// 自检台前端：所有请求按页面所在路径拼接，适配平台的 /apps/<应用>/~<令牌>/ 前缀（不写死绝对路径）。
(function () {
  const ROOT = location.pathname.replace(/pages\/about\/?$/, '').replace(/[^/]*$/, '');
  const $ = id => document.getElementById(id);
  const api = path => ROOT + path;
  const show = (id, value) => { const el = $(id); if (el) el.textContent = typeof value === 'string' ? value : JSON.stringify(value, null, 2); };
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  async function json(path, options = {}) {
    const response = await fetch(api(path), options);
    const text = await response.text();
    let body; try { body = JSON.parse(text); } catch (_e) { body = text; }
    return { status: response.status, headers: response.headers, url: response.url, body };
  }

  // ── 页面打开计数：验证 localStorage 持久化 ──
  let visits = 0;
  try {
    visits = Number(localStorage.getItem('visits') || 0) + 1;
    localStorage.setItem('visits', String(visits));
  } catch (error) { visits = -1; }
  if ($('visits')) $('visits').textContent = visits < 0 ? '不可用' : String(visits);

  // ── 标签页 ──
  document.querySelectorAll('.tabs [data-tab]').forEach(button => button.addEventListener('click', () => {
    document.querySelectorAll('.tabs [data-tab]').forEach(item => item.classList.toggle('active', item === button));
    document.querySelectorAll('.panel').forEach(panel => panel.classList.toggle('active', panel.dataset.panel === button.dataset.tab));
    if (button.dataset.tab === 'notes') loadNotes();
    if (button.dataset.tab === 'console') loadSources();
  }));

  // ── 顶部信息 ──
  json('api/info').then(result => {
    const info = result.body;
    if (!$('subtitle')) return;
    const user = info.user || {};
    $('subtitle').textContent = `v${info.app.version} · Python ${info.runtime.python} · PID ${info.app.pid} · 当前用户 ${user.user || '未知'}（${user.role || '-'}）${user.signatureValid ? ' · 身份签名有效' : ' · 身份签名无效'}`;
  }).catch(error => { if ($('subtitle')) $('subtitle').textContent = `读取运行环境失败：${error.message}`; });

  // ══ 浏览器端检查项 ══
  async function sha256(blob) {
    if (!crypto.subtle) return null;
    const digest = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
    return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
  }

  function randomBlob(bytes) {
    const parts = [];
    for (let offset = 0; offset < bytes; offset += 65536) {
      const chunk = new Uint8Array(Math.min(65536, bytes - offset));
      crypto.getRandomValues(chunk);
      parts.push(chunk);
    }
    return new Blob(parts, { type: 'application/octet-stream' });
  }

  async function readStream(onEvent) {
    const response = await fetch(api('api/stream?count=5&interval=0.5'));
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    const arrivals = [];
    let buffer = '';
    const started = performance.now();
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let index;
      while ((index = buffer.indexOf('\n\n')) >= 0) {
        const event = buffer.slice(0, index);
        buffer = buffer.slice(index + 2);
        const at = Math.round(performance.now() - started);
        arrivals.push(at);
        onEvent && onEvent(`${at} ms  ${event.replace(/\n/g, ' | ')}`);
      }
    }
    return arrivals;
  }

  function wsEcho(text) {
    return new Promise((resolve, reject) => {
      const url = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}${api('ws')}`;
      const socket = new WebSocket(url);
      const messages = [];
      const timer = setTimeout(() => { socket.close(); reject(new Error('WebSocket 10 秒内没有响应')); }, 10000);
      socket.onmessage = event => {
        const data = JSON.parse(event.data);
        messages.push(data);
        if (data.type === 'hello') socket.send(text);
        if (data.type === 'echo') { clearTimeout(timer); socket.close(); resolve(messages); }
      };
      socket.onerror = () => { clearTimeout(timer); reject(new Error('WebSocket 连接失败')); };
    });
  }

  async function isolation() {
    const result = { origin: String(window.origin) };
    try { document.cookie = 'probe=1'; result.cookieAfterWrite = document.cookie; result.cookieNoThrow = true; } catch (e) { result.cookieNoThrow = false; result.cookieError = e.message; }
    try { result.parentTitle = String(window.parent.document.title); result.parentBlocked = false; } catch (_e) { result.parentBlocked = true; }
    try {
      const response = await fetch('/api/custom-tools', { credentials: 'include' });
      result.platformApi = `HTTP ${response.status}`;
      result.platformApiBlocked = response.status === 401 || response.status === 403;
    } catch (e) { result.platformApi = `请求被浏览器拦截：${e.message}`; result.platformApiBlocked = true; }
    try { sessionStorage.setItem('s', '1'); result.sessionStorage = sessionStorage.getItem('s') === '1'; } catch (e) { result.sessionStorage = false; }
    try { localStorage.setItem('__probe', 'ok'); result.localStorage = localStorage.getItem('__probe') === 'ok'; localStorage.removeItem('__probe'); } catch (e) { result.localStorage = false; }
    return result;
  }

  const browserChecks = [
    ['运行环境', '应用只监听 127.0.0.1', '127.0.0.1', async () => { const r = await json('api/info'); return [r.body.env.HOST === '127.0.0.1', `HOST=${r.body.env.HOST}，PORT=${r.body.env.PORT}`]; }],
    ['运行环境', '运行在平台创建的虚拟环境', 'inVenv=true', async () => { const r = await json('api/info'); return [r.body.runtime.inVenv, r.body.runtime.executable]; }],
    ['运行环境', '没有继承平台密钥类环境变量', '列表为空', async () => { const r = await json('api/info'); return [r.body.leakedPlatformVariables.length === 0, JSON.stringify(r.body.leakedPlatformVariables)]; }],
    ['运行环境', '注入基座兼容的数据接口变量', 'BASE_QUERY_URL / APP_SCHEMA 存在', async () => { const r = await json('api/info'); return [/\/hosted-api\/.+\/dh\/query$/.test(r.body.env.BASE_QUERY_URL) && Boolean(r.body.env.APP_SCHEMA), `${r.body.env.BASE_QUERY_URL} · schema ${r.body.env.APP_SCHEMA}`]; }],
    ['身份', '平台用户头签名有效', 'signatureValid=true', async () => { const r = await json('api/info'); return [r.body.user.signatureValid && r.body.user.timestampFresh, `${r.body.user.user}（${r.body.user.role}）@${r.body.user.tenant}`]; }],
    ['身份', '平台 Cookie / Authorization / Origin 未转发给应用', '全部已剥离', async () => { const r = await json('api/info'); const s = r.body.strippedHeaders; return [Object.values(s).every(Boolean), JSON.stringify(s)]; }],
    ['反向代理', 'root_path 等于平台前缀', 'rootPath 与页面路径一致', async () => { const r = await json('api/info'); return [ROOT.startsWith(r.body.proxy.rootPath + '/'), r.body.proxy.rootPath.slice(0, 40) + '…']; }],
    ['反向代理', '307 重定向改写到应用前缀下', '最终地址在前缀内', async () => { const r = await json('api/redirect'); return [r.status === 200 && new URL(r.url).pathname === api('api/healthz') && /from=redirect/.test(r.url), new URL(r.url).pathname.replace(ROOT, '…/')]; }],
    ['反向代理', '去掉 Clear-Site-Data，X-Frame-Options 改为 SAMEORIGIN', '已过滤', async () => { const r = await json('api/cookie'); return [!r.headers.get('clear-site-data') && r.headers.get('x-frame-options') === 'SAMEORIGIN', `clear-site-data=${r.headers.get('clear-site-data')}，x-frame-options=${r.headers.get('x-frame-options')}`]; }],
    ['反向代理', '响应带 CSP sandbox', 'sandbox 且无 allow-same-origin', async () => { const r = await fetch(api('')); const csp = r.headers.get('content-security-policy') || ''; return [/sandbox allow-scripts/.test(csp) && !/allow-same-origin/.test(csp), csp]; }],
    ['反向代理', 'PUT JSON（触发预检）', '方法与请求体原样到达', async () => { const r = await json('api/echo?x=1', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ 中文: '值', quote: "it's" }) }); return [r.body.method === 'PUT' && JSON.parse(r.body.body).quote === "it's" && r.body.query.x === '1', JSON.stringify(r.body).slice(0, 160)]; }],
    ['反向代理', 'DELETE', '方法原样到达', async () => { const r = await json('api/echo', { method: 'DELETE' }); return [r.body.method === 'DELETE', `HTTP ${r.status}`]; }],
    ['反向代理', '流式响应逐条到达', '5 条以上，首末间隔 > 1.5 秒', async () => { const t = await readStream(); return [t.length >= 5 && t[t.length - 1] - t[0] > 1500, `到达时间 ${t.join(' / ')} ms`]; }],
    ['反向代理', '上传 3 MB 二进制，服务端校验一致', 'SHA-256 一致', async () => {
      const blob = randomBlob(3 * 1024 * 1024); const form = new FormData(); form.append('file', blob, '随机.bin');
      const r = await json('api/upload', { method: 'POST', body: form }); const local = await sha256(blob);
      return [r.status === 200 && r.body.bytes === blob.size && (!local || local === r.body.sha256), `${r.body.bytes} 字节 · ${local ? (local === r.body.sha256 ? 'SHA-256 一致' : 'SHA-256 不一致') : '浏览器不支持 SHA-256，仅比对大小'}`];
    }],
    ['反向代理', '下载附件', 'Content-Disposition 为附件', async () => { const r = await fetch(api('api/download?rows=2000')); const blob = await r.blob(); return [r.ok && /attachment/.test(r.headers.get('content-disposition') || '') && blob.size > 10000, `${blob.size} 字节 · ${r.headers.get('content-disposition')}`]; }],
    ['反向代理', 'WebSocket 回显', '收到 hello 与 echo', async () => { const m = await wsEcho('自检'); return [m.some(x => x.type === 'echo' && x.message === '自检'), JSON.stringify(m).slice(0, 160)]; }],
    ['反向代理', '慢请求（3 秒）', '正常返回', async () => { const r = await json('api/slow?seconds=3'); return [r.status === 200, `HTTP ${r.status}`]; }],
    ['反向代理', '应用异常返回 500', 'HTTP 500', async () => { const r = await json('api/error'); return [r.status === 500, `HTTP ${r.status}`]; }],
    ['反向代理', '不存在的路径', 'HTTP 404', async () => { const r = await json('api/not-exist'); return [r.status === 404, `HTTP ${r.status}`]; }],
    ['反向代理', '相对路径静态资源', 'static/app.css 可访问', async () => { const r = await fetch(api('static/app.css')); return [r.ok && /text\/css/.test(r.headers.get('content-type') || ''), `HTTP ${r.status} · ${r.headers.get('content-type')}`]; }],
    ['反向代理', 'Swagger 文档使用前缀', '/docs 引用前缀下的 openapi.json', async () => { const r = await fetch(api('docs')); const html = await r.text(); const spec = await fetch(api('openapi.json')); return [r.ok && html.includes(api('openapi.json')) && spec.ok, `docs ${r.status} · openapi ${spec.status}`]; }],
    ['浏览器沙箱', '页面来源为 null（独立来源）', 'origin=null', async () => { const r = await isolation(); return [r.origin === 'null', `origin=${r.origin}`]; }],
    ['浏览器沙箱', '不能带登录态调用平台 API', '被拦截或 401', async () => { const r = await isolation(); return [r.platformApiBlocked, r.platformApi]; }],
    ['浏览器沙箱', '访问不了上层平台页面', '跨源访问被拒绝', async () => { const r = await isolation(); return [r.parentBlocked, r.parentBlocked ? '已拒绝' : `读到了：${r.parentTitle}`]; }],
    ['浏览器沙箱', 'document.cookie 读写不报错、不生效', '读取为空', async () => { const r = await isolation(); return [r.cookieNoThrow && !r.cookieAfterWrite, `写入后读取「${r.cookieAfterWrite || ''}」`]; }],
    ['浏览器沙箱', 'localStorage / sessionStorage 可用', '读写正常', async () => { const r = await isolation(); return [r.localStorage && r.sessionStorage, `local=${r.localStorage}，session=${r.sessionStorage}`]; }],
    ['浏览器沙箱', 'localStorage 跨刷新保留', '打开次数持续累加', async () => [visits >= 1, visits > 1 ? `已累计 ${visits} 次（之前的值保留了）` : '首次打开；刷新页面后再自检，次数应变为 2']]
  ];

  // ══ 一键自检 ══
  const rows = [];
  function renderResults() {
    const onlyFailed = $('onlyFailed').checked;
    const tbody = $('results').querySelector('tbody');
    tbody.innerHTML = '';
    for (const item of rows) {
      if (onlyFailed && item.status !== 'fail') continue;
      const tr = document.createElement('tr');
      tr.className = item.status;
      const label = { pass: '通过', fail: '失败', skip: '跳过', running: '进行中…' }[item.status];
      [item.group, item.name, item.expect, label, item.detail, item.ms === undefined ? '' : `${item.ms} ms`].forEach((value, index) => {
        const td = document.createElement('td');
        td.textContent = value == null ? '' : String(value);
        if (index === 3) td.className = 'status';
        if (index === 4) td.className = 'detail';
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    }
    const count = status => rows.filter(item => item.status === status).length;
    $('countPass').textContent = `${count('pass')} 通过`;
    $('countFail').textContent = `${count('fail')} 失败`;
    $('countSkip').textContent = `${count('skip')} 跳过`;
  }

  async function loadHistory() {
    const r = await json('api/selftest/history');
    const tbody = $('history').querySelector('tbody');
    tbody.innerHTML = (r.body.items || []).map(item => `<tr><td>${item.id}</td><td>${escape(item.run_by)}</td><td>${item.passed}</td><td>${item.failed}</td><td>${item.skipped}</td><td>${escape(item.created_at)}</td></tr>`).join('') || '<tr><td colspan="6" class="muted">暂无记录</td></tr>';
  }

  $('runAll') && $('runAll').addEventListener('click', async () => {
    const button = $('runAll');
    button.disabled = true;
    button.textContent = '自检中…';
    rows.length = 0;
    $('summary').hidden = false;
    $('resultFilters').hidden = false;
    const started = performance.now();
    for (const [group, name, expect, run] of browserChecks) {
      const item = { group, name, expect, status: 'running' };
      rows.push(item);
      renderResults();
      const t0 = performance.now();
      try {
        const [ok, detail] = await run();
        Object.assign(item, { status: ok ? 'pass' : 'fail', detail });
      } catch (error) {
        Object.assign(item, { status: 'fail', detail: error.message });
      }
      item.ms = Math.round(performance.now() - t0);
      renderResults();
    }
    const placeholder = { group: '数据库', name: '服务端数据库自检', expect: '-', status: 'running' };
    rows.push(placeholder);
    renderResults();
    try {
      const r = await json('api/selftest', { method: 'POST' });
      if (r.status !== 200) throw new Error(`HTTP ${r.status} ${JSON.stringify(r.body).slice(0, 200)}`);
      rows.pop();
      rows.push(...r.body.results);
    } catch (error) {
      Object.assign(placeholder, { status: 'fail', detail: error.message });
    }
    renderResults();
    $('countTime').textContent = `总耗时 ${((performance.now() - started) / 1000).toFixed(1)} 秒`;
    button.disabled = false;
    button.textContent = '重新自检';
    window.HostedTestKitResults = rows.slice();
    loadHistory();
  });
  $('onlyFailed') && $('onlyFailed').addEventListener('change', renderResults);
  if ($('history')) loadHistory();

  // ══ 数据库控制台 ══
  const PRESETS = [
    ['应用库', 'app', '查询便签', 'SELECT id, title, tag, done, created_at FROM t_note ORDER BY id DESC'],
    ['应用库', 'app', '新建表', 'CREATE TABLE IF NOT EXISTS t_demo (\n  id INTEGER PRIMARY KEY AUTOINCREMENT,\n  name TEXT NOT NULL,\n  amount REAL DEFAULT 0,\n  created_at TEXT DEFAULT CURRENT_TIMESTAMP\n)'],
    ['应用库', 'app', '插入多行', "INSERT INTO t_demo (name, amount) VALUES ('张三', 12.5), ('李四', 30), ('O''Brien', 7)"],
    ['应用库', 'app', '查询 t_demo', 'SELECT * FROM t_demo ORDER BY id DESC'],
    ['应用库', 'app', '更新', "UPDATE t_demo SET amount = amount * 2 WHERE name = '张三'"],
    ['应用库', 'app', '聚合统计', 'SELECT count(*) AS 行数, sum(amount) AS 合计, round(avg(amount), 2) AS 平均 FROM t_demo'],
    ['应用库', 'app', '加列', "ALTER TABLE t_demo ADD COLUMN remark TEXT DEFAULT ''"],
    ['应用库', 'app', '建索引', 'CREATE INDEX IF NOT EXISTS idx_demo_name ON t_demo(name)'],
    ['应用库', 'app', '删除行', "DELETE FROM t_demo WHERE name = '李四'"],
    ['应用库', 'app', '查看应用库的表', "SELECT name, type FROM sqlite_master WHERE type IN ('table', 'index') ORDER BY name"],
    ['应用库', 'app', '删除表', 'DROP TABLE IF EXISTS t_demo'],
    ['应被拒绝', 'app', 'ATTACH 其他库', "ATTACH DATABASE '/tmp/x.db' AS x"],
    ['应被拒绝', 'app', 'PRAGMA', 'PRAGMA journal_mode = DELETE'],
    ['应被拒绝', 'app', '多条语句', 'DELETE FROM t_note WHERE 1 = 0; DROP TABLE t_note'],
    ['应被拒绝', 'app', '查询接口写数据（点「执行查询」）', 'DELETE FROM t_note'],
    ['平台库只读', 'platform:report.db', '报表快照数量', 'SELECT count(*) AS n FROM ReportSnapshots'],
    ['平台库只读', 'platform:report.db', '报表快照列表', 'SELECT * FROM ReportSnapshots ORDER BY rowid DESC LIMIT 20'],
    ['应被拒绝', 'platform:tools.db', '读取账号表', 'SELECT username FROM auth_users'],
    ['应被拒绝', 'platform:report.db', '读取 sqlite_master', 'SELECT name, sql FROM sqlite_master'],
    ['应被拒绝', 'platform:report.db', '平台库删除（点「执行查询」）', 'DELETE FROM ReportSnapshots'],
    ['应被拒绝', 'platform:report.db', '写接口指向平台库（点「执行写入」）', 'DELETE FROM ReportSnapshots WHERE 1 = 0'],
    ['应被中止', 'app', '死循环递归（约 15 秒后中止）', 'WITH RECURSIVE n(x) AS (SELECT 1 UNION ALL SELECT x + 1 FROM n) SELECT count(*) FROM n']
  ];
  let sourcesLoaded = false;
  async function loadSources() {
    if (sourcesLoaded) return;
    const select = $('source');
    const r = await json('api/db/datasources');
    const items = Array.isArray(r.body.data) ? r.body.data : [];
    select.innerHTML = items.map(item => {
      const value = item.id === 'app' ? 'app' : item.name;
      const label = item.id === 'app' ? '应用库（可读写）' : `${item.name}（${item.type === 'NETCARE_READONLY' ? 'NetCare 只读' : '平台只读'}）`;
      return `<option value="${escape(value)}">${escape(label)}</option>`;
    }).join('');
    $('preset').innerHTML = '<option value="">选择预设…</option>' + PRESETS.map((item, index) => `<option value="${index}">[${item[0]}] ${escape(item[2])}</option>`).join('');
    sourcesLoaded = true;
  }
  $('preset') && $('preset').addEventListener('change', event => {
    const preset = PRESETS[event.target.value];
    if (!preset) return;
    const [, source, , sql] = preset;
    if (![...$('source').options].some(option => option.value === source)) {
      $('source').insertAdjacentHTML('beforeend', `<option value="${escape(source)}">${escape(source)}（当前不可用）</option>`);
    }
    $('source').value = source;
    $('sql').value = sql;
  });
  async function runSql(kind) {
    const button = kind === 'query' ? $('runQuery') : $('runExecute');
    button.disabled = true;
    $('sqlStatus').textContent = '执行中…';
    try {
      const r = await json(`api/db/${kind}`, { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source: $('source').value || 'app', sql: $('sql').value, limit: Number($('limit').value) || 200 }) });
      const body = r.body;
      const ok = body.success === true;
      $('sqlStatus').innerHTML = `<span class="pill ${ok ? 'pass' : 'fail'}">${ok ? '成功' : '失败'} · 接口 HTTP ${body.httpStatus}</span> ${body.ms} ms${Array.isArray(body.data) ? ` · ${body.data.length} 行${body.truncated ? '（已截断）' : ''}` : ''}${ok ? '' : ` · ${escape(body.message || '')}`}`;
      renderTable($('sqlResult'), Array.isArray(body.data) ? body.data : body.data ? [body.data] : []);
      $('sqlRaw').hidden = false;
      show('sqlRaw', body);
    } catch (error) {
      $('sqlStatus').textContent = error.message;
    } finally {
      button.disabled = false;
    }
  }
  $('runQuery') && $('runQuery').addEventListener('click', () => runSql('query'));
  $('runExecute') && $('runExecute').addEventListener('click', () => runSql('execute'));
  $('runFind') && $('runFind').addEventListener('click', async () => {
    const r = await json(`api/db/find-table?table=${encodeURIComponent($('findTable').value.trim())}`);
    show('findResult', r.body);
  });

  function renderTable(table, data) {
    if (!data.length) { table.innerHTML = '<tbody><tr><td class="muted">（无结果行）</td></tr></tbody>'; return; }
    const columns = [...new Set(data.flatMap(row => Object.keys(row)))];
    table.innerHTML = `<thead><tr>${columns.map(name => `<th>${escape(name)}</th>`).join('')}</tr></thead><tbody>${data.map(row => `<tr>${columns.map(name => `<td>${escape(row[name] == null ? 'NULL' : row[name])}</td>`).join('')}</tr>`).join('')}</tbody>`;
  }

  function escape(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }

  // ══ 便签 CRUD ══
  let notes = [];
  async function loadNotes() {
    if (!$('notes')) return;
    const q = $('noteSearch').value.trim();
    const tag = $('noteTag').value;
    const r = await json(`api/notes?q=${encodeURIComponent(q)}&tag=${encodeURIComponent(tag)}`);
    if (r.status !== 200) { $('notes').innerHTML = `<li class="muted">读取失败：${escape(r.body.message || r.status)}</li>`; return; }
    notes = r.body.items;
    $('noteCount').textContent = `${notes.length} 条`;
    if (!tag) {
      const tags = [...new Set(notes.map(note => note.tag).filter(Boolean))];
      $('noteTag').innerHTML = '<option value="">全部标签</option>' + tags.map(item => `<option>${escape(item)}</option>`).join('');
    }
    $('notes').innerHTML = notes.map(note => `
      <li class="note ${note.done ? 'done' : ''}" data-id="${note.id}">
        <label class="check"><input type="checkbox" data-act="toggle" ${note.done ? 'checked' : ''}></label>
        <div class="note-body"><strong>${escape(note.title)}</strong>${note.tag ? `<span class="tag">${escape(note.tag)}</span>` : ''}
          <p>${escape(note.content || '')}</p><small class="muted">#${note.id} · ${escape(note.created_by || '-')} · 更新于 ${escape(note.updated_at)}</small></div>
        <div class="note-actions"><button class="btn small" data-act="edit">编辑</button><button class="btn small danger" data-act="delete">删除</button></div>
      </li>`).join('') || '<li class="muted">没有便签</li>';
  }
  function resetNoteForm() {
    const form = $('noteForm');
    form.reset();
    form.elements.id.value = '';
    $('noteSubmit').textContent = '新增便签';
    $('noteCancel').hidden = true;
  }
  $('noteForm') && $('noteForm').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const payload = { title: form.elements.title.value.trim(), content: form.elements.content.value, tag: form.elements.tag.value.trim(), done: form.elements.done.checked };
    const id = form.elements.id.value;
    const r = await json(id ? `api/notes/${id}` : 'api/notes', { method: id ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (r.status !== 200) { alert(`保存失败：${r.body.message || r.status}`); return; }
    resetNoteForm();
    loadNotes();
  });
  $('noteCancel') && $('noteCancel').addEventListener('click', resetNoteForm);
  $('noteSearch') && $('noteSearch').addEventListener('input', () => { clearTimeout(loadNotes.timer); loadNotes.timer = setTimeout(loadNotes, 250); });
  $('noteTag') && $('noteTag').addEventListener('change', loadNotes);
  $('notes') && $('notes').addEventListener('click', async event => {
    const act = event.target.dataset.act;
    const li = event.target.closest('.note');
    if (!act || !li) return;
    const note = notes.find(item => String(item.id) === li.dataset.id);
    if (act === 'edit') {
      const form = $('noteForm');
      form.elements.id.value = note.id;
      form.elements.title.value = note.title;
      form.elements.tag.value = note.tag;
      form.elements.content.value = note.content;
      form.elements.done.checked = Boolean(note.done);
      $('noteSubmit').textContent = `保存修改 #${note.id}`;
      $('noteCancel').hidden = false;
      form.elements.title.focus();
      return;
    }
    if (act === 'delete') {
      if (!confirm(`删除便签「${note.title}」？`)) return;
      await json(`api/notes/${note.id}`, { method: 'DELETE' });
    }
    if (act === 'toggle') {
      await json(`api/notes/${note.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...note, done: event.target.checked }) });
    }
    loadNotes();
  });

  // ══ 代理与网络：单项按钮 ══
  const runners = {
    info: async () => show('out-info', (await json('api/info')).body),
    headers: async () => show('out-info', (await json('api/headers')).body),
    redirect: async () => { const r = await json('api/redirect'); show('out-redirect', { 状态: r.status, 最终地址: new URL(r.url).pathname, 响应: r.body }); },
    cookie: async () => { const r = await json('api/cookie'); show('out-redirect', { 状态: r.status, 'clear-site-data': r.headers.get('clear-site-data'), 'x-frame-options': r.headers.get('x-frame-options'), '写入后的 document.cookie': document.cookie, 响应: r.body }); },
    put: async () => show('out-echo', (await json('api/echo?from=put', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ 中文: '值', n: 1 }) })).body),
    patch: async () => show('out-echo', (await json('api/echo', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: '{"patch":true}' })).body),
    delete: async () => show('out-echo', (await json('api/echo?id=9', { method: 'DELETE' })).body),
    form: async () => show('out-echo', (await json('api/echo', { method: 'POST', body: new URLSearchParams({ a: '1', 中文: '表单' }) })).body),
    stream: async () => { const lines = []; await readStream(line => { lines.push(line); show('out-stream', lines.join('\n')); }); lines.push('（结束）'); show('out-stream', lines.join('\n')); },
    upload: async () => {
      const file = $('uploadFile').files[0];
      if (!file) return show('out-upload', '请先选择文件');
      const form = new FormData(); form.append('file', file);
      const r = await json('api/upload', { method: 'POST', body: form });
      show('out-upload', { ...r.body, 本地SHA256: await sha256(file) });
    },
    'upload-gen': async () => {
      const blob = randomBlob(5 * 1024 * 1024); const form = new FormData(); form.append('file', blob, '生成的5MB.bin');
      const t0 = performance.now(); const r = await json('api/upload', { method: 'POST', body: form });
      show('out-upload', { ...r.body, 本地SHA256: await sha256(blob), 耗时ms: Math.round(performance.now() - t0) });
    },
    download: async () => {
      const r = await fetch(api('api/download?rows=5000'));
      const blob = await r.blob();
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = '自检下载.csv';
      link.click();
      show('out-upload', { 状态: r.status, 字节: blob.size, 'content-disposition': r.headers.get('content-disposition') });
    },
    ws: async () => show('out-ws', await wsEcho($('wsText').value || 'ping')),
    error: async () => { const r = await json('api/error'); show('out-error', { 状态: r.status, 响应: r.body }); },
    notfound: async () => { const r = await json('api/not-exist'); show('out-error', { 状态: r.status, 响应: r.body }); },
    slow: async () => { const t0 = performance.now(); const r = await json('api/slow?seconds=5'); show('out-error', { 状态: r.status, 响应: r.body, 耗时ms: Math.round(performance.now() - t0) }); },
    slowsql: async () => {
      show('out-error', '执行中，约 15 秒…');
      const t0 = performance.now();
      const r = await json('api/db/query', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ source: 'app', sql: 'WITH RECURSIVE n(x) AS (SELECT 1 UNION ALL SELECT x + 1 FROM n) SELECT count(*) FROM n' }) });
      show('out-error', { 接口状态: r.body.httpStatus, 消息: r.body.message, 耗时ms: Math.round(performance.now() - t0) });
    },
    crash: async () => {
      if (!confirm('进程将异常退出，平台会自动重启。继续？')) return;
      const before = (await json('api/info')).body.app;
      const r = await json('api/crash', { method: 'POST' });
      if (r.status !== 200) return show('out-crash', r.body);
      const log = [`崩溃前 PID ${before.pid}`, r.body.message];
      show('out-crash', log.join('\n'));
      const started = performance.now();
      await sleep(1500);
      for (let i = 0; i < 30; i++) {
        try {
          const after = await json('api/healthz');
          if (after.status === 200) {
            const now = (await json('api/info')).body.app;
            log.push(`${((performance.now() - started) / 1000).toFixed(1)} 秒后恢复：新 PID ${now.pid}，运行 ${now.uptime} 秒${now.pid !== before.pid ? '（已重启）' : ''}`);
            break;
          }
          log.push(`等待中… HTTP ${after.status}`);
        } catch (error) { log.push(`等待中… ${error.message}`); }
        show('out-crash', log.join('\n'));
        await sleep(1000);
      }
      show('out-crash', log.join('\n'));
    },
    static: async () => {
      const css = await fetch(api('static/app.css'));
      const docs = await fetch(api('docs'));
      const html = await docs.text();
      show('out-static', { 'static/app.css': `${css.status} ${css.headers.get('content-type')}`, docs: docs.status, 'docs 引用前缀下的 openapi.json': html.includes(api('openapi.json')) });
    },
    isolation: async () => show('out-isolation', await isolation())
  };
  document.querySelectorAll('[data-run]').forEach(button => button.addEventListener('click', async () => {
    button.disabled = true;
    try { await runners[button.dataset.run](); } catch (error) { alert(error.message); } finally { button.disabled = false; }
  }));

  // ══ 浏览器沙箱 ══
  $('lsSet') && $('lsSet').addEventListener('click', () => { localStorage.setItem($('lsKey').value, $('lsValue').value); show('out-ls', `已写入 ${$('lsKey').value}；刷新页面或打开第二个页面后读取，值应保留`); });
  $('lsGet') && $('lsGet').addEventListener('click', () => show('out-ls', { key: $('lsKey').value, value: localStorage.getItem($('lsKey').value), 全部: Object.fromEntries(Array.from({ length: localStorage.length }, (_, i) => [localStorage.key(i), localStorage.getItem(localStorage.key(i))])) }));
  $('lsClear') && $('lsClear').addEventListener('click', () => { localStorage.clear(); show('out-ls', '已清空（打开次数也会重新计数）'); });
  $('openPopup') && $('openPopup').addEventListener('click', () => { const w = window.open(location.href, '_blank'); show('out-popup', w ? '已打开新窗口' : '弹窗被浏览器拦截'); });
  $('alertTest') && $('alertTest').addEventListener('click', () => { alert('alert 正常'); show('out-popup', `confirm 返回：${confirm('confirm 正常吗？')}`); });
})();
