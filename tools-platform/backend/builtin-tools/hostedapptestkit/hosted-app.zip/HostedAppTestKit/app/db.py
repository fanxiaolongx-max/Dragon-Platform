"""数据访问层：所有 SQL 经平台注入的基座兼容接口（BASE_QUERY_URL），应用不持有任何数据库连接。"""
import os
from typing import Any, Optional

import httpx

_client: Optional[httpx.AsyncClient] = None


def base_url() -> str:
    # BASE_QUERY_URL 去掉末尾 /query 即基础地址（与数字人基座约定一致）
    return os.environ.get("BASE_QUERY_URL", "").rsplit("/query", 1)[0]


def app_scope() -> dict:
    return {"datasourceId": os.environ.get("APP_DATASOURCE_ID", "app"), "schema": os.environ.get("APP_SCHEMA", "")}


def client() -> httpx.AsyncClient:
    global _client
    if _client is None:
        # trust_env=False：不走系统代理，平台接口只在本机
        _client = httpx.AsyncClient(trust_env=False, timeout=30)
    return _client


async def close():
    global _client
    if _client is not None:
        await _client.aclose()
        _client = None


async def _call(method: str, path: str, **kwargs) -> dict:
    """返回 {status, body}，保留接口原始状态码，便于自检比对预期。"""
    try:
        response = await client().request(method, base_url() + path, **kwargs)
    except httpx.HTTPError as error:
        return {"status": 0, "body": {"success": False, "message": f"无法连接平台数据接口：{error}"}}
    try:
        body: Any = response.json()
    except ValueError:
        body = {"success": False, "message": response.text[:500]}
    return {"status": response.status_code, "body": body}


async def query(source: str, sql: str, limit: int = 1000) -> dict:
    """source=app 查应用库；否则按 datasourceName 查业务库（platform:xxx.db 或 NetCare 组名）。"""
    payload = {**app_scope(), "sql": sql, "limit": limit} if source == "app" else {"datasourceName": source, "sql": sql, "limit": limit}
    return await _call("POST", "/query", json=payload)


async def execute(sql: str, scope: Optional[dict] = None) -> dict:
    payload = {**(scope if scope is not None else app_scope()), "sql": sql}
    return await _call("POST", "/execute", json=payload, headers={"x-app-id": os.environ.get("APP_UUID", "")})


async def raw(path: str, payload: dict) -> dict:
    """自检用：原样提交请求体，验证越权请求被拒绝。"""
    return await _call("POST", path, json=payload)


async def datasources() -> dict:
    return await _call("GET", "/query/datasources")


async def find_table(table: str) -> dict:
    return await _call("GET", "/query/find-table-datasource", params={"table": table})


def quote(value: Any) -> str:
    """字面量转义（单引号加倍）；None → NULL。"""
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (int, float)):
        return str(value)
    return "'" + str(value).replace("'", "''") + "'"


def rows(result: dict) -> list:
    data = result.get("body", {}).get("data")
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("rows", [])
    return result.get("body", {}).get("rows", [])
