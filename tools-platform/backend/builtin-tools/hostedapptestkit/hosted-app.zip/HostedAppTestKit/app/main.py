"""托管应用自检台：FastAPI 应用工厂。页面与 API 路径都按相对路径组织，适配平台反向代理前缀。"""
import asyncio
import hashlib
import hmac
import io
import os
import platform as py_platform
import sys
import time
from typing import Optional
from urllib.parse import unquote

from fastapi import FastAPI, File, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import db, selftest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC = os.path.join(ROOT, "static")
VERSION = open(os.path.join(ROOT, "HostedAppTestKit.version"), encoding="utf-8").read().strip()
STARTED_AT = time.time()


def platform_user(request: Request) -> dict:
    """读取平台转发的用户头并校验签名：HMAC-SHA256(PLATFORM_APP_SECRET, user\\nrole\\ntenant\\ntimestamp)。"""
    h = request.headers
    user, role, tenant, ts = h.get("x-platform-user", ""), h.get("x-platform-role", ""), h.get("x-platform-tenant", ""), h.get("x-platform-timestamp", "")
    secret = os.environ.get("PLATFORM_APP_SECRET", "")
    expected = hmac.new(secret.encode(), f"{user}\n{role}\n{tenant}\n{ts}".encode(), hashlib.sha256).hexdigest() if secret else ""
    signed = bool(secret) and hmac.compare_digest(expected, h.get("x-platform-signature", ""))
    fresh = ts.isdigit() and abs(time.time() * 1000 - int(ts)) < 5 * 60 * 1000
    return {"user": unquote(user), "role": role, "tenant": tenant, "signatureValid": signed, "timestampFresh": fresh}


def mask(value: Optional[str]) -> str:
    if not value:
        return ""
    if "/hosted-api/" in value:
        head, tail = value.split("/hosted-api/", 1)
        token, _, rest = tail.partition("/")
        return f"{head}/hosted-api/{token[:4]}…{token[-4:]}/{rest}"
    return value


class SqlBody(BaseModel):
    source: str = "app"
    sql: str
    limit: int = 200


class NoteBody(BaseModel):
    title: str
    content: str = ""
    tag: str = ""
    done: bool = False


def create_app() -> FastAPI:
    app = FastAPI(title="托管应用自检台", version=VERSION)
    app.mount("/static", StaticFiles(directory=STATIC), name="static")

    @app.on_event("shutdown")
    async def _shutdown():
        await db.close()

    # ── 页面 ──
    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(os.path.join(STATIC, "index.html"))

    @app.get("/pages/about", include_in_schema=False)
    def about():
        return FileResponse(os.path.join(STATIC, "pages", "about.html"))

    # ── 运行环境与身份 ──
    @app.get("/api/healthz")
    def healthz():
        return {"ok": True, "uptime": round(time.time() - STARTED_AT, 1)}

    @app.get("/api/info")
    def info(request: Request):
        h = request.headers
        leaked = [k for k in os.environ if any(word in k.upper() for word in ("PASSWORD", "TOOLS_", "GEMINI", "OPENAI", "API_KEY")) and k != "PLATFORM_APP_SECRET"]
        return {
            "app": {"name": "HostedAppTestKit", "version": VERSION, "pid": os.getpid(), "uptime": round(time.time() - STARTED_AT, 1)},
            "runtime": {"python": sys.version.split()[0], "platform": py_platform.platform(), "cwd": os.getcwd(), "executable": sys.executable,
                        "inVenv": sys.prefix != getattr(sys, "base_prefix", sys.prefix)},
            "env": {k: mask(os.environ.get(k)) for k in ["HOST", "PORT", "RELOAD", "WORKERS", "DEBUG", "APP_NAME", "APP_VERSION", "BASE_QUERY_URL",
                                                      "APP_DATASOURCE_ID", "APP_SCHEMA", "APP_UUID", "APP_LEVEL", "BUSINESS_DATASOURCE_NAME", "PLATFORM_APP_SLUG"]},
            "platformSecretInjected": bool(os.environ.get("PLATFORM_APP_SECRET")),
            "leakedPlatformVariables": leaked,
            "user": platform_user(request),
            "proxy": {"rootPath": request.scope.get("root_path", ""), "path": request.url.path, "forwardedPrefix": mask(h.get("x-forwarded-prefix", ""))[:24] + "…",
                      "forwardedProto": h.get("x-forwarded-proto"), "clientHost": request.client.host if request.client else None},
            "strippedHeaders": {name: h.get(name) is None for name in ["cookie", "authorization", "origin", "referer", "x-forwarded-for", "cf-connecting-ip"]},
        }

    @app.get("/api/headers")
    def headers(request: Request):
        return {k: (v[:12] + "…" if k in ("x-platform-signature", "x-forwarded-prefix") else v) for k, v in request.headers.items()}

    # ── 代理行为 ──
    @app.get("/api/redirect")
    def redirect():
        return RedirectResponse("/api/healthz?from=redirect", status_code=307)

    @app.get("/api/cookie")
    def cookie():
        response = JSONResponse({"note": "应用尝试设置 tools_token Cookie 并下发 Clear-Site-Data；平台应全部去掉，浏览器里看不到它们"})
        response.set_cookie("tools_token", "hijack-attempt")
        response.headers["Clear-Site-Data"] = '"cookies", "storage"'
        response.headers["X-Frame-Options"] = "DENY"
        return response

    @app.api_route("/api/echo", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    async def echo(request: Request):
        body = await request.body()
        return {"method": request.method, "query": dict(request.query_params), "contentType": request.headers.get("content-type"),
                "body": body.decode("utf-8", "replace")[:2000], "bytes": len(body)}

    @app.get("/api/stream")
    async def stream(count: int = 5, interval: float = 0.4):
        async def events():
            for index in range(1, min(count, 50) + 1):
                yield f"data: 第 {index} 条 · {time.strftime('%H:%M:%S')}\n\n"
                await asyncio.sleep(min(interval, 2))
            yield "event: done\ndata: end\n\n"
        return StreamingResponse(events(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})

    @app.post("/api/upload")
    async def upload(file: UploadFile = File(...)):
        digest, size = hashlib.sha256(), 0
        while chunk := await file.read(1024 * 1024):
            digest.update(chunk)
            size += len(chunk)
        return {"filename": file.filename, "contentType": file.content_type, "bytes": size, "sha256": digest.hexdigest()}

    @app.get("/api/download")
    def download(rows: int = 100):
        buffer = io.StringIO()
        buffer.write("﻿id,名称,分数\n")
        for index in range(1, min(rows, 100000) + 1):
            buffer.write(f"{index},样例{index},{index % 100}\n")
        data = buffer.getvalue().encode("utf-8")
        return StreamingResponse(iter([data]), media_type="text/csv; charset=utf-8",
                                 headers={"Content-Disposition": "attachment; filename*=UTF-8''%E8%87%AA%E6%A3%80%E4%B8%8B%E8%BD%BD.csv", "Content-Length": str(len(data))})

    @app.get("/api/slow")
    async def slow(seconds: float = 3):
        await asyncio.sleep(min(seconds, 120))
        return {"sleptSeconds": min(seconds, 120)}

    @app.get("/api/error")
    def error():
        raise RuntimeError("这是自检故意抛出的异常，应返回 500")

    @app.post("/api/crash")
    async def crash(request: Request):
        user = platform_user(request)
        if user["role"] != "admin" or not user["signatureValid"]:
            return JSONResponse({"error": "只有管理员可以触发崩溃测试"}, status_code=403)
        asyncio.get_running_loop().call_later(0.5, lambda: os._exit(3))
        return {"message": "进程将在 0.5 秒后异常退出（退出码 3），平台应在约 1 秒后自动重启"}

    @app.websocket("/ws")
    async def websocket(ws: WebSocket):
        await ws.accept()
        await ws.send_json({"type": "hello", "message": "WebSocket 已连接", "user": unquote(ws.headers.get("x-platform-user", ""))})
        try:
            while True:
                text = await ws.receive_text()
                await ws.send_json({"type": "echo", "message": text, "at": time.strftime("%H:%M:%S")})
        except WebSocketDisconnect:
            pass

    # ── 数据库 ──
    @app.get("/api/db/datasources")
    async def datasources():
        result = await db.datasources()
        return JSONResponse(result["body"], status_code=result["status"] or 502)

    @app.get("/api/db/find-table")
    async def find_table(table: str):
        result = await db.find_table(table)
        return JSONResponse(result["body"], status_code=result["status"] or 502)

    @app.post("/api/db/query")
    async def query(body: SqlBody):
        started = time.perf_counter()
        result = await db.query(body.source, body.sql, body.limit)
        return JSONResponse({**result["body"], "httpStatus": result["status"], "ms": round((time.perf_counter() - started) * 1000)}, status_code=200)

    @app.post("/api/db/execute")
    async def execute(body: SqlBody):
        started = time.perf_counter()
        scope = None if body.source == "app" else {"datasourceName": body.source}
        result = await db.execute(body.sql, scope)
        return JSONResponse({**result["body"], "httpStatus": result["status"], "ms": round((time.perf_counter() - started) * 1000)}, status_code=200)

    @app.post("/api/selftest")
    async def run_selftest(request: Request):
        results = await selftest.run()
        counts = {status: sum(1 for item in results if item["status"] == status) for status in ("pass", "fail", "skip")}
        await db.execute(f"INSERT INTO t_check_run(run_by, passed, failed, skipped) VALUES ({db.quote(platform_user(request)['user'])}, {counts['pass']}, {counts['fail']}, {counts['skip']})")
        return {"results": results, "counts": counts}

    @app.get("/api/selftest/history")
    async def selftest_history():
        result = await db.query("app", "SELECT id, run_by, passed, failed, skipped, created_at FROM t_check_run ORDER BY id DESC", 20)
        return {"items": db.rows(result)}

    # ── 便签 CRUD（应用库 t_note）──
    @app.get("/api/notes")
    async def list_notes(q: str = "", tag: str = ""):
        where = ["1 = 1"]
        if q:
            like = db.quote(f"%{q}%")
            where.append(f"(title LIKE {like} OR content LIKE {like})")
        if tag:
            where.append(f"tag = {db.quote(tag)}")
        result = await db.query("app", f"SELECT id, title, content, tag, done, created_by, created_at, updated_at FROM t_note WHERE {' AND '.join(where)} ORDER BY done, id DESC", 500)
        if result["status"] != 200:
            return JSONResponse(result["body"], status_code=result["status"] or 502)
        return {"items": db.rows(result)}

    @app.post("/api/notes")
    async def create_note(note: NoteBody, request: Request):
        result = await db.execute(f"INSERT INTO t_note(title, content, tag, done, created_by) VALUES ({db.quote(note.title)}, {db.quote(note.content)}, {db.quote(note.tag)}, {db.quote(note.done)}, {db.quote(platform_user(request)['user'])})")
        return JSONResponse(result["body"], status_code=result["status"] or 502)

    @app.put("/api/notes/{note_id}")
    async def update_note(note_id: int, note: NoteBody):
        result = await db.execute(f"UPDATE t_note SET title = {db.quote(note.title)}, content = {db.quote(note.content)}, tag = {db.quote(note.tag)}, done = {db.quote(note.done)}, updated_at = datetime('now', 'localtime') WHERE id = {note_id}")
        return JSONResponse(result["body"], status_code=result["status"] or 502)

    @app.delete("/api/notes/{note_id}")
    async def delete_note(note_id: int):
        result = await db.execute(f"DELETE FROM t_note WHERE id = {note_id}")
        return JSONResponse(result["body"], status_code=result["status"] or 502)

    return app
