"""服务端自检：逐项调用平台数据接口，按预期判定通过 / 失败 / 跳过。"""
import time
import uuid
from typing import Awaitable, Callable

from . import db

OK = lambda r: r["status"] == 200 and r["body"].get("success") is True  # noqa: E731
DENIED = lambda r: r["status"] in (400, 403)  # noqa: E731


class Suite:
    def __init__(self):
        self.results = []

    async def check(self, group: str, name: str, expect: str, call: Callable[[], Awaitable[dict]], judge: Callable[[dict], bool], detail: Callable[[dict], str] = None):
        started = time.perf_counter()
        try:
            result = await call()
            ok = bool(judge(result))
            info = detail(result) if detail else _summary(result)
        except Exception as error:  # 自检本身出错也记为失败
            ok, info = False, f"{type(error).__name__}: {error}"
        self.results.append({"group": group, "name": name, "expect": expect, "status": "pass" if ok else "fail",
                             "detail": info, "ms": round((time.perf_counter() - started) * 1000)})

    def skip(self, group: str, name: str, reason: str):
        self.results.append({"group": group, "name": name, "expect": "-", "status": "skip", "detail": reason, "ms": 0})


def _summary(result: dict) -> str:
    body = result.get("body") or {}
    data = body.get("data")
    if isinstance(data, list):
        preview = data[:2]
        return f"HTTP {result['status']} · {len(data)} 行 · {preview}"[:300]
    return f"HTTP {result['status']} · {body.get('message') or data}"[:300]


async def run() -> list:
    s = Suite()
    table = f"t_selftest_{uuid.uuid4().hex[:8]}"

    # ── 数据源 ──
    ds = await db.datasources()
    sources = db.rows(ds)
    names = [item.get("name") or item.get("id") for item in sources]
    platform = [item["name"] for item in sources if item.get("type") == "PLATFORM_READONLY"]
    netcare = [item["name"] for item in sources if item.get("type") == "NETCARE_READONLY"]
    await s.check("数据源", "列出可用数据源", "返回应用库 + 平台只读库", lambda: _ret(ds),
                  lambda r: OK(r) and "应用库" in names and bool(platform), lambda r: "、".join(map(str, names)))

    # ── 应用库：增删改查与 DDL ──
    g = "应用库读写"
    await s.check(g, "CREATE TABLE", "成功", lambda: db.execute(f"CREATE TABLE {table} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, score REAL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)"), OK)
    await s.check(g, "CREATE INDEX", "成功", lambda: db.execute(f"CREATE INDEX idx_{table}_name ON {table}(name)"), OK)
    await s.check(g, "INSERT 单行", "affectedRows=1 且返回 lastInsertId", lambda: db.execute(f"INSERT INTO {table}(name, score) VALUES ('张三', 88.5)"),
                  lambda r: OK(r) and r["body"]["data"]["affectedRows"] == 1 and r["body"]["data"].get("lastInsertId"))
    await s.check(g, "INSERT 多行", "affectedRows=3", lambda: db.execute(f"INSERT INTO {table}(name, score) VALUES ('李四', 72), ('王五', 95), ('含''引号', 60)"),
                  lambda r: OK(r) and r["body"]["data"]["affectedRows"] == 3)
    await s.check(g, "SELECT", "4 行，中文与引号原样返回", lambda: db.query("app", f"SELECT id, name, score FROM {table} ORDER BY id"),
                  lambda r: OK(r) and len(db.rows(r)) == 4 and db.rows(r)[3]["name"] == "含'引号")
    await s.check(g, "UPDATE", "affectedRows=1", lambda: db.execute(f"UPDATE {table} SET score = score + 10 WHERE name = '李四'"),
                  lambda r: OK(r) and r["body"]["data"]["affectedRows"] == 1)
    await s.check(g, "聚合查询", "count=4，max=95", lambda: db.query("app", f"SELECT count(*) AS n, max(score) AS top, round(avg(score), 2) AS avg FROM {table}"),
                  lambda r: OK(r) and db.rows(r)[0]["n"] == 4 and db.rows(r)[0]["top"] == 95)
    await s.check(g, "UPSERT（INSERT … ON CONFLICT）", "成功", lambda: db.execute(f"INSERT INTO {table}(id, name, score) VALUES (1, '张三', 99) ON CONFLICT(id) DO UPDATE SET score = excluded.score"), OK)
    await s.check(g, "ALTER TABLE ADD COLUMN", "成功", lambda: db.execute(f"ALTER TABLE {table} ADD COLUMN remark TEXT DEFAULT ''"), OK)
    await s.check(g, "WITH 递归查询 + limit", "按 limit 只返回 5 行", lambda: db.query("app", "WITH RECURSIVE n(x) AS (SELECT 1 UNION ALL SELECT x + 1 FROM n WHERE x < 50) SELECT x FROM n", 5),
                  lambda r: OK(r) and len(db.rows(r)) == 5)
    await s.check(g, "单次最多 1000 行", "请求 5000 行只返回 1000 行", lambda: db.query("app", "WITH RECURSIVE n(x) AS (SELECT 1 UNION ALL SELECT x + 1 FROM n WHERE x < 3000) SELECT x FROM n", 5000),
                  lambda r: OK(r) and len(db.rows(r)) == 1000, lambda r: f"返回 {len(db.rows(r))} 行，truncated={r['body'].get('truncated')}")
    await s.check(g, "DELETE", "affectedRows=1", lambda: db.execute(f"DELETE FROM {table} WHERE name = '王五'"), lambda r: OK(r) and r["body"]["data"]["affectedRows"] == 1)
    await s.check(g, "SQL 语法错误", "返回 400 和 SQLite 错误原因，不崩溃", lambda: db.query("app", "SELECT * FROM t_note WHERE"), lambda r: r["status"] == 400 and "SQL 执行失败" in str(r["body"].get("message")))
    await s.check(g, "查询不存在的表", "返回 400 和错误原因", lambda: db.query("app", "SELECT * FROM t_not_exist"), lambda r: r["status"] == 400 and "no such table" in str(r["body"].get("message")))
    await s.check(g, "init.sqlite.sql 种子数据", "t_note 中有初始化便签", lambda: db.query("app", "SELECT title FROM t_note WHERE created_by = 'init.sqlite.sql'"),
                  lambda r: OK(r) and len(db.rows(r)) >= 1)
    await s.check(g, "DROP TABLE", "成功", lambda: db.execute(f"DROP TABLE {table}"), OK)

    # ── 应用库：越界拦截 ──
    g = "应用库越界拦截"
    await s.check(g, "ATTACH 其他数据库", "拒绝（400）", lambda: db.execute("ATTACH DATABASE '/tmp/other.db' AS other"), DENIED)
    await s.check(g, "PRAGMA", "拒绝（400）", lambda: db.execute("PRAGMA writable_schema = 1"), DENIED)
    await s.check(g, "一次多条语句", "拒绝（400）", lambda: db.execute("DELETE FROM t_note WHERE 1 = 0; DROP TABLE t_note"), DENIED)
    await s.check(g, "load_extension", "拒绝（400）", lambda: db.query("app", "SELECT load_extension('x')"), DENIED)
    await s.check(g, "虚拟表", "拒绝（400）", lambda: db.execute("CREATE VIRTUAL TABLE v_fts USING fts5(body)"), DENIED)
    await s.check(g, "访问其他应用的 schema", "拒绝（403）", lambda: db.raw("/query", {"datasourceId": "app", "schema": "another-app", "sql": "SELECT 1"}), lambda r: r["status"] == 403)
    await s.check(g, "查询接口执行写语句", "拒绝（400）", lambda: db.query("app", "DELETE FROM t_note"), DENIED)

    # ── 平台库：只读 ──
    g = "平台库只读"
    if not platform:
        s.skip(g, "平台库", "没有可用的平台库")
    else:
        first = platform[0]
        await s.check(g, f"SELECT 1（{first}）", "成功", lambda: db.query(first, "SELECT 1 AS ok"), OK)
        found = db.rows(await db.find_table("ReportSnapshots"))
        if found:
            src = found[0]["datasourceName"]
            await s.check(g, f"按表名反查并读取 ReportSnapshots（{src}）", "成功", lambda: db.query(src, "SELECT count(*) AS n FROM ReportSnapshots"), OK)
        else:
            s.skip(g, "读取 ReportSnapshots", "当前租户的平台库里没有这张表")
        await s.check(g, "查询接口执行 DELETE", "拒绝（400）", lambda: db.query(first, "DELETE FROM PlatformConfig"), DENIED)
        await s.check(g, "写接口指向平台库", "拒绝（403）", lambda: db.raw("/execute", {"datasourceName": first, "sql": "DELETE FROM PlatformConfig"}), lambda r: r["status"] == 403)
        await s.check(g, "读取 sqlite_master", "拒绝（403）", lambda: db.query(first, "SELECT name, sql FROM sqlite_master"), lambda r: r["status"] == 403)
        if "platform:tools.db" in platform:
            await s.check(g, "读取账号表 auth_users", "拒绝（403）", lambda: db.query("platform:tools.db", "SELECT username FROM auth_users"), lambda r: r["status"] == 403)
            await s.check(g, "子查询间接读取 auth_sessions", "拒绝（403）", lambda: db.query("platform:tools.db", "SELECT 1 WHERE EXISTS (SELECT 1 FROM auth_sessions)"), lambda r: r["status"] == 403)
        else:
            s.skip(g, "账号表拦截", "当前租户没有 platform:tools.db")
        await s.check(g, "不存在的平台库", "拒绝（404）", lambda: db.query("platform:not-exist.db", "SELECT 1"), lambda r: r["status"] == 404)
        await s.check(g, "聊天记录库", "不开放（403）", lambda: db.query("platform:chat-history.db", "SELECT 1"), lambda r: r["status"] in (403, 404))

    # ── NetCare 业务库 ──
    g = "NetCare 业务库"
    if netcare:
        await s.check(g, f"SELECT 1（{netcare[0]}）", "经基座只读转发成功", lambda: db.query(netcare[0], "SELECT 1 AS ok", 1), OK)
        await s.check(g, "写语句", "拒绝", lambda: db.query(netcare[0], "DELETE FROM t WHERE 1 = 0"), lambda r: r["status"] >= 400)
    else:
        s.skip(g, "NetCare 只读转发", "平台未启用数字人基座（全局设置 › 频道对接 › 数字人）")

    return s.results


async def _ret(value):
    return value
