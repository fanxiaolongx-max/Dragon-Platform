"""本地开发入口：python run.py。平台托管时不执行本文件，由平台用 uvicorn 在 127.0.0.1 启动 app.main:create_app。"""
import os

import uvicorn

if __name__ == "__main__":
    uvicorn.run("app.main:create_app", factory=True, host="127.0.0.1", port=int(os.getenv("PORT", "5600")))
