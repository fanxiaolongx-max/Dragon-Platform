-- 应用库初始化脚本：首次启动时由平台在本应用独享的 SQLite 中执行一次（内容变化后再执行）
CREATE TABLE IF NOT EXISTS t_note (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    tag TEXT NOT NULL DEFAULT '',
    done INTEGER NOT NULL DEFAULT 0,
    created_by TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_note_tag ON t_note(tag);
CREATE TABLE IF NOT EXISTS t_check_run (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_by TEXT NOT NULL DEFAULT '',
    passed INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    skipped INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO t_note (title, content, tag, created_by)
SELECT '欢迎使用自检台', '这条便签来自 db/init.sqlite.sql 的种子数据，说明初始化脚本已执行。', '种子', 'init.sqlite.sql'
WHERE NOT EXISTS (SELECT 1 FROM t_note WHERE created_by = 'init.sqlite.sql');
