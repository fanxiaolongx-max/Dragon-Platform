# 托管应用自检台（HostedAppTestKit）

这是验证平台「托管 Python Web 应用」功能的测试包，结构符合平台导入要求：
- 根目录有 `requirements.txt` 和 `platform-app.json`；
- 入口是 `app.main:create_app`（工厂函数）；
- 自带 `db/init.sqlite.sql` 初始化脚本。

## 导入

1. 在首页点「导入 HTML / ZIP / SKILL」，选择 zip。弹窗应显示「已识别为 Python Web 应用（app.main:create_app，ASGI）」，确认后导入。
2. 打开工具菜单里的「托管应用自检台」。首次打开会创建虚拟环境并安装依赖（fastapi、uvicorn、httpx、python-multipart、websockets），完成后自动进入页面。

有两个包可选：
- `hosted-app-test-kit.zip`：在线安装依赖。内网机器可在启动页「Python 环境设置」里配置 pip 镜像。
- `hosted-app-test-kit-offline-macos-arm64-py3.13.zip`：自带 `wheels/`，只能在 macOS Apple 芯片 + Python 3.13 上离线安装。其他平台请用在线包，或在目标机器上执行 `pip download -r requirements.txt -d wheels` 后自己打包。

## 页面功能

| 标签页 | 内容 |
| --- | --- |
| 一键自检 | 约 60 项检查，自动判定通过 / 失败 / 跳过，结果写入应用库 `t_check_run` |
| 数据库控制台 | 选择数据源（应用库 / 平台只读库 / NetCare）执行任意 SQL；预设包含建表、增删改查、聚合、加列、索引，以及应被拒绝或中止的语句 |
| 便签 | 应用库 `t_note` 的完整增删改查：新增、编辑、勾选完成、删除、搜索、按标签筛选 |
| 代理与网络 | 运行环境与身份签名、重定向改写、响应头过滤、PUT/PATCH/DELETE 预检、SSE 流式、上传（SHA-256 校验）、下载、WebSocket、500/404、慢请求、慢 SQL 中止、崩溃自动重启（仅管理员）、静态资源与 Swagger |
| 浏览器沙箱 | localStorage 持久化计数、读写与清空、隔离检查（来源为 null、平台 API 不可用、上层页面不可访问、Cookie 不生效）、弹窗、alert/confirm |
| 第二个页面 | 多页面跳转，验证相对路径与 localStorage 跨页面保留 |

## 一键自检覆盖的内容

- **运行环境**：只监听 127.0.0.1；运行在独立虚拟环境；没有继承平台密钥；注入了基座兼容的数据接口变量。
- **身份**：`X-Platform-*` 用户头的 HMAC 签名有效，时间戳新鲜；Cookie、Authorization、Origin、Referer 和转发头都已剥离。
- **反向代理**：
  - root_path 与访问前缀一致，307 重定向改写到前缀内；
  - 去掉 Clear-Site-Data，X-Frame-Options 改为 SAMEORIGIN，响应带 CSP sandbox；
  - PUT 预检、DELETE、SSE 逐条到达、3 MB 上传 SHA-256 一致、附件下载、WebSocket 回显；
  - 慢请求、500、404、静态资源、Swagger。
- **浏览器沙箱**：页面来源为 null；不能带登录态调用平台 API；访问不了上层页面；document.cookie 不报错也不生效；localStorage / sessionStorage 可用，刷新后保留。
- **应用库读写**：CREATE TABLE / INDEX、单行和多行 INSERT（含中文和单引号）、SELECT、UPDATE、聚合、UPSERT、ALTER TABLE、WITH 递归 + limit、单次 1000 行上限、DELETE、语法错误、init.sqlite.sql 种子数据、DROP TABLE。
- **应用库越界拦截**：ATTACH、PRAGMA、多条语句、load_extension、虚拟表、访问其他应用的 schema、用查询接口执行写语句，都应被拒绝。
- **平台库只读**：SELECT 1 和按表名反查读取 ReportSnapshots 应成功；以下都应被拒绝：
  - 查询接口执行 DELETE、写接口指向平台库；
  - 读取 sqlite_master、读取账号表 auth_users、子查询间接读取 auth_sessions；
  - 不存在的库、聊天记录库。
- **NetCare 业务库**：平台启用数字人基座时，测试只读转发和写语句拒绝；未启用时标为跳过。

注意：
- 「localStorage 跨刷新保留」首次自检会显示「首次打开」，刷新页面后再自检，次数应累加。
- 崩溃重启测试会让进程退出，所以不放在一键自检里，请到「代理与网络」手动触发。

## 本地开发

```bash
pip install -r requirements.txt
python run.py
```

本地运行时没有平台的数据接口和用户头，数据库和身份相关的检查会失败，这是预期的。
