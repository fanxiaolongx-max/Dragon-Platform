# Independent AI model connections

AiOps-Report can use the embedded ADC page or an independently configured HTTP/HTTPS model service. Open **AI 模型** on the report toolbar, or **开发者模式 → 工具 → AI 模型配置**. Create a profile, test it, then save and select it. Saving alone does not change the selected channel. Multiple profiles can be retained; the active profile is shared by the report and Dragon Claw in this application database. A different data environment has its own profiles.

Supported text protocols:

| Protocol | API root example | Inference path |
| --- | --- | --- |
| OpenAI / compatible | `https://api.openai.com/v1` | `/chat/completions` |
| OpenAI Responses | `https://api.openai.com/v1` | `/responses` |
| Anthropic Messages | `https://api.anthropic.com/v1` | `/messages` |
| Gemini GenerateContent | `https://generativelanguage.googleapis.com/v1beta` | `/models/{model}:generateContent` |
| Ollama | `http://127.0.0.1:11434` | `/api/chat` |
| Custom HTTP JSON | Full endpoint URL | Configured URL, POST JSON |

An existing full inference URL is accepted without duplicating its suffix. For OpenAI/Responses/Anthropic, a bare host defaults to `/v1`; Gemini defaults to `/v1beta`. Gateway subpaths are preserved. Select the actual wire protocol: many local models, DeepSeek/Qwen gateways, and proxy services expose the OpenAI-compatible protocol. Model IDs are entered explicitly, so the application does not assume a provider's current model list. HTTP addresses and private-network IPs are supported. `127.0.0.1` refers to the **application server/container**, not the user's browser. In a container, use the model service's reachable host/address.

Authentication options: Bearer, `x-api-key`, `api-key`, `x-goog-api-key`, none, or a custom header name. Extra headers, body parameters, and custom templates are supported. Values in extra body override default fields; `null` omits unsupported fields (e.g. `{"temperature":null,"max_tokens":null,"max_completion_tokens":8000}` for a compatible model that requires that parameter). Additional headers and body/template data are encrypted along with the API Key and are not returned to the browser. An empty field retains the saved value; an explicit `{}` clears an advanced JSON field. Use **清除已保存的 Key** to remove the key.

Custom example (full endpoint `http://inference.internal/api/generate`):

```json
{"model":"${model}","messages":"${messages}","prompt":"${prompt}","max_tokens":"${max_tokens}"}
```

Exact placeholder values retain their JSON type (`${messages}` is an array, `${max_tokens}` is a number). Other supported placeholders: `${system}` and `${temperature}`. Use a dotted response path such as `data.answer` or `choices.0.message.content`. Custom support covers synchronous POST/JSON text services; it does not automatically implement proprietary signatures, binary protocols, WebSockets, or cloud IAM signing.

## Compare model performance

Select the model and ask the same question in a fresh chat for each run. In **Developer → Tools → Interaction log**, search `MODEL-INVOKE` and expand an entry. **Export JSON** refreshes the current filter and includes these server-side events in the same interaction log. The same marker is written to the service console, but this export does not contain the raw console file. A matching request ID links the server row and browser trace.

- The request and observed thinking are separate. For Gemini, add e.g. `{"generationConfig":{"thinkingConfig":{"thinkingLevel":"HIGH"}}}` to **Extra request parameters JSON** if supported by the selected model, or use its supported `thinkingBudget`. For Qwen gateways supporting it, use `{"enable_thinking":true}`. Request flags do not prove that a provider ran a thinking phase.
- Native Gemini reads `candidatesTokenCount` for the answer and `thoughtsTokenCount` for thinking; the two sum to generated tokens when both are reported. OpenAI-compatible completion usage is the generated total; when reasoning usage is available, subtract it from the provider's text token count (or the text-only output total) for the answer.
- Missing metrics remain null, including a missing thinking count. Explicit zero stays zero. End-to-end rates divide reported tokens by the complete model round trip; for example, 310 generated tokens in 8282 ms is 37.43 tok/s. This includes queueing and network time and is not an independent thinking/decode speed. Provider generation duration/rate is shown separately only when available. No raw thought text is needed to measure this.

## Persistence and deployment

In 1.8.6, cell summaries request at most 4000 output tokens instead of inheriting a potentially larger profile budget. The profile limit still applies; explicit advanced body parameters retain their override behavior. OpenAI-compatible gateways that return SSE despite `stream:false` are supported, including usage and termination checks. Empty responses, gateway HTML and malformed structures remain errors. Failure diagnostics contain only a generated request ID, protocol, numeric output limits, upstream HTTP status, media type, response byte count and elapsed time; headers and raw provider bodies are not logged. Model transport failures stop recipe repair loops, retaining computed cell content. No schema migration is needed for this patch.

`db/init.sql` / `db/init.sqlite.sql` create `t_ai_model_config` and `t_ai_model_state` on a fresh import. `db/upgrade.sql` / `db/upgrade.sqlite.sql` add the same tables to existing applications. All are idempotent and preserve existing monthly reports. Deploy the SQL using the base's package initialization/upgrade mechanism (or the local platform's **升级应用表（模拟基座 DBA）** menu). Runtime model APIs use the existing application-schema REST access layer, never direct DB connections or business-schema writes. When both new tables are absent, older installations keep using ADC and the settings UI requests migration before saving models. Other database failures are not silently routed to ADC. The application does not create tables during a model request.

Every profile, including all credentials and advanced fields, is encrypted with Fernet authenticated encryption **before** it is written to the application database. Read APIs return only whitelisted public fields and `has_*` flags, never ciphertext, the API Key, secret headers, or the encryption key. A saved key cannot be revealed in the UI. Test requests can use an unsaved draft and do not persist it.

The master key is separate from the DB:

- Set `AI_MODEL_ENCRYPTION_KEY` as a private **process environment variable**, using a Fernet key generated by `python -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())'`.
- Otherwise the server atomically generates a 0600 file under `~/.aiops-report/keys/<application-identity-hash>.key`. `AI_MODEL_KEY_FILE` can point to a path on a **persistent volume**. App source updates do not replace this file.
- Back up this key independently with the application database. For container replacement or server migration, restore the same key or inject it as a process variable. Without the original key existing profiles cannot be decrypted; they are marked locked instead of silently overwritten. This differs from merely restarting the same process.
- Do not put the master key in the public source `.env`, a Git commit, or a release ZIP. The release builder refuses unsupported keys in the tracked `.env`, and excludes key files, runtime DBs and credentials. The packages include the `cryptography` dependency declaration; an offline base must provide/install it along with the existing Python requirements.

## Calls, isolation, and cancellation

Model calls originate on the application server. Browser mixed-content/CORS restrictions therefore do not prevent an HTTPS app from calling an internal HTTP model. Requests use a dedicated HTTP client: no inherited base identity headers/cookies, no automatic redirects, and no automatic model retries. TLS verification defaults to enabled and can be explicitly disabled for a configured self-signed internal endpoint. HTTP itself provides no transport encryption.

Each operation pins the selected profile ID and revision. Changing a profile causes subsequent calls from an old operation to stop with a revision conflict. The settings UI blocks saving/switching during active tasks in that page. Model contexts are separate for independent owners/operations and are reset when changing channels; the common queue retains the existing cell isolation and tracing behavior.

The model receives the application's existing JSON tool instructions. It cannot execute tools by itself; the browser routes allowed actions through the app's existing `agent/execute` validation and allocated app/business database boundaries. Native/provider-managed tools and remote persistent conversations are not enabled by profile parameters. For Responses requests, storage is disabled by default.

Stop uses the current task's AbortSignal, ignores late results, cancels the backend's pending upstream HTTP work after a client disconnect, and prevents follow-up model calls. A provider may already be computing an accepted request; closing HTTP does not certify that the provider stopped billing/computation. Long generations use a configurable 5–600 second timeout. Current adapters receive complete JSON responses (not incremental text streaming); progress and the Stop action remain available. Image/audio generation is outside this text-model feature.

Model errors report HTTP status and an app-generated request ID without echoing raw provider error bodies or authentication data. Response size is bounded to 4 MB, and truncated outputs are rejected instead of being saved as valid recipes.

Protocol references: [Anthropic Messages](https://platform.claude.com/docs/en/api/messages/create), [Gemini GenerateContent](https://ai.google.dev/api/generate-content), [Ollama Chat](https://docs.ollama.com/api/chat), [OpenAI Responses](https://platform.openai.com/docs/api-reference/responses).
