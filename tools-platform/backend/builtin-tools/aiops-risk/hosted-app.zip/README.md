# AiOps-Risk 风险管理看板

基于基座平台 V4.1 样例工程规范改造的风险管理看板（线上库模式）。

## 功能

- **筛选联动**：基准月 / ICT场景 / 地区部 / 代表处 / 国家 / 网络 / 产品线 / 级别 / 大T / NA级别 / 运营商&企业风险类型 / 创建&应关闭月份区间，共 16 项筛选项，实时联动 KPI + 三图 + 详细进展。
- **概览 KPI**：风险数、中高风险数、中高风险处置完成率、临期未处置中高风险数、已逾期未处置中高风险数、中高风险清理完成率。
- **三图**：风险数量-地区部 / 级别 / 产品线（处置 / 清理双模式切换，中高风险数 + 已处置/已关闭双柱）。
- **趋势图**：近 12 月全量「风险数量 & 完成率」，处置 / 清理双模式（中高风险数 + 超期未处置/清理双柱 + 完成率折线）。
- **详细进展**：5 个维度 Tab（地区部 / 代表处-办事处-网络 / 代表处-办事处-子网和NA / 大T-NA级别 / 产品线），分页 + 全量汇总行。
- **口径**：严格按《风险模块指标字典》校准（处置/清理状态精确集、逾期/临期/及时等实时口径）。

## 目录结构

```
AiOps-Risk/
├── run.py                    # 启动入口（uvicorn）
├── AiOps-Risk.version        # 版本号
├── requirements.txt          # Python 依赖
├── .env / .env.example       # 本地配置 / 环境变量模板
├── .gitignore                # 不入库项
├── app/                      # 后端（FastAPI + 基座 API）
│   ├── main.py               # 应用工厂：路由/静态/CORS/异常
│   ├── config.py             # pydantic-settings 配置（.env 注入）
│   ├── db.py                 # 数据访问层（query_business 走基座 REST API）
│   ├── core/                 # 异常 / 统一响应 / loguru 日志
│   └── routers/
│       ├── health.py         # /api/healthz 探活
│       └── risk.py           # 风险管理看板接口
├── static/                   # 前端纯静态（HTML + CSS + JS + ECharts 本地）
│   ├── index.html
│   ├── css/index.css
│   └── js/{api,theme,charts,risk}.js + echarts.min.js
├── db/                       # 建表脚本（本工程只读，占位）
├── tests/                    # 单元测试
└── scripts/build.py          # 打包脚本
```

## 数据访问（线上库模式）

- 数据查询走基座 REST API（`query_business`，按 `BUSINESS_DATASOURCE_NAME` 路由业务只读库），**代码中不出现数据库账号密码**。
- 主表：`OP_IOC_RISK_TASK_DTL_D_DWD`（风险管理详单表，归一化 CNBG+EBG）。
- `trust_env=False` + `verify=False`（基座自签证书，避免系统代理干扰）。
- 指标口径常量与聚合 SQL 见 `app/routers/risk.py`。

## 启动

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置
cp .env.example .env   # 填写 BASE_QUERY_URL / BUSINESS_DATASOURCE_NAME 等

# 3. 运行
python run.py          # 或 uvicorn app.main:app --port 5400 --reload
```

浏览器访问 `http://localhost:5400/`；接口文档 `http://localhost:5400/docs`；健康检查 `GET /api/healthz`。

## 接口一览

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/healthz` | 健康检查 |
| GET | `/api/filters` | 筛选项 distinct 值 + 基准月 + 维度名称映射 |
| GET | `/api/dashboard` | KPI + 三图 + 全量趋势（筛选联动） |
| GET | `/api/detail` | 详细进展 5 维 Tab 分页明细 + 汇总 |

统一响应体 `{code, message, data, total, elapsed_ms, cache_hit}`。

## 打包

```bash
python scripts/build.py   # 生成 AiOps-Risk-<version>.zip（含 MD5）
```
