# -*- coding: utf-8 -*-
"""打包脚本：读取版本号、白名单打包、排除缓存/日志/敏感文件、生成 MD5 校验。

用法：python scripts/build.py
产物：../dist/AiOps-Risk-<version>.zip  + 同名 .md5
"""
import hashlib
import os
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VERSION_FILE = os.path.join(ROOT, "AiOps-Risk.version")
DIST_DIR = os.path.join(ROOT, "dist")

# 白名单：仅打包以下顶层目录/文件
TOP_WHITELIST = {"app", "static", "db", "tests", "scripts"}
TOP_FILES = {"run.py", "requirements.txt", ".env.example", "README.md", "AiOps-Risk.version"}

# 排除规则（目录名 / 扩展名）
EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".codegraph", "logs", "dist", ".git"}
EXCLUDE_EXTS = {".pyc", ".pyo", ".log", ".err", ".env"}


def read_version():
    try:
        with open(VERSION_FILE, "r", encoding="utf-8") as f:
            return f.read().strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def eligible(path):
    rel = os.path.relpath(path, ROOT)
    parts = rel.split(os.sep)
    # 排除敏感/缓存文件
    if any(p in EXCLUDE_DIRS for p in parts):
        return False
    if os.path.splitext(rel)[1].lower() in EXCLUDE_EXTS:
        return False
    if os.path.basename(rel) == ".env":
        return False
    return True


def collect():
    files = []
    # 顶层白名单目录
    for d in TOP_WHITELIST:
        p = os.path.join(ROOT, d)
        if not os.path.isdir(p):
            continue
        for r, _, fs in os.walk(p):
            for f in fs:
                fp = os.path.join(r, f)
                if eligible(fp):
                    files.append(fp)
    # 顶层白名单文件
    for f in TOP_FILES:
        fp = os.path.join(ROOT, f)
        if os.path.isfile(fp) and eligible(fp):
            files.append(fp)
    # 排除打包脚本自身所在 scripts 里的中间产物不再重复（collect 已覆盖）
    return files


def md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    os.makedirs(DIST_DIR, exist_ok=True)
    version = read_version()
    out_zip = os.path.join(DIST_DIR, f"AiOps-Risk-{version}.zip")
    files = collect()

    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for fp in files:
            arcname = os.path.relpath(fp, ROOT)
            z.write(fp, arcname)

    dig = md5(out_zip)
    with open(out_zip + ".md5", "w", encoding="utf-8") as f:
        f.write(f"{dig}  {os.path.basename(out_zip)}\n")

    print(f"打包完成：{out_zip}")
    print(f"文件数：{len(files)}  MD5：{dig}")


if __name__ == "__main__":
    main()
