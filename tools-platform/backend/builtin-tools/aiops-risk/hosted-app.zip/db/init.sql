-- ============================================================
-- AiOps-Risk 风险服务 — 数据库初始化脚本
-- 适用基座 schema 模式：基座会自动将裸表名限定为 `schema`.`表名`
-- 因此本脚本中直接写裸表名，不带 schema 前缀
--
-- 执行方式：由 DBA 在 MySQL 服务器上手动执行
--   mysql -h <host> -P 3306 -u<user> -p <database> < db/init.sql
--
-- 特性：DROP IF EXISTS + CREATE，幂等可重复执行
-- ============================================================

START TRANSACTION;

-- -----------------------------------------------------------
-- 0. 备份（保留旧数据，便于回滚）
-- -----------------------------------------------------------
DROP TABLE IF EXISTS risk_task_bak;
DROP TABLE IF EXISTS risk_log_bak;
DROP TABLE IF EXISTS audit_log_bak;
DROP TABLE IF EXISTS risk_rule_bak;

CREATE TABLE IF NOT EXISTS risk_task_bak AS SELECT * FROM risk_task WHERE 1=1;
CREATE TABLE IF NOT EXISTS risk_log_bak  AS SELECT * FROM risk_log  WHERE 1=1;
CREATE TABLE IF NOT EXISTS audit_log_bak AS SELECT * FROM audit_log WHERE 1=1;
CREATE TABLE IF NOT EXISTS risk_rule_bak AS SELECT * FROM risk_rule WHERE 1=1;

-- -----------------------------------------------------------
-- 1. risk_task — 风险任务表
--    记录每一条风险事件（人工录入 / 阈值自动触发）
-- -----------------------------------------------------------
DROP TABLE IF EXISTS risk_task;
CREATE TABLE risk_task (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    risk_domain     VARCHAR(32)  NOT NULL                COMMENT '风险域：网上问题/网络变更/网络风险/维护人员/氛围建设',
    risk_level      VARCHAR(16)  NOT NULL                COMMENT '提醒级别：红牌/黄牌/不发牌',
    description     TEXT         NULL                    COMMENT '风险描述：内容、当前数值、阈值、影响范围',
    org_code        VARCHAR(32)  NULL                    COMMENT '组织编码，如 ORG-001',
    indicator_name  VARCHAR(128) NULL                    COMMENT '关联指标名称，如：派单及时率',
    status          VARCHAR(20)  NOT NULL DEFAULT 'notified' COMMENT '状态：notified待认领/acked处置中/escalated已升级/closed已闭环',
    source          VARCHAR(16)  NOT NULL DEFAULT 'manual' COMMENT '来源：manual人工录入/auto阈值自动触发',
    dedup_key       VARCHAR(128) NULL                    COMMENT '幂等键（30min 内同类去重）',
    handler         VARCHAR(64)  NULL                    COMMENT '处理人',
    create_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建单时间',
    ack_time        DATETIME     NULL                    COMMENT '认领时间',
    close_time      DATETIME     NULL                    COMMENT '闭环时间',
    escalate_time   DATETIME     NULL                    COMMENT '升级时间',
    update_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    INDEX idx_status (status),
    INDEX idx_domain_level (risk_domain, risk_level),
    INDEX idx_create_time (create_time),
    INDEX idx_dedup (dedup_key, create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='风险任务表 — 记录风险事件处理明细';


-- -----------------------------------------------------------
-- 2. risk_log — 风险处置日志表
--    记录每条风险的状态流转轨迹（建单→提醒→认领→闭环→升级）
-- -----------------------------------------------------------
DROP TABLE IF EXISTS risk_log;
CREATE TABLE risk_log (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    task_id         BIGINT       NOT NULL                COMMENT '关联 risk_task.id',
    action          VARCHAR(20)  NOT NULL                COMMENT '操作：create建单/notify提醒/ack认领/close闭环/escalate升级',
    operator        VARCHAR(64)  NULL                    COMMENT '操作人',
    remark          VARCHAR(512) NULL                    COMMENT '备注',
    create_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
    PRIMARY KEY (id),
    INDEX idx_task_id (task_id),
    INDEX idx_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='风险处置日志表 — 记录状态流转轨迹';


-- -----------------------------------------------------------
-- 3. audit_log — 审计日志表
--    通用操作审计记录（健康检查、配置变更等）
-- -----------------------------------------------------------
DROP TABLE IF EXISTS audit_log;
CREATE TABLE audit_log (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    msg             VARCHAR(512) NOT NULL                COMMENT '审计消息',
    operator        VARCHAR(64)  NULL                    COMMENT '操作人',
    source          VARCHAR(32)  NULL                    COMMENT '来源：health/api/system',
    create_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录时间',
    PRIMARY KEY (id),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='审计日志表';


-- -----------------------------------------------------------
-- 4. risk_rule — 风险扣分规则表
--    记录各类风险的扣分与清除规则
-- -----------------------------------------------------------
DROP TABLE IF EXISTS risk_rule;
CREATE TABLE risk_rule (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    rule_name       VARCHAR(128) NOT NULL                COMMENT '规则名称，如：变更倒回回溯>10工作日',
    risk_domain     VARCHAR(32)  NOT NULL                COMMENT '风险域',
    indicator_name  VARCHAR(128) NULL                    COMMENT '关联指标',
    threshold_desc  VARCHAR(256) NULL                    COMMENT '阈值描述，如：>10工作日 / <80%',
    score           INT          NOT NULL DEFAULT 0      COMMENT '扣分值',
    clear_type      VARCHAR(20)  NOT NULL DEFAULT 'auto'  COMMENT '清除类型：auto自动清除/manual人工清除/next_month次月清除',
    clear_condition VARCHAR(256) NULL                    COMMENT '清除条件描述',
    enabled         TINYINT(1)   NOT NULL DEFAULT 1      COMMENT '是否启用：1启用/0禁用',
    create_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    INDEX idx_domain (risk_domain),
    INDEX idx_enabled (enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='风险扣分规则表';


-- -----------------------------------------------------------
-- 5. 初始化数据：风险扣分规则
-- -----------------------------------------------------------
INSERT INTO risk_rule (rule_name, risk_domain, indicator_name, threshold_desc, score, clear_type, clear_condition) VALUES
('变更倒回回溯>10工作日',     '网络变更', '变更倒回回溯',     '>10工作日',         5,  'auto',       '倒回回溯单闭环后扣分自动清除'),
('派单及时率<80%',             '网上问题', '派单及时率',       '<80%',              3,  'auto',       '达标80%后扣分自动清除'),
('疲劳驾驶预警',               '维护人员', '疲劳驾驶',         '触发即扣分',         2,  'next_month', '触发后下月扣分自动清除'),
('TD/PM审批名单未刷新',       '氛围建设', 'TD审批名单',       '名单未刷新',         1,  'manual',     '刷新名单后CPT任务闭环即清除')
ON DUPLICATE KEY UPDATE update_time = NOW();

COMMIT;


-- ============================================================
-- 验证 SQL（执行后应得到如下列数）
-- ============================================================
-- SELECT table_name, COUNT(*) AS col_count
--   FROM information_schema.columns
--  WHERE table_schema = DATABASE()
--    AND table_name IN ('risk_task','risk_log','audit_log','risk_rule')
--  GROUP BY table_name;
-- 预期：
--   risk_task   15
--   risk_log     6
--   audit_log    5
--   risk_rule   11


-- ============================================================
-- 回滚脚本（如需恢复到执行前状态）
-- ============================================================
-- START TRANSACTION;
-- DROP TABLE IF EXISTS risk_task;
-- DROP TABLE IF EXISTS risk_log;
-- DROP TABLE IF EXISTS audit_log;
-- DROP TABLE IF EXISTS risk_rule;
-- RENAME TABLE risk_task_bak   TO risk_task;
-- RENAME TABLE risk_log_bak    TO risk_log;
-- RENAME TABLE audit_log_bak   TO audit_log;
-- RENAME TABLE risk_rule_bak   TO risk_rule;
-- COMMIT;
