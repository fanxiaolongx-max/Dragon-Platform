-- ============================================================
-- AiOps-Risk 风险服务 — SQLite 初始化脚本
-- ============================================================

CREATE TABLE IF NOT EXISTS risk_task (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    risk_domain     TEXT NOT NULL,
    risk_level      TEXT NOT NULL,
    description     TEXT,
    org_code        TEXT,
    indicator_name  TEXT,
    status          TEXT NOT NULL DEFAULT 'notified',
    source          TEXT NOT NULL DEFAULT 'manual',
    dedup_key       TEXT,
    handler         TEXT,
    create_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ack_time        DATETIME,
    close_time      DATETIME,
    escalate_time   DATETIME,
    update_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_risk_task_status ON risk_task (status);
CREATE INDEX IF NOT EXISTS idx_risk_task_domain_level ON risk_task (risk_domain, risk_level);
CREATE INDEX IF NOT EXISTS idx_risk_task_create_time ON risk_task (create_time);
CREATE INDEX IF NOT EXISTS idx_risk_task_dedup ON risk_task (dedup_key, create_time);

CREATE TABLE IF NOT EXISTS risk_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id         INTEGER NOT NULL,
    action          TEXT NOT NULL,
    operator        TEXT,
    remark          TEXT,
    create_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_risk_log_task_id ON risk_log (task_id);
CREATE INDEX IF NOT EXISTS idx_risk_log_action ON risk_log (action);

CREATE TABLE IF NOT EXISTS audit_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    msg             TEXT NOT NULL,
    operator        TEXT,
    source          TEXT,
    create_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_log_create_time ON audit_log (create_time);

CREATE TABLE IF NOT EXISTS risk_rule (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_name       TEXT NOT NULL,
    risk_domain     TEXT NOT NULL,
    indicator_name  TEXT,
    threshold_desc  TEXT,
    score           INTEGER NOT NULL DEFAULT 0,
    clear_type      TEXT NOT NULL DEFAULT 'auto',
    clear_condition TEXT,
    enabled         INTEGER NOT NULL DEFAULT 1,
    create_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_risk_rule_domain ON risk_rule (risk_domain);
CREATE INDEX IF NOT EXISTS idx_risk_rule_enabled ON risk_rule (enabled);

INSERT OR REPLACE INTO risk_rule (id, rule_name, risk_domain, indicator_name, threshold_desc, score, clear_type, clear_condition) VALUES
(1, '变更倒回回溯>10工作日',     '网络变更', '变更倒回回溯',     '>10工作日',         5,  'auto',       '倒回回溯单闭环后扣分自动清除'),
(2, '派单及时率<80%',             '网上问题', '派单及时率',       '<80%',              3,  'auto',       '达标80%后扣分自动清除'),
(3, '疲劳驾驶预警',               '维护人员', '疲劳驾驶',         '触发即扣分',         2,  'next_month', '触发后下月扣分自动清除'),
(4, 'TD/PM审批名单未刷新',       '氛围建设', 'TD审批名单',       '名单未刷新',         1,  'manual',     '刷新名单后CPT任务闭环即清除');
