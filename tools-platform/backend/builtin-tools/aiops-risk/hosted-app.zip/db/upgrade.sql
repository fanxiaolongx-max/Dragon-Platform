-- ============================================================
-- AiOps-Risk 风险服务 — 数据库升级脚本
-- 作用：将 risk_task / risk_log 两张表的结构对齐 init.sql 设计稿
-- 背景：基座 API（POST /query /execute）禁止 DDL，仅允许 INSERT/UPDATE/DELETE，
--       因此本脚本必须由 DBA 在 MySQL 服务器（7.180.143.136:3306/netcare）上手动执行。
-- 影响：risk_task / risk_log 当前 0 行数据，DROP 重建无数据损失。
-- 执行前自检：
--   SELECT COUNT(*) FROM risk_task;  -- 应为 0
--   SELECT COUNT(*) FROM risk_log;   -- 应为 0
-- ============================================================

-- -----------------------------------------------------------
-- 0. 安全开关：事务包裹，出错即回滚
-- -----------------------------------------------------------
START TRANSACTION;

-- -----------------------------------------------------------
-- 1. 备份（空表也备份，保留习惯）
-- -----------------------------------------------------------
DROP TABLE IF EXISTS risk_task_bak;
DROP TABLE IF EXISTS risk_log_bak;
CREATE TABLE risk_task_bak AS SELECT * FROM risk_task;
CREATE TABLE risk_log_bak  AS SELECT * FROM risk_log;

-- -----------------------------------------------------------
-- 2. 重建 risk_task — 风险任务表（15 列）
-- -----------------------------------------------------------
DROP TABLE IF EXISTS risk_task;
CREATE TABLE risk_task (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    risk_domain     VARCHAR(32)  NOT NULL                COMMENT '风险域：网上问题/网络变更/网络风险/维护人员/氛围建设',
    risk_level      VARCHAR(16)  NOT NULL                COMMENT '提醒级别：红牌/黄牌/不发牌',
    description     TEXT         NULL                    COMMENT '风险描述：内容、当前数值、阈值、影响范围',
    org_code        VARCHAR(32)  NULL                    COMMENT '组织编码，如 ORG-001',
    indicator_name  VARCHAR(128) NULL                    COMMENT '关联指标名称，如：派单及时率',
    status          VARCHAR(20)  NOT NULL DEFAULT 'notified' COMMENT '状态：notified待认领/acked处置中/escalated已升级/closed已闭环',
    source          VARCHAR(16)  NOT NULL DEFAULT 'manual' COMMENT '来源：manual人工录入/auto阈值自动触发',
    dedup_key       VARCHAR(128) NULL                    COMMENT '幂等键（30min 内同类去重）',
    handler         VARCHAR(64)  NULL                    COMMENT '处理人',
    create_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建单时间',
    ack_time        DATETIME     NULL                    COMMENT '认领时间',
    close_time      DATETIME     NULL                    COMMENT '闭环时间',
    escalate_time   DATETIME     NULL                    COMMENT '升级时间',
    update_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    INDEX idx_status (status),
    INDEX idx_domain_level (risk_domain, risk_level),
    INDEX idx_create_time (create_time),
    INDEX idx_dedup (dedup_key, create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='风险任务表 — 记录风险事件处理明细';

-- -----------------------------------------------------------
-- 3. 重建 risk_log — 风险处置日志表（6 列）
-- -----------------------------------------------------------
DROP TABLE IF EXISTS risk_log;
CREATE TABLE risk_log (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    task_id         BIGINT       NOT NULL                COMMENT '关联 risk_task.id',
    action          VARCHAR(20)  NOT NULL                COMMENT '操作：create建单/notify提醒/ack认领/close闭环/escalate升级',
    operator        VARCHAR(64)  NULL                    COMMENT '操作人',
    remark          VARCHAR(512) NULL                    COMMENT '备注',
    create_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
    PRIMARY KEY (id),
    INDEX idx_task_id (task_id),
    INDEX idx_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='风险处置日志表 — 记录状态流转轨迹';

-- -----------------------------------------------------------
-- 4. 验证：执行后应返回如下结构
-- -----------------------------------------------------------
-- SELECT COLUMN_NAME, DATA_TYPE FROM information_schema.columns
--  WHERE table_schema = DATABASE() AND table_name = 'risk_task'
--  ORDER BY ORDINAL_POSITION;
-- 预期 15 行：id, risk_domain, risk_level, description, org_code, indicator_name,
--            status, source, dedup_key, handler, create_time, ack_time,
--            close_time, escalate_time, update_time

-- SELECT COLUMN_NAME, DATA_TYPE FROM information_schema.columns
--  WHERE table_schema = DATABASE() AND table_name = 'risk_log'
--  ORDER BY ORDINAL_POSITION;
-- 预期 6 行：id, task_id, action, operator, remark, create_time

COMMIT;

-- ============================================================
-- 回滚脚本（如需撤销升级）
-- ============================================================
-- START TRANSACTION;
-- DROP TABLE IF EXISTS risk_task;
-- DROP TABLE IF EXISTS risk_log;
-- RENAME TABLE risk_task_bak TO risk_task;
-- RENAME TABLE risk_log_bak  TO risk_log;
-- COMMIT;
