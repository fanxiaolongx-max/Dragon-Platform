# -*- coding: utf-8 -*-
"""统一配置：通过环境变量或 .env 文件注入，代码中不出现硬连接信息。"""
import os
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


def _read_version() -> str:
    version_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "AiOps-Risk.version")
    env = os.environ.get("APP_VERSION")
    if env:
        return env
    try:
        with open(version_file, "r", encoding="utf-8") as f:
            return f.read().strip() or "0.0.0"
    except OSError:
        return "0.0.0"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ---- 应用信息 ----
    APP_NAME: str = "AiOps-Risk"
    APP_VERSION: str = _read_version()
    DEBUG: bool = True

    # ---- 运行 ----
    WORKERS: int = 1
    RELOAD: bool = True
    PORT: int = 5400              # 主服务端口

    # ---- CORS ----
    CORS_ORIGINS: list[str] = [
        "http://localhost:5400",
        "http://127.0.0.1:5400",
    ]

    # ---- 分页 ----
    MAX_PAGE_SIZE: int = 1000
    DEFAULT_PAGE_SIZE: int = 50

    # ---- 风险管理看板基准月 ----
    # 看板 KPI/三图/详细进展的统计基准月；留空则取数据最新月份 MAX(period_month)
    RISK_BASE_MONTH: str = "2026-09"

    # ---- 基座 API 配置 ----
    # 基座数据查询接口基地址
    BASE_QUERY_URL: str = "https://netcareclaw-beta.icta138.huawei.com/digital-human/api/dh/query"
    # "应用数据库-自定义应用"数据源 ID
    APP_DATASOURCE_ID: int | str = "app"
    # 应用专属 schema（即应用 UUID）
    APP_SCHEMA: str = "5038d513-60cc-4d1a-bfb5-4ea812a5af97"
    # 业务数据库（BUSINESS）组名
    BUSINESS_DATASOURCE_NAME: str = "netcareClaw-operate-digital-readonly"

    # ---- HTTP 客户端 ----
    HTTP_TIMEOUT: int = 15          # 调用基座 API 超时(秒)
    HTTP_VERIFY_SSL: bool = False  # 基座自签证书，关闭校验


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
