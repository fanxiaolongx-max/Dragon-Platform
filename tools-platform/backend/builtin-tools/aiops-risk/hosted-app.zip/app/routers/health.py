# -*- coding: utf-8 -*-
"""健康检查路由"""
from fastapi import APIRouter

from app.core.response import ok
from app.db import check_base_api

router = APIRouter(tags=["健康检查"])


@router.get("/healthz")
async def healthz():
    """探活端点：基座 API 连通性"""
    api_ok = await check_base_api()
    return ok({
        "status": "ok" if api_ok else "fail",
    })
