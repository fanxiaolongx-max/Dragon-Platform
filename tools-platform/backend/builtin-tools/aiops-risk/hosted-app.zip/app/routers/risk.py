# -*- coding: utf-8 -*-
"""风险管理看板路由 — 数据查询接口（线上库模式）

数据来源：云端业务只读库（BUSINESS 数据源，datasourceName 路由）
主表：    OP_IOC_RISK_TASK_DTL_D_DWD（风险管理详单表，归一化 CNBG+EBG）
权威口径：按《风险模块指标字典》校准（见 gen_risk_rows_v4.py 同款口径）

接口：
  GET /api/filters    → 各筛选项 distinct 值 + 趋势月份 + 维度名称映射
  GET /api/dashboard  → KPI + 三图(地区部/级别/产品线) + 全量趋势（按筛选联动）
  GET /api/detail     → 详细进展 5 维 Tab 分页明细（带全量汇总行）

所有 SQL 聚合均在服务端完成，前端仅做展示。
筛选参数经白名单映射，防 SQL 注入。
"""
import json
import os
import time
import asyncio
from typing import Optional

from fastapi import APIRouter, Query

from app.core.response import ok
from app.db import query_business
from app.core.logger import logger
from app.config import settings

router = APIRouter(tags=["风险管理看板"])

# ---------------------------------------------------------------------------
# 内存缓存（TTL 10 分钟，按基准月维度缓存，避免重复查询基座 REST API）
# 符合样例工程规范：不引入 Redis 等外部依赖，用进程内字典 + 时间戳实现
# ---------------------------------------------------------------------------
_CACHE_TTL = 600  # 缓存有效期（秒）
_filters_cache: dict = {}      # {cache_key: (timestamp, data)}
_dyn_maps_cache: dict = {}     # {period_sql: (timestamp, maps)}


def _cache_get(cache: dict, key: str):
    """读取缓存，过期返回 None"""
    item = cache.get(key)
    if not item:
        return None
    ts, data = item
    if time.time() - ts > _CACHE_TTL:
        return None
    return data


def _cache_set(cache: dict, key: str, data):
    """写入缓存"""
    cache[key] = (time.time(), data)

# ---------------------------------------------------------------------------
# 权威口径（与《风险模块指标字典》/ gen_risk_rows_v4.py 一致）
# ---------------------------------------------------------------------------
# 处置完成态：CNBG + EBG 海外/中国区状态码并集归一化
DISP_SET = "'Risk Accepted','Risk+Accepted','Risk Closed','Risk+Closed','风险接受','已闭环','203','207','204','210'"
# 清理完成态（已关闭）
CLOSE_SET = "'Risk Closed','Risk+Closed','已闭环','203','207'"

DISPOSED = f"risk_status IN ({DISP_SET})"
CLOSED = f"risk_status IN ({CLOSE_SET})"
UNDISP = f"NOT ({DISPOSED})"
SEV_MH = "severity IN ('High','Middle')"
# 临期：now <= due <= now+7天
IMPENDING = f"{UNDISP} AND {SEV_MH} AND ticket_close_due_date >= NOW() AND ticket_close_due_date <= DATE_ADD(NOW(), INTERVAL 7 DAY)"
# 逾期：中高 + 未处置 + due < now
OVERDUE_UNDISP = f"{UNDISP} AND {SEV_MH} AND ticket_close_due_date < NOW()"
OVERDUE_UNCLEAR = f"NOT ({CLOSED}) AND {SEV_MH} AND ticket_close_due_date < NOW()"

# 名称映射常量（权威映射，与《风险模块指标字典》、dim_maps_v5.json 同款）
# 数据来源：云端业务只读库（query_business 走基座 REST API）
#   - region/na/pl/sev/bg：静态枚举，硬编码
#   - office/country/net/t1：动态 distinct 值，由 /filters 接口实时查询并返回 *_name 字典
#     · office: common_data_customer_rel_country_relation.repoffice_code -> repoffice_name_cn
#     · country: 海外用 common_data_customer_rel_country_relation.country_code -> country_name；
#               中国省份 CN-XX 用主表 rep_off 字段（EBG 中国区省份中文名）
#     · net:    主表 network_id -> network_name（一对多取首个非空）
#     · t1:     cs_nc_comm_customer_d_list.hq_cust_category_code -> hq_cust_category_cn_name
REGION_MAP = {
    "027425": "中国地区部", "072133": "A类区域管理部", "040593": "拉美地区部",
    "071217": "欧洲地区部", "077572": "海湾多国管理部", "077587": "中亚多国管理部",
    "025899": "南部非洲地区部", "050133": "亚太地区部", "049683": "B类区域工作组",
    "026902": "北部非洲地区部", "026876": "伊拉克代表处", "026850": "巴基斯坦代表处",
    "037370": "俄罗斯代表处", "026783": "沙特代表处",
}
PL_NAME = {"data_communication": "数通", "optical_business": "光网络", "wireless": "无线",
           "cloud_core_network": "云核心网", "data_storage": "数据存储", "software_business": "软件",
           "service_product": "服务产品", "computing": "计算", "other": "其它", "digital_power": "数字能源"}
SEV_NAME = {"High": "高", "Middle": "中", "Low": "低"}
NA_NAME = {"02": "A2", "03": "A3", "04": "A4", "09": "A9", "10": "A10", "12": "A12", "13": "A13"}
BG_NAME = {"CNBG": "运营商", "EBG": "政企"}

# 表名（大写以显式标注业务只读表）
RISK_TABLE = "OP_IOC_RISK_TASK_DTL_D_DWD"

# 动态映射查询 SQL（/filters 接口调用，结果填入 *_name 字典返回前端）
# 注：office/country/net/t1 的 distinct 值随基准月变化，不能硬编码；
#     这里仅提供查询 SQL，由 _load_dynamic_maps() 异步执行并合并
DYNAMIC_MAP_SQL = {
    # 代表处：repoffice_code -> repoffice_name_cn
    "office_name": (
        "SELECT DISTINCT t.repoffice_code AS k, r.repoffice_name_cn AS v "
        f"FROM {RISK_TABLE} t "
        "LEFT JOIN common_data_customer_rel_country_relation r ON t.repoffice_code = r.repoffice_code "
        "WHERE t.period_month = {period} AND t.repoffice_code IS NOT NULL AND t.repoffice_code<>'' "
        "AND r.repoffice_name_cn IS NOT NULL AND r.repoffice_name_cn<>''"
    ),
    # 国家（海外）：country_code -> country_name
    "country_name_overseas": (
        f"SELECT DISTINCT t.country_code AS k, r.country_name AS v "
        f"FROM {RISK_TABLE} t "
        "LEFT JOIN common_data_customer_rel_country_relation r ON t.country_code = r.country_code "
        "WHERE t.period_month = {period} AND t.country_code IS NOT NULL AND t.country_code<>'' "
        "AND t.country_code NOT LIKE 'CN-%' "
        "AND r.country_name IS NOT NULL AND r.country_name<>''"
    ),
    # 国家（中国省份 CN-XX）：country_code -> rep_off（主表内中文名）
    "country_name_cn": (
        f"SELECT country_code AS k, MIN(rep_off) AS v "
        f"FROM {RISK_TABLE} "
        "WHERE period_month = {period} AND country_code LIKE 'CN-%' "
        "AND rep_off IS NOT NULL AND rep_off<>'' "
        "GROUP BY country_code"
    ),
    # 网络：network_id -> network_name（主表内关联，取首个非空）
    "net_name": (
        f"SELECT network_id AS k, MIN(network_name) AS v "
        f"FROM {RISK_TABLE} "
        "WHERE period_month = {period} AND network_id IS NOT NULL AND network_id<>'' "
        "AND network_name IS NOT NULL AND network_name<>'' "
        "GROUP BY network_id"
    ),
    # 大T：主表内 t1_operator_code -> customer（客户名称，主表内关联，稳定可靠）
    # 注：优先用主表内 customer 字段；cs_nc_comm_customer_d_list 表在云端只读库可能不可访问
    "t1_name": (
        f"SELECT t1_operator_code AS k, MIN(customer) AS v "
        f"FROM {RISK_TABLE} "
        "WHERE period_month = {period} AND t1_operator_code IS NOT NULL AND t1_operator_code<>'' "
        "AND customer IS NOT NULL AND customer<>'' "
        "GROUP BY t1_operator_code"
    ),
}


async def _load_dynamic_maps(period_sql: str) -> dict:
    """根据基准月加载动态中文映射（office/country/net/t1）。
    period_sql: 已带引号的基准月 SQL 字面量（与 _resolve_month 返回值一致）。
    返回：{office_name, country_name, net_name, t1_name} 字典。

    优化（遵循样例工程规范，进程内缓存 + 并发查询）：
      1. 内存缓存 10 分钟（按基准月维度），避免重复查询基座 REST API
      2. asyncio.gather 并发执行 5 个映射查询（替代串行），缩短总耗时
      3. 单个查询失败不影响其他（gather return_exceptions=True）
    """
    # 1. 缓存命中直接返回
    cached = _cache_get(_dyn_maps_cache, period_sql)
    if cached is not None:
        logger.info(f"动态映射命中缓存 period={period_sql}")
        return cached

    async def _q(sql_tpl: str, retries: int = 1) -> list:
        """单次查询 + 失败重试 1 次（降低重试次数，避免雪崩）"""
        sql = sql_tpl.format(period=period_sql)
        last_exc = None
        for attempt in range(retries + 1):
            try:
                rows = await query_business(sql, 2000)
                return rows
            except Exception as exc:
                last_exc = exc
                if attempt < retries:
                    await asyncio.sleep(0.3)
        logger.warning(f"动态映射查询失败: {last_exc}")
        return []

    # 2. 并发执行 5 个映射查询（gather + return_exceptions 容错）
    results = await asyncio.gather(
        _q(DYNAMIC_MAP_SQL["office_name"]),
        _q(DYNAMIC_MAP_SQL["country_name_overseas"]),
        _q(DYNAMIC_MAP_SQL["country_name_cn"]),
        _q(DYNAMIC_MAP_SQL["net_name"]),
        _q(DYNAMIC_MAP_SQL["t1_name"]),
        return_exceptions=True,
    )
    # 3. 合并结果（容错：异常项返回空列表）
    def _safe(idx):
        r = results[idx]
        return r if isinstance(r, list) else []
    office_rows = _safe(0)
    country_overseas_rows = _safe(1)
    country_cn_rows = _safe(2)
    net_rows = _safe(3)
    t1_rows = _safe(4)

    maps = {"office_name": {}, "country_name": {}, "net_name": {}, "t1_name": {}}
    maps["office_name"] = {r["k"]: r["v"] for r in office_rows if r.get("k") and r.get("v")}
    country_map = {}
    country_map.update({r["k"]: r["v"] for r in country_overseas_rows if r.get("k") and r.get("v")})
    country_map.update({r["k"]: r["v"] for r in country_cn_rows if r.get("k") and r.get("v")})
    maps["country_name"] = country_map
    maps["net_name"] = {r["k"]: r["v"] for r in net_rows if r.get("k") and r.get("v")}
    t1_map = {r["k"]: r["v"] for r in t1_rows if r.get("k") and r.get("v")}
    t1_map["Others"] = "其他"
    maps["t1_name"] = t1_map
    logger.info(f"动态映射完成: office={len(maps['office_name'])} country={len(maps['country_name'])} "
                f"net={len(maps['net_name'])} t1={len(maps['t1_name'])}")
    # 4. 写入缓存
    _cache_set(_dyn_maps_cache, period_sql, maps)
    return maps
    return maps

# 筛选参数白名单：参数名 → 数据库列（防注入）
# 注：office 用 repoffice_code（代表处编码，CNBG 78 / EBG 54 均有值）；
#     rep_off 仅 EBG 中国区有中文文本且 CNBG 全空(25759行)，不可用于筛选。
FILTER_COLS = {
    "ict": "bg",
    "region": "region_code",
    "office": "repoffice_code",
    "country": "country_code",
    "net": "network_id",
    "pl": "product_line_map",
    "sev": "severity",
    "t1": "t1_operator_code",
    "na": "na_type",
}

# 筛选项 → 前端 buildOptions 期望的复数字段名（fd.regions / fd.offices / ...）
FILTER_PLURAL = {
    "region": "regions", "office": "offices", "country": "countries",
    "net": "nets", "pl": "pls", "sev": "sevs", "t1": "t1s", "na": "nas",
}


def _esc(v: str) -> str:
    """SQL 值转义（防注入兜底）"""
    return v.replace("'", "''").replace("\\", "\\\\")


def _resolve_month(params: dict) -> str:
    """解析统计基准月：请求参数 month > 配置 RISK_BASE_MONTH > 最新月份"""
    m = (params.get("month") or "").strip()
    if m:
        return f"'{_esc(m)}'"
    if settings.RISK_BASE_MONTH:
        return f"'{_esc(settings.RISK_BASE_MONTH)}'"
    return f"(SELECT MAX(period_month) FROM {RISK_TABLE})"


def _resolve_month_raw(params: dict) -> str:
    """基准月的裸值（不带引号/子查询；用于 Python 端月份偏移）"""
    m = (params.get("month") or "").strip()
    if m:
        return m
    if settings.RISK_BASE_MONTH:
        return settings.RISK_BASE_MONTH
    return ""


def _shift_month(month: str, delta: int) -> str:
    """月份偏移（Python 端计算，避免 DATE_SUB 处理 'YYYY-MM' 字符串时求值为 NULL）"""
    try:
        y, m = month.split("-")
        total = int(y) * 12 + (int(m) - 1) + delta
        yy, mm = divmod(total, 12)
        return f"{yy:04d}-{mm + 1:02d}"
    except Exception:
        return month


def _latest_month_sql() -> str:
    """(弃用保留) 取数据最新月份"""
    return f"(SELECT MAX(period_month) FROM {RISK_TABLE})"


def _month_filter_sql(params: dict) -> tuple:
    """根据请求参数生成 WHERE 片段列表（白名单映射）"""
    where = []
    for key, col in FILTER_COLS.items():
        v = (params.get(key) or "").strip()
        if v and v != "__all__":
            where.append(f"{col} = '{_esc(v)}'")
    # 风险类型（关联 bg + TYPE）
    optype = (params.get("optype") or "").strip()
    if optype:
        where.append(f"bg='CNBG' AND TYPE='{_esc(optype)}'")
    entype = (params.get("entype") or "").strip()
    if entype:
        where.append(f"bg='EBG' AND TYPE='{_esc(entype)}'")
    # 月份区间（创建 / 应关闭）
    cstart, cend = (params.get("cstart") or "").strip(), (params.get("cend") or "").strip()
    if cstart or cend:
        rng = []
        if cstart:
            rng.append(f"DATE_FORMAT(create_time,'%Y-%m') >= '{_esc(cstart)}'")
        if cend:
            rng.append(f"DATE_FORMAT(create_time,'%Y-%m') <= '{_esc(cend)}'")
        if rng:
            where.append("(" + " AND ".join(rng) + ")")
    sstart, send = (params.get("sstart") or "").strip(), (params.get("send") or "").strip()
    if sstart or send:
        rng = []
        if sstart:
            rng.append(f"DATE_FORMAT(COALESCE(close_time,ticket_close_due_date,expected_close_time),'%Y-%m') >= '{_esc(sstart)}'")
        if send:
            rng.append(f"DATE_FORMAT(COALESCE(close_time,ticket_close_due_date,expected_close_time),'%Y-%m') <= '{_esc(send)}'")
        if rng:
            where.append("(" + " AND ".join(rng) + ")")
    return where


def _base_from(params: dict, alias: str = "") -> str:
    """SELECT 的 FROM 与筛选 WHERE（共享查询骨架）"""
    period = _resolve_month(params)
    where = [f"period_month = {period}"]
    where += _month_filter_sql(params)
    a = f"{alias}." if alias else ""
    # 拼前缀：字段别名加前缀（detail 处用）
    return a, " AND ".join(where), where


# ---------------------------------------------------------------------------
# 查询辅助（聚合列表达式）
# ---------------------------------------------------------------------------

def _agg_exprs(prefix: str = "") -> str:
    """聚合列表达式（与 NetCare 参考页面 21 列对齐）。
    新增：高风险数/中风险数/低风险数/已挂起/及时处置数/超期已处置数。
    """
    p = (prefix + ".") if prefix else ""
    # 已挂起状态（进行中/待确认，未处置且未关闭）
    HANG_UP = f"NOT ({p}{DISPOSED}) AND NOT ({p}risk_status IN ({CLOSE_SET}))"
    # 及时处置：中高 + 已处置 + (accept_time < due 或 close_time < due)
    TIMELY_DISPOSED = (f"{p}{SEV_MH} AND {p}{DISPOSED} AND "
                       f"(({p}accept_time IS NOT NULL AND {p}accept_time < {p}ticket_close_due_date) "
                       f"OR ({p}close_time IS NOT NULL AND {p}close_time < {p}ticket_close_due_date))")
    # 超期已处置：中高 + 已处置 + due < now
    OVERDUE_DISPOSED = f"{p}{SEV_MH} AND {p}{DISPOSED} AND {p}ticket_close_due_date < NOW()"
    return (
        f"COUNT(*) AS risk_cnt,"
        f"SUM({p}{SEV_MH}) AS mh,"                                          # 中高风险数
        f"SUM({p}severity='High') AS high_risk_cnt,"                        # 高风险数
        f"SUM({p}severity='Middle') AS mid_risk_cnt,"                       # 中风险数
        f"SUM({p}severity='Low') AS low_risk_cnt,"                          # 低风险数
        f"SUM({p}{SEV_MH} AND {HANG_UP}) AS hang_up_cnt,"                   # 已挂起（中高未处置未关闭）
        f"SUM({p}{SEV_MH} AND {p}risk_status IN ({DISP_SET})) AS disposed," # 已处置
        f"SUM({p}{SEV_MH} AND {p}risk_status IN ({CLOSE_SET})) AS closed,"  # 已关闭
        f"SUM({p}{TIMELY_DISPOSED}) AS timely_disposed_cnt,"                # 及时处置数
        f"SUM({p}{OVERDUE_DISPOSED}) AS overdue_disposed_cnt,"              # 超期已处置数
        f"SUM({p}{SEV_MH} AND {p}NOT ({p}{DISPOSED}) AND {p}ticket_close_due_date >= NOW() "
        f"AND {p}ticket_close_due_date <= DATE_ADD(NOW(), INTERVAL 7 DAY)) AS impending,"
        f"SUM({p}NOT ({p}{DISPOSED}) AND {p}{SEV_MH} AND {p}ticket_close_due_date < NOW()) AS overdue_undisposed,"
        f"SUM({p}NOT ({p}risk_status IN ({CLOSE_SET})) AND {p}{SEV_MH} AND {p}ticket_close_due_date < NOW()) AS overdue_uncleared"
    )


# ---------------------------------------------------------------------------
# 路由
# ---------------------------------------------------------------------------

@router.get("/filters")
async def get_filters(month: Optional[str] = Query(None)):
    """筛选项 distinct 值 + 基准月 + 可选月份 + 维度名称映射。
    返回的 *_name 字典用于前端把下拉值（编码）渲染为中文名。

    优化（遵循样例工程规范，进程内缓存 + 并发查询）：
      1. 内存缓存 10 分钟（按基准月维度），避免重复查询基座 REST API
      2. asyncio.gather 并发执行 distinct 查询 + 动态映射（替代串行）
    """
    params = {"month": month or ""}
    period = _resolve_month(params)
    cache_key = f"filters:{period}"
    # 1. 缓存命中直接返回
    cached = _cache_get(_filters_cache, cache_key)
    if cached is not None:
        logger.info(f"filters 命中缓存 period={period}")
        return ok(cached)

    sub = f"WHERE period_month = {period}"

    # 2. distinct 查询保持串行（基座 REST API 对并发请求有限流，并发会触发限流导致失败）
    #    动态映射用 asyncio.gather 并发（JOIN 查询数量少，5 个并发基座可承受）
    async def _q_distinct(key, col):
        if key == "ict":
            return key, [["", "全部ICT场景"], ["CNBG", "运营商"], ["EBG", "政企"]]
        sql = f"SELECT DISTINCT {col} AS v FROM {RISK_TABLE} {sub} ORDER BY v"
        try:
            rows = await query_business(sql, 2000)
            return key, [r["v"] for r in rows if r.get("v") not in (None, "")]
        except Exception as exc:
            logger.warning(f"filters[{key}] 失败: {exc}")
            return key, []

    # 串行执行 distinct 查询（9 个）+ 类型 + 月份
    out = {}
    for key, col in FILTER_COLS.items():
        if key == "sep_skip":
            continue
        k, vals = await _q_distinct(key, col)
        if key == "ict":
            out["ict"] = vals
        else:
            out[FILTER_PLURAL.get(key, key)] = vals

    # 风险类型（串行）
    try:
        type_cond = "AND TYPE IS NOT NULL AND TYPE<>''"
        rg = await query_business(
            f"SELECT DISTINCT bg, TYPE AS v FROM {RISK_TABLE} {sub} "
            f"{type_cond} ORDER BY bg, v", 2000)
    except Exception as exc:
        logger.warning(f"filters[type] 失败: {exc}")
        rg = []
    optype, entype = [], []
    for r in rg:
        item = (r.get("v") or "").strip()
        if not item:
            continue
        (optype if r.get("bg") == "CNBG" else entype).append(item)
    out["optype"] = optype
    out["entype"] = entype

    # 月份（串行）
    try:
        mm = await query_business(
            f"SELECT DISTINCT period_month AS m FROM {RISK_TABLE} ORDER BY m DESC LIMIT 24", 30)
    except Exception as exc:
        logger.warning(f"filters[months] 失败: {exc}")
        mm = []
    out["months"] = [r["m"] for r in mm]
    out["base_month"] = (params["month"] or settings.RISK_BASE_MONTH or (out["months"][0] if out["months"] else ""))

    # 静态名称映射（硬编码枚举）
    out["region_name"] = REGION_MAP
    out["pl_name"] = PL_NAME
    out["sev_name"] = SEV_NAME
    out["na_name"] = NA_NAME
    out["bg_name"] = BG_NAME

    # 动态名称映射（并发执行 5 个 JOIN 查询，基座可承受）
    dyn_maps = await _load_dynamic_maps(period)
    out["office_name"] = dyn_maps.get("office_name", {})
    out["country_name"] = dyn_maps.get("country_name", {})
    out["net_name"] = dyn_maps.get("net_name", {})
    out["t1_name"] = dyn_maps.get("t1_name", {})

    # 3. 写入缓存
    _cache_set(_filters_cache, cache_key, out)
    return ok(out)


@router.get("/dashboard")
async def get_dashboard(
    ict: Optional[str] = Query(None), region: Optional[str] = Query(None),
    office: Optional[str] = Query(None), country: Optional[str] = Query(None),
    net: Optional[str] = Query(None), pl: Optional[str] = Query(None),
    sev: Optional[str] = Query(None), t1: Optional[str] = Query(None),
    na: Optional[str] = Query(None), optype: Optional[str] = Query(None),
    entype: Optional[str] = Query(None), cstart: Optional[str] = Query(None),
    cend: Optional[str] = Query(None), sstart: Optional[str] = Query(None),
    send: Optional[str] = Query(None), month: Optional[str] = Query(None),
):
    """KPI + 三图 + 全量趋势（筛选联动）。
    优化（遵循样例工程规范）：
      1. 内存缓存 10 分钟（按筛选条件 hash 缓存）
      2. asyncio.gather 并发执行 KPI + 3 图表 + 趋势查询（替代串行）
    """
    params = {
        "ict": ict or "", "region": region or "", "office": office or "",
        "country": country or "", "net": net or "", "pl": pl or "", "sev": sev or "",
        "t1": t1 or "", "na": na or "", "optype": optype or "", "entype": entype or "",
        "cstart": cstart or "", "cend": cend or "", "sstart": sstart or "", "send": send or "",
        "month": month or "",
    }
    # 1. 缓存命中直接返回
    cache_key = f"dashboard:{json.dumps(params, sort_keys=True)}"
    cached = _cache_get(_filters_cache, cache_key)
    if cached is not None:
        logger.info(f"dashboard 命中缓存")
        return ok(cached)

    _, where, _w = _base_from(params)

    # 2. KPI 串行查询（最重要，避免并发触发基座 API 限流导致空数据）
    async def _q_kpi():
        sql = f"SELECT {_agg_exprs()} FROM {RISK_TABLE} WHERE {where}"
        rows = await query_business(sql, 10)
        return rows[0] if rows else {}

    k = await _q_kpi()

    # 3. 图表 + 趋势并发查询（3 个图表 + 趋势，基座可承受）
    async def _q_chart(dim, col, name):
        sql = (f"SELECT {col} AS dim, {_agg_exprs()} FROM {RISK_TABLE} "
               f"WHERE {where} AND {col} IS NOT NULL AND {col}<>'' "
               f"GROUP BY {col} ORDER BY mh DESC")
        rows = await query_business(sql, 2000)
        arr = []
        for r in rows:
            dm = r.get("dim")
            arr.append({
                "name": (name or {}).get(str(dm), str(dm)),
                "mh": int(r.get("mh") or 0),
                "disposed": int(r.get("disposed") or 0),
                "closed": int(r.get("closed") or 0),
                "impending": int(r.get("impending") or 0),
                "overdue_undisposed": int(r.get("overdue_undisposed") or 0),
                "overdue_uncleared": int(r.get("overdue_uncleared") or 0),
            })
        return dim, arr

    async def _q_trend():
        base_month_sql = _resolve_month(params)
        base_month_raw = _resolve_month_raw(params)
        trend_start = _shift_month(base_month_raw, -11) if base_month_raw else base_month_raw
        trend_where = f"period_month <= {base_month_sql}"
        if trend_start:
            trend_where += f" AND period_month >= '{_esc(trend_start)}'"
        sql = (
            f"SELECT period_month AS month,"
            f"SUM({SEV_MH}) AS mh,"
            f"SUM({SEV_MH} AND {DISPOSED}) AS disp,"
            f"SUM({SEV_MH} AND {CLOSED}) AS clear,"
            f"SUM({UNDISP} AND {SEV_MH} AND ticket_close_due_date < NOW()) AS overdue_undisposed,"
            f"SUM(NOT ({CLOSED}) AND {SEV_MH} AND ticket_close_due_date < NOW()) AS overdue_uncleared "
            f"FROM {RISK_TABLE} "
            f"WHERE {trend_where} "
            f"GROUP BY period_month ORDER BY period_month"
        )
        rows = await query_business(sql, 60)
        trend = []
        for r in rows:
            m = int(r.get("mh") or 0)
            disp = int(r.get("disp") or 0)
            clear = int(r.get("clear") or 0)
            trend.append({
                "month": r.get("month"),
                "mh": m, "disp": disp, "clear": clear,
                "overdue_undisposed": int(r.get("overdue_undisposed") or 0),
                "overdue_uncleared": int(r.get("overdue_uncleared") or 0),
                "disp_rate": round(disp / m * 100, 2) if m else 0,
                "clear_rate": round(clear / m * 100, 2) if m else 0,
            })
        return trend

    # 并发：3 图表 + 趋势（4 个查询并发，KPI 已串行获取）
    results = await asyncio.gather(
        _q_chart("region", "region_code", REGION_MAP),
        _q_chart("sev", "severity", SEV_NAME),
        _q_chart("pl", "product_line_map", PL_NAME),
        _q_trend(),
        return_exceptions=True,
    )

    # 4. 合并结果
    mh = int(k.get("mh") or 0)
    disposed = int(k.get("disposed") or 0)
    closed = int(k.get("closed") or 0)
    kpi = {
        "risk_cnt": int(k.get("risk_cnt") or 0),
        "mh": mh,
        "disposed": disposed,
        "closed": closed,
        "impending": int(k.get("impending") or 0),
        "overdue_undisposed": int(k.get("overdue_undisposed") or 0),
        "disp_rate": round(disposed / mh * 100, 2) if mh else 0,
        "clear_rate": round(closed / mh * 100, 2) if mh else 0,
    }
    charts = {}
    for i, dim in enumerate(["region", "sev", "pl"]):
        r = results[i]
        if isinstance(r, Exception):
            charts[dim] = []
        else:
            _, arr = r
            charts[dim] = arr
    trend = results[3] if not isinstance(results[3], Exception) else []

    out = {"kpi": kpi, "charts": charts, "trend": trend}
    # 5. 写入缓存
    _cache_set(_filters_cache, cache_key, out)
    return ok(out)


@router.get("/mini-dashboard")
async def get_mini_dashboard(
    ict: Optional[str] = Query(None), region: Optional[str] = Query(None),
    office: Optional[str] = Query(None), country: Optional[str] = Query(None),
    net: Optional[str] = Query(None), pl: Optional[str] = Query(None),
    sev: Optional[str] = Query(None), t1: Optional[str] = Query(None),
    na: Optional[str] = Query(None), optype: Optional[str] = Query(None),
    entype: Optional[str] = Query(None), cstart: Optional[str] = Query(None),
    cend: Optional[str] = Query(None), sstart: Optional[str] = Query(None),
    send: Optional[str] = Query(None), month: Optional[str] = Query(None),
):
    """小页面专用轻量级接口：返回 KPI + 地区部分布图数据（charts.region）。
    相比 /dashboard 少 3 个图表查询 + 趋势查询，响应更快。
    """
    params = {
        "ict": ict or "", "region": region or "", "office": office or "",
        "country": country or "", "net": net or "", "pl": pl or "", "sev": sev or "",
        "t1": t1 or "", "na": na or "", "optype": optype or "", "entype": entype or "",
        "cstart": cstart or "", "cend": cend or "", "sstart": sstart or "", "send": send or "",
        "month": month or "",
    }
    # 缓存命中直接返回
    cache_key = f"mini-dashboard:{json.dumps(params, sort_keys=True)}"
    cached = _cache_get(_filters_cache, cache_key)
    if cached is not None:
        return ok(cached)

    _, where, _w = _base_from(params)

    # KPI + 地区部分布 并发查询（2 个查询）
    async def _q_kpi():
        sql = f"SELECT {_agg_exprs()} FROM {RISK_TABLE} WHERE {where}"
        rows = await query_business(sql, 10)
        return rows[0] if rows else {}

    async def _q_region():
        sql = (f"SELECT region_code AS dim, {_agg_exprs()} FROM {RISK_TABLE} "
               f"WHERE {where} AND region_code IS NOT NULL AND region_code<>'' "
               f"GROUP BY region_code ORDER BY mh DESC")
        rows = await query_business(sql, 2000)
        arr = []
        for r in rows:
            dm = r.get("dim")
            m = int(r.get("mh") or 0)
            disp = int(r.get("disposed") or 0)
            arr.append({
                "name": REGION_MAP.get(str(dm), str(dm)),
                "dim": str(dm) if dm is not None else "",
                "mh": m,
                "disposed": disp,
                "disp_rate": round(disp / m * 100, 2) if m else 0,
            })
        return arr

    results = await asyncio.gather(
        _q_kpi(),
        _q_region(),
        return_exceptions=True,
    )

    k = results[0] if not isinstance(results[0], Exception) else {}
    mh = int(k.get("mh") or 0)
    disposed = int(k.get("disposed") or 0)
    closed = int(k.get("closed") or 0)
    kpi = {
        "risk_cnt": int(k.get("risk_cnt") or 0),
        "mh": mh,
        "disposed": disposed,
        "closed": closed,
        "disp_rate": round(disposed / mh * 100, 2) if mh else 0,
        "clear_rate": round(closed / mh * 100, 2) if mh else 0,
    }
    region_data = results[1] if not isinstance(results[1], Exception) else []

    out = {"kpi": kpi, "charts": {"region": region_data}}
    _cache_set(_filters_cache, cache_key, out)
    return ok(out)


# 5 维 Tab 定义：dim → (聚合列, 显示名函数)
DIMS = {
    "region": ("region_code", REGION_MAP),
    "office_net": ("network_id", None),       # 代表处-办事处-网络
    "office_subna": ("subnet_code", None),    # 代表处-办事处-子网和NA
    "t1_na": ("na_type", NA_NAME),            # 大T-NA级别
    "pl": ("product_line_map", PL_NAME),      # 产品线
}


@router.get("/detail")
async def get_detail(
    dim: str = Query("region"),
    page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=500),
    ict: Optional[str] = Query(None), region: Optional[str] = Query(None),
    office: Optional[str] = Query(None), country: Optional[str] = Query(None),
    net: Optional[str] = Query(None), pl: Optional[str] = Query(None),
    sev: Optional[str] = Query(None), t1: Optional[str] = Query(None),
    na: Optional[str] = Query(None), optype: Optional[str] = Query(None),
    entype: Optional[str] = Query(None), cstart: Optional[str] = Query(None),
    cend: Optional[str] = Query(None), sstart: Optional[str] = Query(None),
    send: Optional[str] = Query(None), month: Optional[str] = Query(None),
):
    """详细进展：指定 Tab 维度分页明细 + 全量汇总行。
    office_net 维度按 network_id 聚合，name 用 /filters 返回的 net_name 字典渲染中文。
    """
    if dim not in DIMS:
        return ok([], total=0, message="未知维度")
    col, name = DIMS[dim]
    params = {
        "ict": ict or "", "region": region or "", "office": office or "",
        "country": country or "", "net": net or "", "pl": pl or "", "sev": sev or "",
        "t1": t1 or "", "na": na or "", "optype": optype or "", "entype": entype or "",
        "cstart": cstart or "", "cend": cend or "", "sstart": sstart or "", "send": send or "",
        "month": month or "",
    }
    _, where, _w = _base_from(params)

    # 优化：汇总 + COUNT + 分页明细并发查询（替代串行，缩短总耗时）
    # 注：3 个查询并发基座 API 可承受（与 dashboard 的 4 并发一致）
    sum_sql = f"SELECT {_agg_exprs()} FROM {RISK_TABLE} WHERE {where}"
    cnt_sql = (
        f"SELECT COUNT(DISTINCT {col}) AS c FROM {RISK_TABLE} "
        f"WHERE {where} AND {col} IS NOT NULL AND {col}<>''"
    )
    item_sql = (
        f"SELECT {col} AS dim, {_agg_exprs()} FROM {RISK_TABLE} "
        f"WHERE {where} AND {col} IS NOT NULL AND {col}<>'' "
        f"GROUP BY {col} ORDER BY mh DESC LIMIT {size} OFFSET {(page-1)*size}"
    )
    results = await asyncio.gather(
        query_business(sum_sql, 10),
        query_business(cnt_sql, 10),
        query_business(item_sql, size + 10),
        return_exceptions=True,
    )
    # 容错处理
    srows = results[0] if not isinstance(results[0], Exception) else []
    crows = results[1] if not isinstance(results[1], Exception) else []
    rows = results[2] if not isinstance(results[2], Exception) else []
    s = srows[0] if srows else {}
    _mh_s = int(s.get("mh") or 0)
    _disp_s = int(s.get("disposed") or 0)
    _closed_s = int(s.get("closed") or 0)
    summary = {
        "name": "全部", "risk_cnt": int(s.get("risk_cnt") or 0),
        "mh": _mh_s,
        "high_risk_cnt": int(s.get("high_risk_cnt") or 0),
        "mid_risk_cnt": int(s.get("mid_risk_cnt") or 0),
        "low_risk_cnt": int(s.get("low_risk_cnt") or 0),
        "hang_up_cnt": int(s.get("hang_up_cnt") or 0),
        "disposed": _disp_s,
        "closed": _closed_s,
        "disp_rate": round(_disp_s / _mh_s * 100, 2) if _mh_s else 0,
        "clear_rate": round(_closed_s / _mh_s * 100, 2) if _mh_s else 0,
        "timely_disposed_cnt": int(s.get("timely_disposed_cnt") or 0),
        "overdue_disposed_cnt": int(s.get("overdue_disposed_cnt") or 0),
        "impending": int(s.get("impending") or 0),
        "overdue_undisposed": int(s.get("overdue_undisposed") or 0),
        "overdue_uncleared": int(s.get("overdue_uncleared") or 0),
    }
    total = int(crows[0]["c"]) if crows else 0
    # office_net 维度按 network_id 聚合时，name 需用动态 net_name 字典渲染中文
    dyn_net_name = {}
    if dim == "office_net":
        try:
            dyn_net_name = (await _load_dynamic_maps(_resolve_month(params)))["net_name"]
        except Exception as exc:
            logger.warning(f"detail[office_net] 加载 net_name 失败: {exc}")
    items = []
    for r in rows:
        dm = r.get("dim")
        if name and str(dm) in name:
            disp = name[str(dm)]
        elif dim == "office_net" and str(dm) in dyn_net_name:
            disp = dyn_net_name[str(dm)]
        else:
            disp = str(dm)
        _mh = int(r.get("mh") or 0)
        _disp = int(r.get("disposed") or 0)
        _closed = int(r.get("closed") or 0)
        items.append({
            "name": disp,
            "dim": str(dm) if dm is not None else "",
            "risk_cnt": int(r.get("risk_cnt") or 0),
            "mh": _mh,
            "high_risk_cnt": int(r.get("high_risk_cnt") or 0),
            "mid_risk_cnt": int(r.get("mid_risk_cnt") or 0),
            "low_risk_cnt": int(r.get("low_risk_cnt") or 0),
            "hang_up_cnt": int(r.get("hang_up_cnt") or 0),
            "disposed": _disp,
            "closed": _closed,
            "disp_rate": round(_disp / _mh * 100, 2) if _mh else 0,
            "clear_rate": round(_closed / _mh * 100, 2) if _mh else 0,
            "timely_disposed_cnt": int(r.get("timely_disposed_cnt") or 0),
            "overdue_disposed_cnt": int(r.get("overdue_disposed_cnt") or 0),
            "impending": int(r.get("impending") or 0),
            "overdue_undisposed": int(r.get("overdue_undisposed") or 0),
            "overdue_uncleared": int(r.get("overdue_uncleared") or 0),
        })
    return ok({"items": items, "summary": summary, "dim": dim},
              total=total)


# ---------------------------------------------------------------------------
# 风险详单明细（对应 NetCare 风险管理详单页面，KPI 卡片 / 详细进展数字下钻）
# ---------------------------------------------------------------------------

# 详单表列定义（与 NetCare op_ex_risk_detail_grid 32 列对齐）
RISK_DETAIL_COLS = [
    ("task_id",              "任务ID"),
    ("bg",                   "ICT场景"),
    ("region_code",          "地区部"),
    ("repoffice_code",       "代表处"),
    ("country_code",         "国家/区域/行业"),
    ("customer",             "客户名称"),
    ("t1_operator_code",     "大T"),
    ("rep_off",              "区域系统部"),
    ("na_type",              "NA级别"),
    ("subnet_code",          "子网"),
    ("network_id",           "网络ID"),
    ("network_name",         "网络名称"),
    ("spdt_cn_name",         "SPDT"),
    ("product_line_map",     "产品线"),
    ("product_line",         "产品线-作业单"),
    ("product",              "产品"),
    ("TYPE",                 "风险类型"),
    ("severity",             "风险等级"),
    ("create_time",          "创建时间"),
    ("risk_status",          "风险状态"),
    ("ticket_close_due_date","期望关闭时间"),
    ("is_overdue",           "是否逾期"),
    ("overdue_time",         "逾期日期"),
    ("current_handler",      "当前责任人"),
    ("project_code",         "项目编码"),
    ("project_name",         "项目名称"),
    ("source_l1",            "风险来源"),
    ("source",               "风险来源L2"),
    ("risk_description",     "风险描述"),
    ("close_time",           "关闭时间"),
    ("appraisal_year",       "考核范围"),
    ("mobile_ioc_product_line_map", "产品线-中国区"),
]

# 详单筛选参数白名单（扩展看板筛选，增加风险状态/类型/等级单选）
DETAIL_FILTER_COLS = {
    "ict": "bg", "region": "region_code", "office": "repoffice_code",
    "country": "country_code", "net": "network_id", "pl": "product_line_map",
    "sev": "severity", "t1": "t1_operator_code", "na": "na_type",
    "status": "risk_status", "type": "TYPE", "spdt": "spdt_cn_name",
    "subnet": "subnet_code", "project_code": "project_code",
}

# metric → SQL WHERE 片段（KPI 卡片下钻用）
# 注：处置完成率/清理完成率卡片跳转到"未完成"的部分（分母减分子），
#     与 NetCare 参考页面一致：mid_high_risk_rate=未处置中高风险，mid_high_clear_rate=未清理中高风险
METRIC_WHERE = {
    "risk_cnt":              "1=1",                              # 全部风险
    "mid_high_risk_cnt":     SEV_MH,                              # 中高风险数
    "impending":             IMPENDING,                           # 临期未处置中高风险
    "overdue_undisposed":    OVERDUE_UNDISP,                      # 已逾期未处置中高风险
    "disposed":              f"{SEV_MH} AND {DISPOSED}",          # 已处置中高风险
    "closed":                f"{SEV_MH} AND {CLOSED}",            # 已关闭中高风险
    "mid_high_risk_rate":    f"{SEV_MH} AND {UNDISP}",            # 未处置中高风险（处置完成率卡片）
    "mid_high_clear_rate":   f"{SEV_MH} AND NOT ({CLOSED})",      # 未清理中高风险（清理完成率卡片）
}

# metric → 详单页面标题（前端显示用，与 NetCare 参考页面一致）
METRIC_TITLE = {
    "risk_cnt":              "风险管理详单",
    "mid_high_risk_cnt":     "风险管理详单",
    "impending":             "临期未处置中高风险",
    "overdue_undisposed":    "已逾期未处置中高风险",
    "disposed":              "已处置中高风险",
    "closed":                "已关闭中高风险",
    "mid_high_risk_rate":    "未处置完成（中高风险）",
    "mid_high_clear_rate":   "未清理完成（中高风险）",
}


def _detail_where(params: dict, metric: str = "", dim_col: str = "", dim_val: str = "") -> list:
    """构建详单查询 WHERE 片段。
    params: 看板筛选参数（month/ict/region/...）
    metric: KPI 指标 key（risk_cnt/mid_high_risk_cnt/...），空表示不限定
    dim_col: 下钻维度列（region_code/network_id/...），空表示不限定维度
    dim_val: 下钻维度值
    """
    where = _month_filter_sql(params)
    # 基准月
    period = _resolve_month(params)
    where.insert(0, f"period_month = {period}")
    # KPI 指标限定
    if metric and metric in METRIC_WHERE:
        where.append(METRIC_WHERE[metric])
    # 维度下钻限定（详细进展行点击）
    if dim_col and dim_val:
        where.append(f"{dim_col} = '{_esc(dim_val)}'")
    # 风险类型（运营商/企业）
    optype = (params.get("optype") or "").strip()
    if optype:
        where.append(f"bg='CNBG' AND TYPE='{_esc(optype)}'")
    entype = (params.get("entype") or "").strip()
    if entype:
        where.append(f"bg='EBG' AND TYPE='{_esc(entype)}'")
    # 月份区间（创建 / 应关闭）
    cstart, cend = (params.get("cstart") or "").strip(), (params.get("cend") or "").strip()
    if cstart or cend:
        rng = []
        if cstart:
            rng.append(f"DATE_FORMAT(create_time,'%Y-%m') >= '{_esc(cstart)}'")
        if cend:
            rng.append(f"DATE_FORMAT(create_time,'%Y-%m') <= '{_esc(cend)}'")
        if rng:
            where.append("(" + " AND ".join(rng) + ")")
    sstart, send = (params.get("sstart") or "").strip(), (params.get("send") or "").strip()
    if sstart or send:
        rng = []
        if sstart:
            rng.append(f"DATE_FORMAT(COALESCE(close_time,ticket_close_due_date,expected_close_time),'%Y-%m') >= '{_esc(sstart)}'")
        if send:
            rng.append(f"DATE_FORMAT(COALESCE(close_time,ticket_close_due_date,expected_close_time),'%Y-%m') <= '{_esc(send)}'")
        if rng:
            where.append("(" + " AND ".join(rng) + ")")
    # 详单独有筛选（风险状态/类型/SPDT/子网/项目编码）
    for key, col in DETAIL_FILTER_COLS.items():
        if key in ("ict", "region", "office", "country", "net", "pl", "sev", "t1", "na"):
            continue  # 已在 _month_filter_sql 处理
        v = (params.get(key) or "").strip()
        if v and v != "__all__":
            where.append(f"{col} = '{_esc(v)}'")
    return where


@router.get("/risk-detail")
async def get_risk_detail(
    page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=500),
    metric: Optional[str] = Query(None, description="KPI 指标 key: risk_cnt/mid_high_risk_cnt/impending/overdue_undisposed/disposed/closed"),
    dim: Optional[str] = Query(None, description="下钻维度: region/office_net/office_subna/t1_na/pl"),
    dim_val: Optional[str] = Query(None, description="下钻维度值（编码）"),
    # 看板筛选参数
    ict: Optional[str] = Query(None), region: Optional[str] = Query(None),
    office: Optional[str] = Query(None), country: Optional[str] = Query(None),
    net: Optional[str] = Query(None), pl: Optional[str] = Query(None),
    sev: Optional[str] = Query(None), t1: Optional[str] = Query(None),
    na: Optional[str] = Query(None), optype: Optional[str] = Query(None),
    entype: Optional[str] = Query(None), cstart: Optional[str] = Query(None),
    cend: Optional[str] = Query(None), sstart: Optional[str] = Query(None),
    send: Optional[str] = Query(None), month: Optional[str] = Query(None),
    # 详单独有筛选
    status: Optional[str] = Query(None), type: Optional[str] = Query(None),
    spdt: Optional[str] = Query(None), subnet: Optional[str] = Query(None),
    project_code: Optional[str] = Query(None),
):
    """风险详单明细分页（对应 NetCare 风险管理详单页面）。
    支持 KPI 卡片下钻（metric）和详细进展行下钻（dim + dim_val）。
    返回 32 列明细 + 总数 + 列定义。
    """
    params = {
        "ict": ict or "", "region": region or "", "office": office or "",
        "country": country or "", "net": net or "", "pl": pl or "", "sev": sev or "",
        "t1": t1 or "", "na": na or "", "optype": optype or "", "entype": entype or "",
        "cstart": cstart or "", "cend": cend or "", "sstart": sstart or "", "send": send or "",
        "month": month or "", "status": status or "", "type": type or "",
        "spdt": spdt or "", "subnet": subnet or "", "project_code": project_code or "",
    }
    # 解析下钻维度列
    dim_col = ""
    if dim and dim in DIMS:
        dim_col = DIMS[dim][0]
    where = _detail_where(params, metric or "", dim_col, dim_val or "")
    where_sql = " AND ".join(where)
    # 优化：COUNT + 分页明细并发查询（替代串行）
    cnt_sql = f"SELECT COUNT(*) AS c FROM {RISK_TABLE} WHERE {where_sql}"
    cols_sql = ", ".join(c[0] for c in RISK_DETAIL_COLS)
    item_sql = (
        f"SELECT {cols_sql} FROM {RISK_TABLE} "
        f"WHERE {where_sql} "
        f"ORDER BY create_time DESC LIMIT {size} OFFSET {(page-1)*size}"
    )
    results = await asyncio.gather(
        query_business(cnt_sql, 10),
        query_business(item_sql, size + 10),
        return_exceptions=True,
    )
    crows = results[0] if not isinstance(results[0], Exception) else []
    rows = results[1] if not isinstance(results[1], Exception) else []
    total = int(crows[0]["c"]) if crows else 0
    # 名称映射（用于渲染中文，复用缓存）
    dyn_maps = await _load_dynamic_maps(_resolve_month(params))
    name_maps = {
        "region_name": REGION_MAP, "pl_name": PL_NAME, "sev_name": SEV_NAME,
        "na_name": NA_NAME, "bg_name": BG_NAME,
        "office_name": dyn_maps["office_name"], "country_name": dyn_maps["country_name"],
        "net_name": dyn_maps["net_name"], "t1_name": dyn_maps["t1_name"],
    }
    items = []
    for r in rows:
        row = {}
        for col, _label in RISK_DETAIL_COLS:
            row[col] = r.get(col)
        items.append(row)
    return ok({
        "items": items, "columns": [{"key": c[0], "label": c[1]} for c in RISK_DETAIL_COLS],
        "name_maps": name_maps, "metric": metric or "", "dim": dim or "", "dim_val": dim_val or "",
        "title": METRIC_TITLE.get(metric or "", "风险管理详单"),
    }, total=total)
