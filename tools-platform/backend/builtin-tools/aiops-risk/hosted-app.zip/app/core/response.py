"""统一响应体与分页模型"""
from typing import Any

from pydantic import BaseModel, Field


class UnifiedResponse(BaseModel):
    """全局统一响应结构"""
    code: int = 0
    message: str = "success"
    data: Any = None
    total: int = 0
    elapsed_ms: int = 0
    cache_hit: bool = False


class PageData(BaseModel):
    """列表型数据载荷"""
    items: list[Any] = Field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 50


def ok(data: Any = None, total: int = 0, elapsed_ms: int = 0,
       cache_hit: bool = False, message: str = "success") -> dict:
    return {
        "code": 0,
        "message": message,
        "data": data,
        "total": total,
        "elapsed_ms": elapsed_ms,
        "cache_hit": cache_hit,
    }


def fail(message: str, code: int = 400) -> dict:
    return {"code": code, "message": message, "data": None, "total": 0}
