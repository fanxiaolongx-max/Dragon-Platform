"""结构化日志配置"""
import sys
from pathlib import Path

from loguru import logger

from app.config import settings

LOG_DIR = Path(__file__).resolve().parents[2] / "logs"
LOG_DIR.mkdir(exist_ok=True)

logger.remove()

_fmt = (
    "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
    "<level>{level: <8}</level> | "
    "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
    "<level>{message}</level>"
)

logger.configure(extra={"trace_id": "-"})

logger.add(
    sys.stderr,
    level="DEBUG" if settings.DEBUG else "INFO",
    format=_fmt,
    backtrace=False,
    diagnose=False,
    enqueue=True,
)

logger.add(
    LOG_DIR / "app_{time:YYYY-MM-DD}.log",
    level="INFO",
    rotation="00:00",
    retention="14 days",
    compression="zip",
    encoding="utf-8",
    format=_fmt,
    enqueue=True,
)
