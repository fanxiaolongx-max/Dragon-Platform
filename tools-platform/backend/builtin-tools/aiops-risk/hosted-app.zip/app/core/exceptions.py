"""业务异常体系与全局异常处理"""
import uuid

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.logger import logger


class BusinessError(Exception):
    """业务异常基类"""
    code = 400
    message = "业务处理失败"

    def __init__(self, message: str = None, code: int = None):
        self.message = message or self.message
        self.code = code or self.code
        super().__init__(self.message)


class NotFoundError(BusinessError):
    code = 404
    message = "资源不存在"


class QueryValidationError(BusinessError):
    code = 400
    message = "查询参数非法"


class DatabaseError(BusinessError):
    code = 500
    message = "数据查询失败"


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(BusinessError)
    async def _business(request: Request, exc: BusinessError):
        logger.warning(f"业务异常 {exc.code}: {exc.message} | {request.url.path}")
        return JSONResponse(
            status_code=200,
            content={"code": exc.code, "message": exc.message, "data": None, "total": 0},
        )

    @app.exception_handler(RequestValidationError)
    async def _validation(request: Request, exc: RequestValidationError):
        first = exc.errors()[0] if exc.errors() else {}
        loc = ".".join(str(x) for x in first.get("loc", []) if x != "query")
        msg = first.get("msg", "参数校验失败")
        logger.warning(f"参数校验失败 {loc}: {msg}")
        return JSONResponse(
            status_code=422,
            content={"code": 422, "message": f"参数校验失败：{loc} {msg}", "data": None},
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http(request: Request, exc: StarletteHTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"code": exc.status_code, "message": str(exc.detail), "data": None},
        )

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception):
        trace_id = uuid.uuid4().hex[:8]
        logger.exception(f"未捕获异常 trace_id={trace_id} path={request.url.path}")
        return JSONResponse(
            status_code=500,
            content={
                "code": 500,
                "message": f"服务内部错误，请联系管理员（trace_id: {trace_id}）",
                "data": None,
            },
        )
