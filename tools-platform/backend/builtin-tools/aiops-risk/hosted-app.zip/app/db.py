# -*- coding: utf-8 -*-
"""数据库访问层 — 通过基座 REST API 访问数据。

通过 httpx 调用基座 REST API（API-Q1~Q5）访问数据。
环境变量配置：BASE_QUERY_URL / APP_DATASOURCE_ID / APP_SCHEMA / BUSINESS_DATASOURCE_NAME。
"""
import httpx

from app.config import settings
from app.core.exceptions import DatabaseError
from app.core.logger import logger


# --------------------------------------------------------------------
# 基座 API 地址拼接
# --------------------------------------------------------------------

def _base_execute_url() -> str:
    """API-Q2 写操作地址：将末尾 /query 替换为 /execute"""
    return settings.BASE_QUERY_URL.replace("/query", "/execute")


def _base_datasources_url() -> str:
    """API-Q3 数据源列表地址"""
    return settings.BASE_QUERY_URL + "/datasources"


def _base_find_table_url() -> str:
    """API-Q5 按表名反查地址"""
    return settings.BASE_QUERY_URL.replace("/query", "/query/find-table-datasource")


# --------------------------------------------------------------------
# 基座 API 客户端
# --------------------------------------------------------------------


async def base_query_app_schema(sql: str, limit: int = 100) -> dict:
    """API-Q1: 查询应用 schema 内的表（datasourceId + schema 限定）"""
    async with httpx.AsyncClient(
        timeout=settings.HTTP_TIMEOUT, verify=settings.HTTP_VERIFY_SSL, trust_env=False
    ) as client:
        r = await client.post(
            settings.BASE_QUERY_URL,
            json={
                "datasourceId": settings.APP_DATASOURCE_ID,
                "schema": settings.APP_SCHEMA,
                "sql": sql,
                "limit": limit,
            },
        )
        return r.json()


async def base_execute_app_schema(sql: str) -> dict:
    """API-Q2: 写操作（INSERT/UPDATE/DELETE）到应用 schema"""
    async with httpx.AsyncClient(
        timeout=settings.HTTP_TIMEOUT, verify=settings.HTTP_VERIFY_SSL, trust_env=False
    ) as client:
        r = await client.post(
            _base_execute_url(),
            json={
                "datasourceId": settings.APP_DATASOURCE_ID,
                "schema": settings.APP_SCHEMA,
                "sql": sql,
            },
        )
        return r.json()


async def base_query_business(sql: str, limit: int = 100) -> dict:
    """API-Q1: 查询业务库（只读，按业务库组名 datasourceName）"""
    if not settings.BUSINESS_DATASOURCE_NAME:
        raise RuntimeError("未注入 BUSINESS_DATASOURCE_NAME，请创建应用时指定业务数据库")
    async with httpx.AsyncClient(
        timeout=settings.HTTP_TIMEOUT, verify=settings.HTTP_VERIFY_SSL, trust_env=False
    ) as client:
        r = await client.post(
            settings.BASE_QUERY_URL,
            json={
                "datasourceName": settings.BUSINESS_DATASOURCE_NAME,
                "sql": sql,
                "limit": limit,
            },
        )
        return r.json()


async def base_find_table_datasource(table_name: str) -> dict:
    """API-Q5: 按表名反查所属业务数据源组"""
    async with httpx.AsyncClient(
        timeout=settings.HTTP_TIMEOUT, verify=settings.HTTP_VERIFY_SSL, trust_env=False
    ) as client:
        r = await client.get(_base_find_table_url(), params={"table": table_name})
        return r.json()


async def check_base_api() -> bool:
    """基座 API 连通性检查（调用 API-Q3 GET /datasources）"""
    try:
        async with httpx.AsyncClient(
            timeout=5, verify=settings.HTTP_VERIFY_SSL, trust_env=False
        ) as client:
            r = await client.get(_base_datasources_url())
            return r.status_code == 200 and r.json().get("code") == 0
    except Exception as exc:
        logger.warning(f"基座 API 连通失败：{exc}")
        return False


# --------------------------------------------------------------------
# 统一数据访问门面
# --------------------------------------------------------------------

async def query_app_schema(sql: str, limit: int = 100) -> list[dict]:
    """查询应用 schema 内数据，返回 rows 列表。"""
    try:
        resp = await base_query_app_schema(sql, limit)
    except Exception as exc:
        raise DatabaseError(f"基座 API 请求失败：{exc}")
    if resp.get("code") != 0:
        raise DatabaseError(resp.get("message", "基座查询失败"))
    return resp.get("data", {}).get("rows", [])


async def execute_app_schema(sql: str) -> int:
    """写操作（INSERT/UPDATE/DELETE），返回 affectedRows。"""
    try:
        resp = await base_execute_app_schema(sql)
    except Exception as exc:
        raise DatabaseError(f"基座 API 请求失败：{exc}")
    if resp.get("code") != 0:
        raise DatabaseError(resp.get("message", "基座写操作失败"))
    return resp.get("data", {}).get("affectedRows", 0)


async def query_business(sql: str, limit: int = 100) -> list[dict]:
    """查询业务库（只读），返回 rows 列表。"""
    try:
        resp = await base_query_business(sql, limit)
    except Exception as exc:
        raise DatabaseError(f"基座 API 请求失败：{exc}")
    if resp.get("code") != 0:
        raise DatabaseError(resp.get("message", "基座查询失败"))
    return resp.get("data", {}).get("rows", [])
