# -*- coding: utf-8 -*-
"""应用入口：风险服务 — FastAPI + 基座 API + ECharts

路由规划（参照 demo-business-app 模式）：
  页面：  /              → 直接返回 static/index.html
  静态：  由 index.html 内相对路径（./css/... ./js/...）解析
  API：   /api/...       → 业务路由（含 healthz）

前端通过 location.pathname 动态拼接 API 基址，
兼容本地 / 和平台 /digital-human/dh/{UUID}/ 两种部署场景。
"""
import logging
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.core.exceptions import register_exception_handlers
from app.core.logger import logger
from app.routers import health, risk

logging.getLogger("uvicorn").setLevel(logging.INFO)

STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    register_exception_handlers(app)

    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ---- 路由：统一 /api 前缀 ----
    app.include_router(health.router, prefix="/api")
    app.include_router(risk.router, prefix="/api")

    # ---- 静态文件（供 index.html 相对路径引用 ./css ./js）----
    if os.path.isdir(STATIC_DIR):
        app.mount("/css", StaticFiles(directory=os.path.join(STATIC_DIR, "css")), name="css")
        app.mount("/js", StaticFiles(directory=os.path.join(STATIC_DIR, "js")), name="js")

    # ---- 页面入口：直接返回 HTML ----
    @app.get("/", response_class=HTMLResponse, include_in_schema=False)
    async def index():
        return FileResponse(os.path.join(STATIC_DIR, "index.html"))

    @app.get("/log.html", response_class=HTMLResponse, include_in_schema=False)
    async def log_page():
        return FileResponse(os.path.join(STATIC_DIR, "log.html"))

    @app.get("/detail.html", response_class=HTMLResponse, include_in_schema=False)
    async def detail_page():
        return FileResponse(os.path.join(STATIC_DIR, "detail.html"))

    @app.get("/mini.html", response_class=HTMLResponse, include_in_schema=False)
    async def mini_page():
        """小页面（供大看板 iframe 嵌入，自适应尺寸 + 过滤条件传递）"""
        return FileResponse(os.path.join(STATIC_DIR, "mini.html"))

    @app.on_event("startup")
    def on_startup():
        logger.info(
            f"{settings.APP_NAME} v{settings.APP_VERSION} 启动完成 "
            f"(port={settings.PORT})"
        )

    return app


app = create_app()
