// API 基础路径：基于当前页面路径动态拼接，兼容本地 / 和平台 /digital-human/dh/{UUID}/
//
// 本地：  pathname=/            → dir=/            → API_BASE=/api
// 平台：  pathname=/digital-human/dh/{UUID}/ → dir=/digital-human/dh/{UUID}/ → API_BASE=/digital-human/dh/{UUID}/api
//
// 用法：  const data = await api.get('/healthz');
//        const data = await api.post('/risks', {page:1});
(function() {
  function apiBase() {
    var p = window.location.pathname;
    var dir = p.endsWith('/') ? p : p.substring(0, p.lastIndexOf('/') + 1);
    return dir + 'api';
  }
  var API_BASE = apiBase();

  async function apiFetch(path, options) {
    var url = API_BASE + path;
    var resp = await fetch(url, options);
    if (!resp.ok) {
      throw new Error('HTTP ' + resp.status + ': ' + resp.statusText);
    }
    return resp.json();
  }

  window.api = {
    get: function(path) { return apiFetch(path); },
    post: function(path, body) {
      return apiFetch(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body || {}),
      });
    },
  };
})();
