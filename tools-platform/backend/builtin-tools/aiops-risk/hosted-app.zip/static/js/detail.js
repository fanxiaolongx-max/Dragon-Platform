// 风险管理详单页面控制器
// 数据来源：后端 /api/risk-detail 接口（线上库模式）
// 支持 KPI 卡片下钻（metric）和详细进展行下钻（dim + dim_val）

// ---------- 通用 ----------
function rdTick() {
  var d = new Date(), p = function(n){ return String(n).padStart(2, '0'); };
  var wk = ['日','一','二','三','四','五','六'];
  var el = document.getElementById('clock');
  if (el) el.innerHTML = '<b>' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()) + '</b> · 星期' + wk[d.getDay()];
}
if (typeof tick === 'function') { rdTick(); setInterval(rdTick, 1000); }

function rdToast(msg, kind) {
  kind = kind || 'ok';
  var t = document.createElement('div');
  t.className = 'toast ' + kind;
  t.textContent = msg;
  var tc = document.getElementById('toast');
  if (!tc) return;
  tc.appendChild(t);
  setTimeout(function(){ t.remove(); }, 2800);
}

function rdNumFmt(n){ return Number(n || 0).toLocaleString('en-US'); }

// 名称映射（来自后端 /filters）
var NAME = {
  region_name: {}, pl_name: {}, sev_name: {High:'高',Middle:'中',Low:'低'},
  na_name: {}, bg_name: {CNBG:'运营商',EBG:'政企'},
  office_name: {}, country_name: {}, net_name: {}, t1_name: {}
};

// 详单筛选字段
var DETAIL_FILTER_KEYS = ['ict','region','office','country','net','pl','t1','na','sev','status','type','month'];
var DEFAULT_PAGE_SIZE = 20;
var curPage = 1;
// 详单上下文（从看板跳转携带的 metric/dim/dim_val/筛选条件）
var detailContext = {};

// SPA 视图切换：打开详单视图（由 risk.js 的 gotoDetail/gotoDetailByDim 调用）
function openDetailView(params) {
  detailContext = params || {};
  curPage = 1;
  // 瞬时切换视图（参考数字证书看板 openKpiDetailPage）
  document.getElementById('mainView').style.display = 'none';
  document.getElementById('detailView').style.display = 'block';
  window.scrollTo(0, 0);
  // 显示上下文（指标 + 维度 + 维度值）
  var ctx = [];
  if (detailContext.metric) ctx.push('指标: ' + detailContext.metric);
  if (detailContext.dim) ctx.push('维度: ' + detailContext.dim);
  if (detailContext.dim_val) ctx.push('维度值: ' + detailContext.dim_val);
  var ctxEl = document.getElementById('detail-ctx');
  if (ctxEl) ctxEl.textContent = ctx.join(' · ');
  // 应用筛选条件到下拉框
  applyContextFilters(detailContext);
  // 异步加载数据（加载完成后用后端返回的 title 更新页面标题）
  rdLoadDetail();
}

// SPA 视图切换：关闭详单视图，返回看板
function closeDetailView() {
  document.getElementById('detailView').style.display = 'none';
  document.getElementById('mainView').style.display = 'block';
  window.scrollTo(0, 0);
}

// 应用上下文筛选条件到下拉框
function applyContextFilters(ctx) {
  var map = {ict:'d-ict', region:'d-region', office:'d-office', country:'d-country',
             net:'d-net', pl:'d-pl', sev:'d-sev', t1:'d-t1', na:'d-na', month:'d-month',
             status:'d-status', type:'d-type'};
  Object.keys(map).forEach(function(k){
    if (ctx[k] !== undefined && ctx[k] !== '') {
      var sel = document.getElementById(map[k]);
      if (sel) sel.value = ctx[k];
    }
  });
}

// ---------- 筛选初始化 ----------
function initFilterSelects(fd) {
  // 静态映射
  NAME.region_name = fd.region_name || {};
  NAME.pl_name = fd.pl_name || {};
  NAME.sev_name = fd.sev_name || {High:'高',Middle:'中',Low:'低'};
  NAME.na_name = fd.na_name || {};
  NAME.office_name = fd.office_name || {};
  NAME.country_name = fd.country_name || {};
  NAME.net_name = fd.net_name || {};
  NAME.t1_name = fd.t1_name || {};

  // 填充下拉框
  function fillSelect(id, vals, nameMap) {
    var sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = '<option value="">全部</option>';
    (vals || []).forEach(function(v){
      var op = document.createElement('option');
      op.value = v;
      op.textContent = (nameMap && nameMap[v]) || v;
      sel.appendChild(op);
    });
  }
  fillSelect('d-ict', [['CNBG','运营商'],['EBG','政企']], null);
  fillSelect('d-region', fd.regions, NAME.region_name);
  fillSelect('d-office', fd.offices, NAME.office_name);
  fillSelect('d-country', fd.countries, NAME.country_name);
  fillSelect('d-net', fd.nets, NAME.net_name);
  fillSelect('d-pl', fd.pls, NAME.pl_name);
  fillSelect('d-t1', fd.t1s, NAME.t1_name);
  fillSelect('d-na', fd.nas, NAME.na_name);
  fillSelect('d-sev', fd.sevs, NAME.sev_name);

  // 风险状态（从字典或硬编码）
  var statusSel = document.getElementById('d-status');
  if (statusSel) {
    var statuses = ['Risk Initial','Risk Accepted','Risk+Accepted','Risk Closed','Risk+Closed',
                    '风险接受','已闭环','203','207','204','210','201','206','208'];
    statusSel.innerHTML = '<option value="">全部</option>';
    statuses.forEach(function(s){
      var op = document.createElement('option');
      op.value = s; op.textContent = s;
      statusSel.appendChild(op);
    });
  }

  // 风险类型（从 /filters 的 optype/entype 合并）
  var typeSel = document.getElementById('d-type');
  if (typeSel) {
    var types = [].concat(fd.optype || [], fd.entype || []);
    typeSel.innerHTML = '<option value="">全部</option>';
    types.forEach(function(t){
      var op = document.createElement('option');
      op.value = t; op.textContent = t;
      typeSel.appendChild(op);
    });
  }

  // 基准月
  var monSel = document.getElementById('d-month');
  if (monSel) {
    monSel.innerHTML = '<option value="">全部</option>';
    (fd.months || []).forEach(function(m){
      var op = document.createElement('option');
      op.value = m; op.textContent = m.slice(2);
      monSel.appendChild(op);
    });
    if (fd.base_month) monSel.value = fd.base_month;
  }
}

// （applyUrlParams 已被 applyContextFilters 替代，SPA 模式下不再从 URL 读参数）

// ---------- 获取筛选条件 ----------
function getDetailFilters() {
  var f = {};
  DETAIL_FILTER_KEYS.forEach(function(k){
    var sel = document.getElementById('d-' + k);
    f[k] = sel ? sel.value : '';
  });
  return f;
}

function buildQs(f, extra) {
  var parts = [];
  Object.keys(f).forEach(function(k){
    if (f[k]) parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(f[k]));
  });
  if (extra) {
    Object.keys(extra).forEach(function(k){
      if (extra[k]) parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(extra[k]));
    });
  }
  return parts.join('&');
}

// ---------- 渲染表格 ----------
function rdRenderTable(data) {
  var cols = data.columns || [];
  var items = data.items || [];
  var nameMaps = data.name_maps || {};
  var thead = document.getElementById('rd-thead');
  var tbody = document.getElementById('rd-tbody');
  // 表头
  thead.innerHTML = '<tr>' + cols.map(function(c){
    return '<th title="' + (c.label || c.key) + '">' + (c.label || c.key) + '</th>';
  }).join('') + '</tr>';
  // 行
  function renderCell(col, row) {
    var v = row[col.key];
    if (v === null || v === undefined || v === '') return '<td>--</td>';
    // 名称映射渲染
    var maps = {
      'bg': nameMaps.bg_name, 'region_code': nameMaps.region_name,
      'repoffice_code': nameMaps.office_name, 'country_code': nameMaps.country_name,
      'network_id': nameMaps.net_name, 'product_line_map': nameMaps.pl_name,
      'severity': nameMaps.sev_name, 'na_type': nameMaps.na_name,
      't1_operator_code': nameMaps.t1_name,
    };
    var disp = v;
    if (maps[col.key] && maps[col.key][String(v)]) disp = maps[col.key][String(v)];
    // 风险等级颜色
    var cls = '';
    if (col.key === 'severity') cls = ' class="sev-' + v + '"';
    // 时间格式化
    if (col.key === 'create_time' || col.key === 'close_time' ||
        col.key === 'ticket_close_due_date' || col.key === 'overdue_time') {
      disp = String(v).replace('T',' ').substring(0, 19);
    }
    // 是否逾期
    if (col.key === 'is_overdue') {
      disp = (v == 1 || v === '1' || v === 'true') ? '是' : '否';
    }
    return '<td' + cls + ' title="' + String(disp).substring(0, 100) + '">' + String(disp) + '</td>';
  }
  var rows = items.map(function(r){
    return '<tr>' + cols.map(function(c){ return renderCell(c, r); }).join('') + '</tr>';
  });
  tbody.innerHTML = rows.length ? rows.join('') :
    '<tr><td colspan="' + cols.length + '" style="text-align:center;color:var(--kb-dim2);padding:20px">暂无数据</td></tr>';
}

// ---------- 分页 ----------
function rdRenderPager(total) {
  var el = document.getElementById('rd-pager');
  if (!el) return;
  var pages = Math.max(1, Math.ceil(total / DEFAULT_PAGE_SIZE));
  var cur = curPage;
  var btns = [];
  if (cur > 1) btns.push('<button class="pbtn" data-p="' + (cur-1) + '">‹</button>');
  var lo = Math.max(1, cur - 4), hi = Math.min(pages, cur + 4);
  if (lo > 1) btns.push('<button class="pbtn" data-p="1">1</button>' + (lo > 2 ? '<span class="pdot">…</span>' : ''));
  for (var i = lo; i <= hi; i++) btns.push('<button class="pbtn' + (i===cur?' on':'') + '" data-p="' + i + '">' + i + '</button>');
  if (hi < pages) btns.push((hi < pages - 1 ? '<span class="pdot">…</span>' : '') + '<button class="pbtn" data-p="' + pages + '">' + pages + '</button>');
  if (cur < pages) btns.push('<button class="pbtn" data-p="' + (cur+1) + '">›</button>');
  el.innerHTML = '<span class="info">共 ' + rdNumFmt(total) + ' 条 · 第 ' + cur + '/' + pages + ' 页</span><span class="pbtns">' + btns.join('') + '</span>';
  el.querySelectorAll('.pbtn').forEach(function(b){
    b.onclick = function(){
      var p = parseInt(b.getAttribute('data-p'), 10);
      if (p && p !== curPage) { curPage = p; rdLoadDetail(); }
    };
  });
}

// ---------- 数据加载 ----------
function rdLoadDetail() {
  var f = getDetailFilters();
  // 合并 detailContext 中的筛选条件（从小页面跳转时携带的 URL 参数）
  // 下拉框可能还没初始化，此时用 detailContext 的值兜底
  ['ict','region','office','country','net','pl','sev','t1','na','month','status','type'].forEach(function(k){
    if (!f[k] && detailContext[k]) f[k] = detailContext[k];
  });
  var extra = {
    page: curPage, size: DEFAULT_PAGE_SIZE,
    metric: detailContext.metric || '', dim: detailContext.dim || '', dim_val: detailContext.dim_val || ''
  };
  var qs = buildQs(f, extra);
  var url = '/risk-detail' + (qs ? '?' + qs : '');
  return api.get(url).then(function(d){
    if (d.code !== 0) { rdToast(d.message || '查询失败', 'err'); return; }
    // 用后端返回的 title 更新详单页面标题（与 NetCare 参考页面一致）
    var data = d.data || {};
    if (data.title) {
      var h1 = document.querySelector('#detailView h1');
      if (h1) h1.textContent = data.title;
    }
    rdRenderTable(data);
    rdRenderPager(d.total || 0);
  }).catch(function(e){
    rdToast('加载详单失败: ' + e.message, 'err');
  });
}

// ---------- 导出 ----------
function rdExportDetail() {
  var f = getDetailFilters();
  var extra = {
    metric: detailContext.metric || '', dim: detailContext.dim || '', dim_val: detailContext.dim_val || ''
  };
  var qs = buildQs(f, extra);
  // 导出当前筛选下的全量数据（前端生成 CSV）
  var exportUrl = '/risk-detail?page=1&size=10000' + (qs ? '&' + qs : '');
  rdToast('正在导出...', 'ok');
  api.get(exportUrl).then(function(d){
    if (d.code !== 0) { rdToast(d.message || '导出失败', 'err'); return; }
    var data = d.data || {};
    var cols = data.columns || [];
    var items = data.items || [];
    var nameMaps = data.name_maps || {};
    // CSV 表头
    var csv = cols.map(function(c){ return '"' + (c.label || c.key).replace(/"/g, '""') + '"'; }).join(',') + '\n';
    // CSV 行
    items.forEach(function(r){
      var row = cols.map(function(c){
        var v = r[c.key];
        if (v === null || v === undefined) v = '';
        return '"' + String(v).replace(/"/g, '""') + '"';
      });
      csv += row.join(',') + '\n';
    });
    // 下载
    var blob = new Blob(['\ufeff' + csv], {type: 'text/csv;charset=utf-8;'});
    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'risk_detail_' + new Date().toISOString().slice(0,10) + '.csv';
    link.click();
    rdToast('导出完成，共 ' + items.length + ' 条', 'ok');
  }).catch(function(e){ rdToast('导出失败: ' + e.message, 'err'); });
}

// ---------- 事件绑定 ----------
function rdBindEvents() {
  var q = document.getElementById('btn-d-query');
  if (q) q.onclick = function(){ curPage = 1; rdLoadDetail(); };
  var r = document.getElementById('btn-d-reset');
  if (r) r.onclick = function(){
    DETAIL_FILTER_KEYS.forEach(function(k){
      var sel = document.getElementById('d-' + k);
      if (sel) sel.selectedIndex = 0;
    });
    curPage = 1; rdLoadDetail();
  };
  var ex = document.getElementById('btn-d-export');
  if (ex) ex.onclick = rdExportDetail;
  var back = document.getElementById('btn-back');
  if (back) back.onclick = closeDetailView;
}

// ---------- 启动 ----------
// SPA 模式：不主动调用 /filters（避免与 risk.js 的 loadFilters 重复请求，这是性能瓶颈）
// 改为监听 risk.js 的 filtersReady 事件，复用已加载的 NAME 数据初始化下拉框
window.addEventListener('load', function(){
  if (typeof api === 'undefined') return;
  // 先绑定事件（返回按钮等）
  rdBindEvents();
  // 如果 NAME 已有数据（risk.js 先完成了），直接初始化
  if (typeof NAME !== 'undefined' && NAME.region_name && Object.keys(NAME.region_name).length > 0) {
    initFilterSelectsFromName();
  }
  // 否则等待 risk.js 的 filtersReady 事件（不重复调用 /filters）
  // 检查 URL 参数：如果是从小页面跳转过来（有 metric/dim），自动打开详单视图
  if (typeof checkUrlParamsAndOpenDetail === 'function') {
    checkUrlParamsAndOpenDetail();
  }
});

// 监听 risk.js 的 filtersReady 事件（filters 加载完成后初始化下拉框）
window.addEventListener('filtersReady', function(){
  initFilterSelectsFromName();
});

// 从全局 NAME 映射初始化下拉框（复用看板数据，避免重复请求）
function initFilterSelectsFromName() {
  // 静态映射已由 risk.js 的 loadFilters 填充到全局 NAME
  // 这里只填充下拉框选项
  function fillSelect(id, vals, nameMap) {
    var sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = '<option value="">全部</option>';
    (vals || []).forEach(function(v){
      var op = document.createElement('option');
      op.value = v;
      op.textContent = (nameMap && nameMap[v]) || v;
      sel.appendChild(op);
    });
  }
  // 从 NAME 映射的 keys 生成选项
  fillSelect('d-ict', [['CNBG','运营商'],['EBG','政企']], null);
  fillSelect('d-region', Object.keys(NAME.region_name || {}), NAME.region_name);
  fillSelect('d-office', Object.keys(NAME.office_name || {}), NAME.office_name);
  fillSelect('d-country', Object.keys(NAME.country_name || {}), NAME.country_name);
  fillSelect('d-net', Object.keys(NAME.net_name || {}), NAME.net_name);
  fillSelect('d-pl', Object.keys(NAME.pl_name || {}), NAME.pl_name);
  fillSelect('d-t1', Object.keys(NAME.t1_name || {}), NAME.t1_name);
  fillSelect('d-na', Object.keys(NAME.na_name || {}), NAME.na_name);
  fillSelect('d-sev', Object.keys(NAME.sev_name || {}), NAME.sev_name);
  // 风险状态（硬编码）
  var statusSel = document.getElementById('d-status');
  if (statusSel) {
    var statuses = ['Risk Initial','Risk Accepted','Risk+Accepted','Risk Closed','Risk+Closed',
                    '风险接受','已闭环','203','207','204','210'];
    statusSel.innerHTML = '<option value="">全部</option>';
    statuses.forEach(function(s){
      var op = document.createElement('option');
      op.value = s; op.textContent = s;
      statusSel.appendChild(op);
    });
  }
  // 风险类型（从全局 OPT_DATA 获取，如果有的话）
  var typeSel = document.getElementById('d-type');
  if (typeSel && typeof OPT_DATA !== 'undefined') {
    var types = [].concat((OPT_DATA.optype || []).map(function(o){return o[0];}),
                          (OPT_DATA.entype || []).map(function(o){return o[0];}));
    typeSel.innerHTML = '<option value="">全部</option>';
    types.forEach(function(t){
      var op = document.createElement('option');
      op.value = t; op.textContent = t;
      typeSel.appendChild(op);
    });
  }
  // 基准月（从全局 OPT_DATA 获取）
  var monSel = document.getElementById('d-month');
  if (monSel && typeof OPT_DATA !== 'undefined' && OPT_DATA.month) {
    monSel.innerHTML = '<option value="">全部</option>';
    OPT_DATA.month.forEach(function(o){
      var op = document.createElement('option');
      op.value = o[0]; op.textContent = o[1];
      monSel.appendChild(op);
    });
  }
}
