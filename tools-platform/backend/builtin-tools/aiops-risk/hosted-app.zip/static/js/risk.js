// 风险管理看板控制器
// 数据来源：后端 /api 接口（query_business 线上库），前端仅做展示

// ---------- 通用 ----------
function tick() {
  var d = new Date(), p = function(n){ return String(n).padStart(2, '0'); };
  var wk = ['日','一','二','三','四','五','六'];
  var el = document.getElementById('clock');
  if (el) el.innerHTML = '<b>' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()) + '</b> · 星期' + wk[d.getDay()];
}
tick(); setInterval(tick, 1000);

function toast(msg, kind) {
  kind = kind || 'ok';
  var t = document.createElement('div');
  t.className = 'toast ' + kind;
  t.textContent = msg;
  var tc = document.getElementById('toast');
  if (!tc) return;
  tc.appendChild(t);
  setTimeout(function(){ t.remove(); }, 2800);
}

function numFmt(n){ return Number(n || 0).toLocaleString('en-US'); }

// 名称映射（来自后端 /filters）
// 静态字段：region_name / pl_name / sev_name / na_name / bg_name（硬编码枚举）
// 动态字段：office_name / country_name / net_name / t1_name（按基准月查询云端只读库）
var NAME = {
  region_name: {}, pl_name: {}, sev_name: {High:'高',Middle:'中',Low:'低'},
  na_name: {}, bg_name: {CNBG:'运营商',EBG:'政企'},
  office_name: {}, country_name: {}, net_name: {}, t1_name: {}
};

// 筛选字段定义：key → 下拉ID + 数据数组
var FILTER_KEYS = ['month','ict','region','office','country','net','pl','sev','t1','na','optype','entype','cstart','cend','sstart','send'];
var OPT_DATA = {}; // {key: [[value,label],...]}

// ---------- 筛选初始化 ----------
function initFilterOptions() {
  var map = {
    month:   function(d){ var m=d.months||[]; return [['', '全部']].concat(m.map(function(x){return [x, x.slice(2)];})); },
    ict:     function(){ return [['','全部ICT场景'],['CNBG','运营商'],['EBG','政企']]; },
    region:  function(d){ return [['','全部地区部']].concat((d.regions||[]).map(function(v){return [v, NAME.region_name[v]||v];})); },
    office:  function(d){ return [['','全部代表处']].concat((d.offices||[]).map(function(v){return [v, NAME.office_name[v]||v];})); },
    country: function(d){ return [['','全部国家/区域']].concat((d.countries||[]).map(function(v){return [v, NAME.country_name[v]||v];})); },
    net:     function(d){ return [['','全部网络']].concat((d.nets||[]).map(function(v){return [v, NAME.net_name[v]||v];})); },
    pl:      function(d){ return [['','全部产品线']].concat((d.pls||[]).map(function(v){return [v, NAME.pl_name[v]||v];})); },
    sev:     function(d){ return [['','全部级别']].concat((d.sevs||[]).map(function(v){return [v, NAME.sev_name[v]||v];})); },
    t1:      function(d){ return [['','全部大T']].concat((d.t1s||[]).map(function(v){return [v, NAME.t1_name[v]||v];})); },
    na:      function(d){ return [['','全部NA级别']].concat((d.nas||[]).map(function(v){return [v, NAME.na_name[v]||v];})); },
    optype:  function(d){ return [['','全部']].concat((d.optype||[]).map(function(v){return [v,v];})); },
    entype:  function(d){ return [['','全部']].concat((d.entype||[]).map(function(v){return [v,v];})); },
    cstart:  function(d){ var m=d.months||[]; return [['','全部']].concat(m.map(function(x){return [x,x.slice(2)];})); },
    cend:    function(d){ var m=d.months||[]; return [['','全部']].concat(m.map(function(x){return [x,x.slice(2)];})); },
    sstart:  function(d){ var m=d.months||[]; return [['','全部']].concat(m.map(function(x){return [x,x.slice(2)];})); },
    send:    function(d){ var m=d.months||[]; return [['','全部']].concat(m.map(function(x){return [x,x.slice(2)];})); },
  };
  return map;
}

// 后端 /filters 返回结构 → OPT_DATA
function buildOptions(fd) {
  OPT_DATA.month   = [['','全部']].concat((fd.months||[]).map(function(x){return [x,x.slice(2)];}));
  OPT_DATA.ict     = [['','全部ICT场景'],['CNBG','运营商'],['EBG','政企']];
  OPT_DATA.region  = [['','全部地区部']].concat((fd.regions||[]).map(function(v){return [v, NAME.region_name[v]||v];}));
  OPT_DATA.office  = [['','全部代表处']].concat((fd.offices||[]).map(function(v){return [v, NAME.office_name[v]||v];}));
  OPT_DATA.country = [['','全部国家/区域']].concat((fd.countries||[]).map(function(v){return [v, NAME.country_name[v]||v];}));
  OPT_DATA.net     = [['','全部网络']].concat((fd.nets||[]).map(function(v){return [v, NAME.net_name[v]||v];}));
  OPT_DATA.pl      = [['','全部产品线']].concat((fd.pls||[]).map(function(v){return [v, NAME.pl_name[v]||v];}));
  OPT_DATA.sev     = [['','全部级别']].concat((fd.sevs||[]).map(function(v){return [v, NAME.sev_name[v]||v];}));
  OPT_DATA.t1      = [['','全部大T']].concat((fd.t1s||[]).map(function(v){return [v, NAME.t1_name[v]||v];}));
  OPT_DATA.na      = [['','全部NA级别']].concat((fd.nas||[]).map(function(v){return [v, NAME.na_name[v]||v];}));
  OPT_DATA.optype  = [['','全部']].concat((fd.optype||[]).map(function(v){return [v,v];}));
  OPT_DATA.entype  = [['','全部']].concat((fd.entype||[]).map(function(v){return [v,v];}));
  OPT_DATA.cstart  = OPT_DATA.month;
  OPT_DATA.cend    = OPT_DATA.month;
  OPT_DATA.sstart  = OPT_DATA.month;
  OPT_DATA.send    = OPT_DATA.month;

  FILTER_KEYS.forEach(function(k){
    var sel = document.getElementById('f-' + k);
    if (!sel) return;
    sel.innerHTML = '';
    (OPT_DATA[k]||[]).forEach(function(o){
      var op = document.createElement('option');
      op.value = o[0]; op.textContent = o[1]; sel.appendChild(op);
    });
  });
  // 默认基准月 = 配置基准
  var bm = fd.base_month || '';
  var monSel = document.getElementById('f-month');
  if (monSel && bm) monSel.value = bm;
  var hdrMon = document.getElementById('hdr-month');
  if (hdrMon) hdrMon.textContent = bm ? (bm.slice(0,4)+'-'+bm.slice(5)) : '--';
}

function getFilters() {
  var f = {};
  FILTER_KEYS.forEach(function(k){
    var sel = document.getElementById('f-' + k);
    f[k] = sel ? sel.value : '';
  });
  return f;
}

function qs(f) {
  var parts = [];
  FILTER_KEYS.forEach(function(k){
    if (f[k]) parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(f[k]));
  });
  return parts.join('&');
}

// ---------- 详情 5 维 Tab ----------
var DIM_TABS = [
  { key:'region',     label:'地区部' },
  { key:'office_net', label:'代表处-办事处-网络' },
  { key:'office_subna', label:'代表处-办事处-子网和NA' },
  { key:'t1_na',      label:'大T/NA级别' },
  { key:'pl',         label:'产品线' },
];
var curDim = 'region', curPage = 1, PAGE_SIZE = 20;

function renderTabs() {
  var tc = document.getElementById('detail-tabs');
  if (!tc) return;
  tc.innerHTML = '';
  DIM_TABS.forEach(function(t){
    var b = document.createElement('button');
    b.className = 'tab' + (t.key === curDim ? ' active' : '');
    b.textContent = t.label;
    b.onclick = function(){ curDim = t.key; curPage = 1; loadDetail(); renderTabs(); };
    tc.appendChild(b);
  });
}

// 详细进展列定义（与 NetCare 参考页面 21 列对齐）
// 处置区：整体情况/中高风险/风险数/高/中/低/已挂起/已关闭/处置完成率/清理完成率/及时处置数
// 清理区：中高风险/已挂起/已关闭/处置完成率/清理完成率/及时处置数
// 超期区：超期已处置/临期未处置/超期未处置
var DETAIL_COLS = [
  { key:'name',               label:'统计维度',     num:false },
  { key:'risk_cnt',           label:'整体情况',     num:true,  metric:'risk_cnt' },
  { key:'mh',                 label:'中高风险数',   num:true,  metric:'mid_high_risk_cnt' },
  { key:'risk_cnt',           label:'风险数',       num:true,  metric:'risk_cnt' },
  { key:'high_risk_cnt',      label:'高风险',       num:true },
  { key:'mid_risk_cnt',       label:'中风险',       num:true },
  { key:'low_risk_cnt',       label:'低风险',       num:true },
  { key:'hang_up_cnt',        label:'已挂起',       num:true },
  { key:'closed',             label:'已关闭',       num:true,  metric:'closed' },
  { key:'disp_rate',          label:'处置完成率',   num:true,  pct:true, metric:'mid_high_risk_rate' },
  { key:'clear_rate',         label:'清理完成率',   num:true,  pct:true, metric:'mid_high_clear_rate' },
  { key:'timely_disposed_cnt',label:'及时处置数',   num:true },
  // 清理维度重复列（参考页面有两段相同结构的列）
  { key:'mh',                 label:'中高风险数',   num:true },
  { key:'hang_up_cnt',        label:'已挂起',       num:true },
  { key:'closed',             label:'已关闭',       num:true },
  { key:'disp_rate',          label:'处置完成率',   num:true,  pct:true },
  { key:'clear_rate',         label:'清理完成率',   num:true,  pct:true },
  { key:'timely_disposed_cnt',label:'及时处置数',   num:true },
  // 超期区
  { key:'overdue_disposed_cnt', label:'超期已处置数', num:true },
  { key:'impending',            label:'临期未处置数', num:true, metric:'impending' },
  { key:'overdue_undisposed',   label:'超期未处置数', num:true, metric:'overdue_undisposed' },
];

function renderDetail(d) {
  var items = (d.data && d.data.items) || [];
  var summary = (d.data && d.data.summary) || {};
  var total = d.total || 0;
  var thead = document.getElementById('detail-thead');
  var tbody = document.getElementById('detail-tbody');
  var pager = document.getElementById('detail-pager');
  // 表头
  thead.innerHTML = '<tr>' + DETAIL_COLS.map(function(c){return '<th>'+c.label+'</th>';}).join('') + '</tr>';
  // 行
  function rowHtml(r, isSum) {
    var cls = isSum ? ' class="sum-row"' : '';
    var dimVal = r.dim || '';
    var tds = DETAIL_COLS.map(function(c){
      // 百分比列（处置完成率/清理完成率）
      if (c.pct) {
        var v = r[c.key] != null ? r[c.key] : 0;
        var display = (typeof v === 'number' ? v.toFixed(2) : v) + '%';
        // 处置完成率/清理完成率可点击跳转（携带 metric）
        if (c.metric && !isSum && dimVal) {
          return '<td><a href="javascript:gotoDetailByDim(\'' + curDim + '\',\'' + String(dimVal).replace(/'/g,"\\'") + '\',\'' + c.metric + '\')" title="点击查看详单">' + display + '</a></td>';
        }
        return '<td>' + display + '</td>';
      }
      if (!c.num) return '<td>' + (r[c.key] != null ? r[c.key] : '--') + '</td>';
      // 数字列可点击跳转（仅在有 metric 且非汇总行且有 dimVal 时）
      if (c.metric && !isSum && dimVal) {
        return '<td><a href="javascript:gotoDetailByDim(\'' + curDim + '\',\'' + String(dimVal).replace(/'/g,"\\'") + '\',\'' + c.metric + '\')" title="点击查看详单">' + numFmt(r[c.key]) + '</a></td>';
      }
      return '<td>' + numFmt(r[c.key]) + '</td>';
    }).join('');
    return '<tr' + cls + '>' + tds + '</tr>';
  }
  var rows = items.map(function(r){ return rowHtml(r, false); });
  // 汇总行（全量合计）
  if (summary && Object.keys(summary).length) {
    rows.push(rowHtml(summary, true));
  }
  tbody.innerHTML = rows.length ? rows.join('') : '<tr><td colspan="' + DETAIL_COLS.length + '" style="text-align:center;color:var(--kb-dim2)">暂无数据</td></tr>';
  // 分页
  var pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  renderPager(pager, pages, total);
}

function renderPager(el, pages, total) {
  if (!el) return;
  var cur = curPage;
  var btns = [];
  var win = 4;
  var lo = Math.max(1, cur - win), hi = Math.min(pages, cur + win);
  if (cur > 1) btns.push('<button class="pbtn" data-p="' + (cur-1) + '">‹</button>');
  if (lo > 1) btns.push('<button class="pbtn" data-p="1">1</button>' + (lo > 2 ? '<span class="pdot">…</span>' : ''));
  for (var i = lo; i <= hi; i++) btns.push('<button class="pbtn' + (i===cur?' on':'') + '" data-p="' + i + '">' + i + '</button>');
  if (hi < pages) btns.push((hi < pages - 1 ? '<span class="pdot">…</span>' : '') + '<button class="pbtn" data-p="' + pages + '">' + pages + '</button>');
  if (cur < pages) btns.push('<button class="pbtn" data-p="' + (cur+1) + '">›</button>');
  el.innerHTML = '<span class="pinfo">共 ' + total + ' 项 · 第 ' + cur + '/' + pages + ' 页 · 末尾' + (summaryLabel()) + '</span><span class="pbtns">' + btns.join('') + '</span>';
  el.querySelectorAll('.pbtn').forEach(function(b){
    b.onclick = function(){
      curPage = parseInt(b.getAttribute('data-p'), 10);
      loadDetail();
    };
  });
}
function summaryLabel(){ return '汇总（全部）'; }

// ---------- KPI ----------
// KPI 卡片 metric 映射（点击跳转详单页面携带的指标 key）
// 注：处置完成率/清理完成率卡片跳转到"未完成"的部分（与 NetCare 参考页面一致）
//   - 处置完成率 → mid_high_risk_rate（未处置中高风险）
//   - 清理完成率 → mid_high_clear_rate（未清理中高风险）
var KPI_METRICS = [
  { key: 'risk_cnt',           label: '风险数',                  metric: 'risk_cnt',           color: '#40a0ff' },
  { key: 'mh',                 label: '中高风险数',              metric: 'mid_high_risk_cnt',  color: '#40a0ff' },
  { key: 'disp_rate',          label: '中高风险处置完成率',     metric: 'mid_high_risk_rate', color: '#34d399', isRate: true, subKey: 'disposed', subLabel: '已处置' },
  { key: 'impending',          label: '临期未处置中高风险数',   metric: 'impending',          color: '#f59e0b' },
  { key: 'overdue_undisposed', label: '已逾期未处置中高风险数', metric: 'overdue_undisposed', color: '#f87171' },
  { key: 'clear_rate',         label: '中高风险清理完成率',     metric: 'mid_high_clear_rate',color: '#7aa8f0', isRate: true, subKey: 'closed', subLabel: '已关闭' },
];

function renderKpi(k) {
  var el = document.getElementById('kpi-grid');
  if (!el) return;
  function card(cfg) {
    var val = cfg.isRate ? (k[cfg.key] + '%') : (numFmt(k[cfg.key]) + '个');
    var unit = cfg.isRate ? '' : '个';
    var valNum = cfg.isRate ? (k[cfg.key] + '%') : numFmt(k[cfg.key]);
    var sub = '';
    if (cfg.subKey !== undefined) sub = '<div class="kpi-sub">' + (cfg.subLabel||'') + ' ' + numFmt(k[cfg.subKey]) + '</div>';
    // 所有卡片都可点击跳转详单页面（携带 metric + 当前筛选条件）
    // 交互样式由 CSS .kpi-card[onclick]:hover 控制（参考数字证书看板）
    return '<div class="kpi-card" onclick="gotoDetail(\'' + cfg.metric + '\')" title="点击查看详单">' +
      '<div class="kpi-label">' + cfg.label + '</div>' +
      '<div class="kpi-value" style="color:' + cfg.color + '">' + valNum + (unit?'<span class="kpi-unit">'+unit+'</span>':'') + '</div>' +
      sub + '</div>';
  }
  el.innerHTML = KPI_METRICS.map(card).join('');
}

// 跳转到详单视图（SPA 内视图切换，参考数字证书看板 openKpiDetailPage 模式）
// 点击 KPI 卡片 → 瞬时切换到 detailView → 异步加载数据（丝滑体验）
function gotoDetail(metric) {
  var f = getFilters();
  var params = { metric: metric };
  ['ict','region','office','country','net','pl','sev','t1','na','optype','entype','cstart','cend','sstart','send','month'].forEach(function(k){
    if (f[k]) params[k] = f[k];
  });
  // 调用 detail.js 的 openDetailView（SPA 视图切换）
  if (typeof openDetailView === 'function') {
    openDetailView(params);
  }
}

// 跳转到详单视图（携带维度下钻：dim + dim_val + 当前看板筛选条件）
function gotoDetailByDim(dim, dimVal, metric) {
  var f = getFilters();
  var params = { dim: dim, dim_val: dimVal };
  if (metric) params.metric = metric;
  ['ict','region','office','country','net','pl','sev','t1','na','optype','entype','cstart','cend','sstart','send','month'].forEach(function(k){
    if (f[k]) params[k] = f[k];
  });
  if (typeof openDetailView === 'function') {
    openDetailView(params);
  }
}

// ---------- 图表渲染 ----------
var curMode = { region:'dispose', sev:'dispose', pl:'dispose', trend:'dispose' };
var lastDash = null; // 缓存最近 dashboard 数据，供主题切换重绘

function renderCharts(d) {
  lastDash = d;
  var charts = d.charts || {};
  // 地区部
  var region = charts.region || [];
  renderBar('chart-region', region.map(function(x){ return x.name; }), region, curMode.region);
  document.getElementById('sub-region').textContent = region.length + ' 项';
  // 级别
  var sev = charts.sev || [];
  renderBar('chart-sev', sev.map(function(x){ return x.name; }), sev, curMode.sev);
  document.getElementById('sub-sev').textContent = sev.length + ' 项';
  // 产品线
  var pl = charts.pl || [];
  renderBar('chart-pl', pl.map(function(x){ return x.name; }), pl, curMode.pl);
  document.getElementById('sub-pl').textContent = pl.length + ' 项';
  // 趋势
  renderTrend('chart-trend', d.trend || [], curMode.trend);
}

// 模式切换按钮
document.addEventListener('click', function(e){
  var btn = e.target.closest ? e.target.closest('.mode-tab') : null;
  if (!btn) return;
  var uid = btn.getAttribute('data-uid'), mode = btn.getAttribute('data-mode');
  curMode[uid] = mode;
  btn.parentNode.querySelectorAll('.mode-tab').forEach(function(b){ b.classList.remove('active'); });
  btn.classList.add('active');
  if (uid === 'trend' && lastDash) { renderTrend('chart-trend', lastDash.trend || [], mode); }
  else if (lastDash) {
    var charts = lastDash.charts || {};
    var arr = charts[uid] || [];
    renderBar('chart-' + uid, arr.map(function(x){return x.name;}), arr, mode);
  }
});

// 主题切换重绘（复用缓存数据）
window.onThemeChange = function(){
  if (lastDash) renderCharts(lastDash);
};

// ---------- 数据加载 ----------
function setBaseStatus(ok) {
  var led = document.getElementById('baseLed');
  var txt = document.getElementById('baseStatus');
  var dm = document.getElementById('dataMode');
  if (led) { led.style.background = ok ? 'var(--green)' : 'var(--red)'; led.style.boxShadow = ok ? '0 0 8px var(--green)' : '0 0 8px var(--red)'; }
  if (txt) txt.textContent = ok ? '已连通' : '不可达(演示)';
  if (dm) dm.textContent = ok ? '线上' : '演示';
}

function checkHealth() {
  api.get('/healthz').then(function(d){
    var st = (d.data && d.data.status) || '';
    setBaseStatus(st === 'ok');
  }).catch(function(){ setBaseStatus(false); });
}

function loadFilters() {
  return api.get('/filters').then(function(d){
    var fd = d.data || {};
    // 静态映射（硬编码枚举）
    NAME.region_name = fd.region_name || {};
    NAME.pl_name = fd.pl_name || {};
    NAME.sev_name = fd.sev_name || {High:'高',Middle:'中',Low:'低'};
    NAME.na_name = fd.na_name || {};
    // 动态映射（按基准月查询云端只读库，前端用于把下拉编码渲染为中文名）
    NAME.office_name = fd.office_name || {};
    NAME.country_name = fd.country_name || {};
    NAME.net_name = fd.net_name || {};
    NAME.t1_name = fd.t1_name || {};
    fd.regions = fd.regions || Object.keys(NAME.region_name);
    buildOptions(fd);
    // 派发 filtersReady 事件，通知 detail.js 初始化下拉框（避免重复调用 /filters）
    window.dispatchEvent(new Event('filtersReady'));
    return fd;
  });
}

function loadDashboard() {
  var f = getFilters();
  var url = '/dashboard' + (qs(f) ? '?' + qs(f) : '');
  var res = document.getElementById('filter-result');
  if (res) res.textContent = '查询中…';
  return api.get(url).then(function(d){
    if (d && d.code !== 0) { toast((d.message||'查询失败'), 'err'); return; }
    renderKpi(d.data.kpi);
    renderCharts(d.data);
    if (res) {
      var act = FILTER_KEYS.filter(function(k){ return f[k]; }).length;
      res.textContent = '已应用 ' + act + ' 项筛选 · 基准月 ' + (f.month || document.getElementById('f-month').value || '--');
    }
  }).catch(function(e){ toast('加载看板失败: ' + e.message, 'err'); });
}

function loadDetail() {
  var f = getFilters();
  var q = 'dim=' + curDim + '&page=' + curPage + '&size=' + PAGE_SIZE + (qs(f) ? '&' + qs(f) : '');
  return api.get('/detail?' + q).then(function(d){
    renderDetail(d);
    markActiveTab();
  }).catch(function(e){ toast('加载明细失败', 'err'); });
}
function markActiveTab(){
  var tc = document.getElementById('detail-tabs');
  if (!tc) return;
  Array.prototype.forEach.call(tc.children, function(b){
    b.classList.toggle('active', b.textContent === (DIM_TABS.find(function(t){return t.key===curDim;}) || {}).label);
  });
}

// ---------- 事件 ----------
function bindEvents() {
  var q = document.getElementById('btn-query');
  if (q) q.onclick = function(){ curPage = 1; loadDashboard(); loadDetail(); };
  var r = document.getElementById('btn-reset');
  if (r) r.onclick = function(){
    FILTER_KEYS.forEach(function(k){
      var sel = document.getElementById('f-' + k);
      if (sel) sel.selectedIndex = 0;
    });
    var bm = (OPT_DATA.base_month || '');
    var monSel = document.getElementById('f-month');
    // 重置后基准月回默认
    var defMonth = window._defaultBaseMonth || '';
    if (monSel && defMonth) monSel.value = defMonth;
    curPage = 1;
    loadDashboard(); loadDetail();
  };
}

// ---------- 启动 ----------
window._defaultBaseMonth = '';
loadFilters().then(function(fd){
  window._defaultBaseMonth = fd.base_month || '';
  renderTabs();
  bindEvents();
  // 正常加载看板
  loadDashboard();
  loadDetail();
  // 检查 URL 参数自动打开详单视图（从小页面跳转）
  checkUrlParamsAndOpenDetail();
}).catch(function(e){
  toast('初始化失败: ' + e.message, 'err');
  renderTabs(); bindEvents();
  checkUrlParamsAndOpenDetail();
});
checkHealth();
setInterval(checkHealth, 30000);

// 检查 URL 参数自动打开详单视图（从小页面跳转过来时携带 metric/dim/dim_val + 筛选条件）
// 用函数封装，在脚本加载完和 loadFilters 完成后都调用一次（确保执行）
function checkUrlParamsAndOpenDetail() {
  var urlSearch = window.location.search.substring(1);
  if (!urlSearch || (urlSearch.indexOf('metric=') < 0 && urlSearch.indexOf('dim=') < 0)) return;
  if (typeof openDetailView !== 'function') return; // detail.js 还没加载完
  // 解析 URL 参数
  var urlParams = {};
  urlSearch.split('&').forEach(function(pair){
    var idx = pair.indexOf('=');
    if (idx > 0) urlParams[decodeURIComponent(pair.substring(0, idx))] = decodeURIComponent(pair.substring(idx + 1));
  });
  if (!urlParams.metric && !urlParams.dim) return;
  // 应用筛选条件到下拉框
  var filterMap = {ict:'f-ict', region:'f-region', office:'f-office', country:'f-country',
                   net:'f-net', pl:'f-pl', sev:'f-sev', t1:'f-t1', na:'f-na', month:'f-month'};
  Object.keys(filterMap).forEach(function(k){
    if (urlParams[k]) {
      var sel = document.getElementById(filterMap[k]);
      if (sel) sel.value = urlParams[k];
    }
  });
  // 自动打开详单视图
  openDetailView(urlParams);
}

// 脚本加载完立即检查（document.readyState 可能已经是 complete）
if (document.readyState === 'complete') {
  checkUrlParamsAndOpenDetail();
} else {
  window.addEventListener('load', checkUrlParamsAndOpenDetail);
}
