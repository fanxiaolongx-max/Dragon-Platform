// 风险管理看板图表封装（ECharts 5.5.1）
// 提供：双柱子柱状图（处置/清理模式）、双柱+折线趋势图、主题联动

function getChartColors() {
  var theme = window.getTheme ? window.getTheme() : 'dark';
  var dark = theme === 'dark';
  return {
    axisLabel: dark ? '#8aa6c6' : '#64748b',
    splitLine: dark ? 'rgba(80,150,220,.14)' : 'rgba(100,130,180,.12)',
    label: dark ? '#dce9f8' : '#1e3a5f',
    tooltipBg: dark ? 'rgba(13,28,48,.96)' : 'rgba(255,255,255,.97)',
  };
}

// 已注册图表实例（用于 resize / 主题重绘）
var _charts = {};

function _init(domId) {
  var el = document.getElementById(domId);
  if (!el) return null;
  if (_charts[domId]) { _charts[domId].dispose(); }
  var c = echarts.init(el);
  _charts[domId] = c;
  return c;
}

// 通用样式助手
function _axis(c) {
  return {
    axisLine: { lineStyle: { color: c.axisLabel } },
    axisLabel: { color: c.axisLabel },
    splitLine: { lineStyle: { color: c.splitLine } },
  };
}

// 工具提示
function _tip(c, formatter) {
  return {
    trigger: 'axis',
    backgroundColor: c.tooltipBg,
    textStyle: { color: c.label },
    borderColor: c.splitLine,
    formatter: formatter || undefined,
  };
}

// 数值千分位
function _fmt(n) {
  return Number(n || 0).toLocaleString('en-US');
}

/**
 * 渲染"风险数量+处置/清理"柱状图（双柱：中高风险数 + 按模式取处置/关闭数）
 * data: [{name, mh, disposed, closed}]
 * mode: 'dispose' | 'clear'
 *
 * 滚动轴规则（符合样例工程规范，保持图表尺寸不变）：
 *   - 数据条数 ≤ 8：无滚动轴，全部直接展示（与原逻辑一致，级别图 3 项不受影响）
 *   - 数据条数 > 8：启用 dataZoom（inside 拖动 + slider 底部滑块），
 *     默认显示前 8 项，可横向拖动/滑动查看剩余项（地区部 14 项、产品线 10 项适用）。
 */
function renderBar(domId, cats, data, mode, color) {
  var c = getChartColors();
  var chart = _init(domId);
  if (!chart) return;
  var s2 = mode === 'dispose' ? '已处置' : '已关闭';
  var s2Key = mode === 'dispose' ? 'disposed' : 'closed';
  var vals2 = data.map(function(x){ return x[s2Key] || 0; });
  // 数据条数较多时启用滚动轴：默认显示前 8 项，可拖动查看剩余
  var useZoom = cats.length > 8;
  var zoomEnd = useZoom ? Math.min(100, Math.round(8 / cats.length * 100)) : 100;
  var option = {
    tooltip: _tip(c, function(p){
      var i = p[0].dataIndex;
      var d = data[i];
      var mh = d.mh || 0;
      var v2 = d[s2Key] || 0;
      var rate = mh ? (v2 / mh * 100).toFixed(1) : '0.0';
      return p[0].name + '<br/>中高风险数: <b>' + _fmt(mh) + '</b><br/>' + s2 + ': <b>' + _fmt(v2) + ' (' + rate + '%)</b>';
    }),
    legend: { data: ['中高风险数', s2], textStyle: { color: c.axisLabel } },
    grid: { left: 46, right: 12, top: 34, bottom: useZoom ? 56 : 42 },
    xAxis: { type: 'category', data: cats, axisLabel: { color: c.axisLabel, rotate: cats.length > 8 ? 30 : 0 }, axisLine: { lineStyle: { color: c.axisLabel } } },
    yAxis: { type: 'value', axisLabel: { color: c.axisLabel }, splitLine: { lineStyle: { color: c.splitLine } } },
    series: [
      { name: '中高风险数', type: 'bar', barWidth: cats.length > 10 ? '26%' : '32%', data: data.map(function(x){return x.mh||0;}),
        itemStyle: { color: '#40a0ff', borderRadius: [3,3,0,0] } },
      { name: s2, type: 'bar', barWidth: cats.length > 10 ? '26%' : '32%', data: vals2,
        itemStyle: { color: mode === 'dispose' ? '#34d399' : '#fbbf24', borderRadius: [3,3,0,0] } },
    ],
  };
  // 启用滚动轴：inside（鼠标拖动/触屏滑动）+ slider（底部滑块），zoomLock 禁止缩放只允许平移
  if (useZoom) {
    option.dataZoom = [
      { type: 'inside', start: 0, end: zoomEnd, zoomLock: true },
      { type: 'slider', start: 0, end: zoomEnd, zoomLock: true, height: 14, bottom: 8,
        borderColor: c.splitLine, fillerColor: 'rgba(64,160,255,.18)',
        handleStyle: { color: '#40a0ff' }, textStyle: { color: c.axisLabel, fontSize: 10 },
        dataBackground: { lineStyle: { color: c.splitLine }, areaStyle: { color: 'rgba(80,150,220,.10)' } },
        selectedDataBackground: { lineStyle: { color: '#40a0ff' }, areaStyle: { color: 'rgba(64,160,255,.20)' } } }
    ];
  }
  chart.setOption(option, true);
}

/**
 * 渲染趋势图（处置/清理双模式）：双柱（中高数 + 超期未处置/清理数）+ 完成率折线
 * trend: [{month, mh, disp, clear, disp_rate, clear_rate}]
 * mode: 'dispose' | 'clear'
 */
function renderTrend(domId, trend, mode) {
  var c = getChartColors();
  var chart = _init(domId);
  if (!chart) return;
  var months = trend.map(function(t){ return (t.month || '').slice(2); });
  var mh = trend.map(function(t){ return t.mh; });
  var overdue, rate, rateName, barName, barColor, lineColor;
  if (mode === 'clear') {
    overdue = trend.map(function(t){ return t.overdue_uncleared; });
    rate = trend.map(function(t){ return t.clear_rate; });
    rateName = '清理完成率';
    barName = '超期未清理数';
    barColor = '#f87171';
    lineColor = '#34d399';
  } else {
    overdue = trend.map(function(t){ return t.overdue_undisposed; });
    rate = trend.map(function(t){ return t.disp_rate; });
    rateName = '处置完成率';
    barName = '超期未处置数';
    barColor = '#f59e0b';
    lineColor = '#40a0ff';
  }
  chart.setOption({
    tooltip: _tip(c, function(p){
      var i = p[0].dataIndex;
      var t = trend[i];
      return months[i] + '<br/>风险数: <b>' + _fmt(t.mh) + '</b><br/>' + barName + ': <b>' + _fmt(t[ mode==='clear'?'overdue_uncleared':'overdue_undisposed']) + '</b><br/>' + rateName + ': <b>' + (mode==='clear'?t.clear_rate:t.disp_rate) + '%</b>';
    }),
    legend: { data: ['风险数', barName, rateName], textStyle: { color: c.axisLabel } },
    grid: { left: 50, right: 50, top: 40, bottom: 42 },
    xAxis: { type: 'category', data: months, axisLabel: { color: c.axisLabel }, axisLine: { lineStyle: { color: c.axisLabel } } },
    yAxis: [
      { type: 'value', name: '风险数', axisLabel: { color: c.axisLabel }, splitLine: { lineStyle: { color: c.splitLine } } },
      { type: 'value', name: '%', min: 0, max: 100, axisLabel: { color: c.axisLabel }, splitLine: { show: false } },
    ],
    series: [
      { name: '风险数', type: 'bar', data: mh, itemStyle: { color: '#7ca8dd', borderRadius: [3, 3, 0, 0] }, barWidth: '32%' },
      { name: barName, type: 'bar', data: overdue, itemStyle: { color: barColor, borderRadius: [3, 3, 0, 0] }, barWidth: '24%' },
      { name: rateName, type: 'line', yAxisIndex: 1, data: rate, smooth: true,
        lineStyle: { color: lineColor, width: 2.5 }, itemStyle: { color: lineColor },
        areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: mode==='clear' ? 'rgba(52,211,153,.22)' : 'rgba(64,160,255,.20)' },
          { offset: 1, color: 'rgba(0,0,0,0)' }] } } },
    ],
  }, true);
}

// resize
window.addEventListener('resize', function(){
  for (var k in _charts) { try { _charts[k].resize(); } catch(e){} }
});

// 主题切换重绘（由 risk.js 重新拉数据并调用 render*）
window.addEventListener('themechange', function(){
  if (window.onThemeChange) { try { window.onThemeChange(); } catch(e){} }
});

window._chartReset = function(){
  for (var k in _charts) { try { _charts[k].dispose(); } catch(e){} }
  _charts = {};
};
