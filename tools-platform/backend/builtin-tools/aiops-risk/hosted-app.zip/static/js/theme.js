// 主题切换：深色 / 浅色，持久化到 localStorage

(function() {
  var THEME_KEY = 'aiops-theme';

  function getStoredTheme() {
    try { return localStorage.getItem(THEME_KEY) || 'dark'; }
    catch(e) { return 'dark'; }
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    var icon = document.getElementById('themeIcon');
    var label = document.getElementById('themeLabel');
    if (icon) icon.textContent = theme === 'dark' ? '🌙' : '☀';
    if (label) label.textContent = theme === 'dark' ? '深色' : '浅色';
    // 通知图表重绘
    window.dispatchEvent(new CustomEvent('themechange', {detail: theme}));
  }

  function toggleTheme() {
    var current = document.documentElement.getAttribute('data-theme') || 'dark';
    var next = current === 'dark' ? 'light' : 'dark';
    try { localStorage.setItem(THEME_KEY, next); } catch(e) {}
    applyTheme(next);
  }

  // 初始化
  var saved = getStoredTheme();
  applyTheme(saved);

  // 绑定切换按钮
  document.addEventListener('DOMContentLoaded', function() {
    var btn = document.getElementById('themeToggle');
    if (btn) btn.addEventListener('click', toggleTheme);
  });

  // 暴露给外部
  window.getTheme = function() {
    return document.documentElement.getAttribute('data-theme') || 'dark';
  };
  window.applyTheme = applyTheme;
})();
