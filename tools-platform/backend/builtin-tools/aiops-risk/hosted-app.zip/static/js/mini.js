/**
 * static/js/mini.js — 风险管理看板小页面控制器（v0.9.4）
 *
 * 参考 AiOps-DigitalCert 小页面规范
 * 功能：
 * 1. 解析 URL Query 筛选参数（支持盯进展标准格式 + 兼容旧格式）
 * 2. 调用 /api/dashboard 获取 KPI + 趋势数据
 * 3. 渲染 2 个 KPI 卡片（风险数 + 中高风险处置完成率）
 * 4. 渲染月度趋势图（中高风险数柱状 + 处置完成率折线，双轴，近12月）
 * 5. ResizeObserver 自适应（上下布局，只需 resize 图表）
 * 6. postMessage 监听盯进展主页筛选更新
 * 7. 所有点击（KPI + 趋势图任意位置）跳转主屏首页（不带 metric）
 */
(function (global) {
  'use strict';

  // ============================================================
  // 配置
  // ============================================================
  var DASHBOARD_URL = './';  // 完整看板 URL（相对路径）

  // 3 个核心 KPI（参考数字证书小页面：指标 + 已处置 + 完成率）
  var KPI_CONFIG = [
    { name: '中高风险数', key: 'mh', cls: '', isRate: false },
    { name: '中高风险已处置', key: 'disposed', cls: '', isRate: false },
    { name: '中高风险处置完成率', key: 'disp_rate', cls: 'rate', isRate: true }
  ];

  // URL 参数 → 内部筛选 key 映射（对齐大页面统一规范）
  // 大页面标准参数：ict_scene/region/reoffice/country/product_line/network/month
  var URL_PARAM_MAP = {
    'ict_scene': 'ict',
    'ict': 'ict',
    'region': 'region',
    'reoffice': 'office',
    'office': 'office',
    'country': 'country',
    'product_line': 'pl',
    'pl': 'pl',
    'network': 'net',
    'net': 'net',
    'month': 'month'
  };

  // 内部字段 → 跳转 URL 参数名（跳转时用标准参数名）
  var FILTER_TO_URL_PARAM = {
    'ict': 'ict',
    'region': 'region',
    'office': 'office',
    'country': 'country',
    'pl': 'pl',
    'net': 'net',
    'month': 'month'
  };

  // ============================================================
  // 状态
  // ============================================================
  var currentFilters = {};
  var trendChart = null;
  var resizeObserver = null;

  // ============================================================
  // API 调用（复用 api.js 的 apiBase 逻辑，独立实现避免依赖）
  // ============================================================
  function apiBase() {
    var path = location.pathname;
    var lastSlash = path.lastIndexOf('/');
    var dir = lastSlash > 0 ? path.substring(0, lastSlash + 1) : '/';
    return dir + 'api';
  }

  async function apiGet(endpoint) {
    var url = apiBase() + '/' + endpoint.replace(/^\//, '');
    var resp = await fetch(url);
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    return resp.json();
  }

  // ============================================================
  // URL 参数解析
  // ============================================================
  function parseFiltersFromURL() {
    var params = new URLSearchParams(location.search);
    var filters = {};
    Object.keys(URL_PARAM_MAP).forEach(function (urlKey) {
      var val = params.get(urlKey);
      if (val) {
        filters[URL_PARAM_MAP[urlKey]] = val;
      }
    });
    return filters;
  }

  // ============================================================
  // 数据加载
  // ============================================================
  async function loadMiniData() {
    showLoading(true);
    try {
      // 构建 query string
      var qs = Object.keys(currentFilters)
        .map(function (k) { return k + '=' + encodeURIComponent(currentFilters[k]); })
        .join('&');
      var endpoint = 'mini-dashboard' + (qs ? '?' + qs : '');
      var result = await apiGet(endpoint);
      if (result.code !== 0) {
        showError(result.message || '接口返回错误');
        return;
      }
      var data = result.data || {};
      renderKpiCards(data.kpi || {});
      var regionData = (data.charts && data.charts.region) ? data.charts.region : [];
      renderTrendChart(regionData);
      bindDetailLink();
      showLoading(false);
    } catch (e) {
      console.error('mini data load error', e);
      showError(e.message);
    }
  }

  // ============================================================
  // KPI 卡片渲染（3 个，grid 3列）
  // ============================================================
  function renderKpiCards(kpi) {
    var grid = document.getElementById('kpiGrid');
    if (!grid) return;
    grid.innerHTML = '';

    KPI_CONFIG.forEach(function (cfg) {
      var val = kpi[cfg.key];
      if (val === undefined || val === null) val = 0;

      var card = document.createElement('div');
      card.className = 'mini-kpi-card';
      var valStr = cfg.isRate ? fmtRate(val) : fmtNum(val);
      var unitHtml = cfg.isRate ? '' : '<span class="mini-kpi-unit">个</span>';
      card.innerHTML =
        '<div class="mini-kpi-value ' + cfg.cls + '">' + valStr + unitHtml + '</div>' +
        '<div class="mini-kpi-name">' + cfg.name + '</div>';
      card.onclick = function () { openDashboard(); };
      grid.appendChild(card);
    });
  }

  // ============================================================
  // 地区部分布图（中高风险数柱状 + 处置完成率折线，双轴）
  // ============================================================
  function renderTrendChart(regionData) {
    var el = document.getElementById('mini_chart');
    if (!el) return;
    if (!regionData || regionData.length === 0) {
      el.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#8aa6c6;font-size:11px">暂无数据</div>';
      return;
    }

    if (trendChart) { try { trendChart.dispose(); } catch (e) {} }
    trendChart = echarts.init(el);

    // 地区部名称（X轴），按容器宽度自适应截断
    var containerWidth = el.offsetWidth || 400;
    var isNarrow = containerWidth < 400;
    var names = regionData.map(function (d) {
      var name = d.name || '';
      if (isNarrow) {
        // 窄屏：去掉"地区部"后缀，超过4字截断
        name = name.replace(/地区部$/, '').replace(/代表处$/, '');
        if (name.length > 4) name = name.substring(0, 3) + '…';
      }
      return name;
    });

    var option = {
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(13,28,48,.96)',
        textStyle: { color: '#dce9f8', fontSize: 11 },
        borderColor: 'rgba(80,150,220,.14)',
        formatter: function (p) {
          var i = p[0].dataIndex;
          var d = regionData[i];
          var html = (d.name || '') + '<br/>';
          html += '中高风险数: <b>' + fmtNum(d.mh || 0) + '</b><br/>';
          html += '已处置: <b>' + fmtNum(d.disposed || 0) + '</b><br/>';
          html += '处置完成率: <b>' + (d.disp_rate || 0) + '%</b>';
          return html;
        }
      },
      legend: {
        data: ['中高风险数', '处置完成率'],
        textStyle: { color: '#8aa6c6', fontSize: 10 },
        top: 2, right: 8
      },
      grid: { left: 48, right: 44, top: 28, bottom: 22 },
      xAxis: {
        type: 'category', data: names,
        axisLabel: { color: '#8aa6c6', fontSize: 9, rotate: names.length > 6 ? 30 : 0, interval: 0 },
        axisLine: { lineStyle: { color: '#1a2a44' } }
      },
      yAxis: [
        {
          type: 'value', name: '风险数',
          nameTextStyle: { color: '#8aa6c6', fontSize: 9 },
          axisLabel: { color: '#8aa6c6', fontSize: 9, formatter: function (v) { return v >= 10000 ? (v / 10000).toFixed(0) + '万' : v; } },
          splitLine: { lineStyle: { color: 'rgba(80,150,220,.14)' } }
        },
        {
          type: 'value', name: '%', min: 0, max: 100,
          nameTextStyle: { color: '#8aa6c6', fontSize: 9 },
          axisLabel: { color: '#8aa6c6', fontSize: 9, formatter: '{value}%' },
          splitLine: { show: false }
        }
      ],
      series: [
        {
          name: '中高风险数', type: 'bar', yAxisIndex: 0,
          data: regionData.map(function (d) { return d.mh || 0; }),
          itemStyle: { color: '#7ca8dd', borderRadius: [3, 3, 0, 0] },
          barWidth: '45%'
        },
        {
          name: '处置完成率', type: 'line', yAxisIndex: 1,
          data: regionData.map(function (d) { return d.disp_rate || 0; }),
          smooth: true,
          lineStyle: { color: '#34d399', width: 2 },
          itemStyle: { color: '#34d399' },
          symbol: 'circle', symbolSize: 4
        }
      ]
    };
    trendChart.setOption(option, true);

    // 关键修复：setOption 后延迟 resize，确保 canvas 铺满容器（容器高度可能异步展开）
    setTimeout(function() { try { trendChart.resize(); } catch(e) {} }, 50);

    // 趋势图三重监听（确保任意位置点击都能跳转）
    bindTrendChartClick();
  }

  // ============================================================
  // 趋势图三重点击监听（参考数字证书小页面）
  // ============================================================
  function bindTrendChartClick() {
    if (!trendChart) return;
    var el = document.getElementById('mini_chart');
    if (!el) return;

    // 1. ECharts getZr（底层 canvas 点击）
    try {
      trendChart.getZr().off('click');
      trendChart.getZr().on('click', function () { openDashboard(); });
    } catch (e) {}

    // 2. canvas DOM click
    var canvas = el.querySelector('canvas');
    if (canvas) {
      canvas.onclick = function () { openDashboard(); };
    }

    // 3. 容器 div click（避免重复触发）
    el.onclick = function (e) {
      if (e.target === el) { openDashboard(); }
    };

    // 也给 chart-area 整体加点击（标题栏等非 canvas 区域）
    var chartArea = document.getElementById('mini_chart');
    if (chartArea) {
      chartArea.onclick = function (e) {
        // 只在点击非 canvas 区域时触发（canvas 已有自己的监听）
        if (e.target === chartArea) {
          openDashboard();
        }
      };
    }
  }

  // ============================================================
  // 跳转完整看板主屏（不带 metric，只携带过滤条件）
  // ============================================================
  function openDashboard() {
    var query = Object.keys(currentFilters)
      .map(function (k) {
        var urlKey = FILTER_TO_URL_PARAM[k] || k;
        return urlKey + '=' + encodeURIComponent(currentFilters[k]);
      })
      .join('&');
    var url = DASHBOARD_URL + (query ? '?' + query : '');
    window.open(url, '_blank');
  }

  // ============================================================
  // 自适应（上下布局，只需 resize 图表）
  // ============================================================
  function checkLayout() {
    if (trendChart) { try { trendChart.resize(); } catch (e) {} }
  }

  // ============================================================
  // 状态展示（适配 miniView 结构：加载时隐藏 miniView，显示 loading）
  // ============================================================
  function showLoading(loading) {
    var loadEl = document.getElementById('miniLoading');
    var viewEl = document.getElementById('miniView');
    if (loading) {
      if (loadEl) loadEl.style.display = 'flex';
      if (viewEl) viewEl.style.display = 'none';
    } else {
      if (loadEl) loadEl.style.display = 'none';
      if (viewEl) viewEl.style.display = 'block';
    }
  }

  function showError(msg) {
    var errEl = document.getElementById('miniError');
    var viewEl = document.getElementById('miniView');
    if (errEl) {
      errEl.textContent = '数据加载失败: ' + msg;
      errEl.style.display = 'flex';
    }
    if (viewEl) viewEl.style.display = 'none';
    var loadEl = document.getElementById('miniLoading');
    if (loadEl) loadEl.style.display = 'none';
  }

  // ============================================================
  // 格式化
  // ============================================================
  function fmtNum(n) {
    return Number(n || 0).toLocaleString('en-US');
  }
  function fmtRate(n) {
    return Number(n || 0).toFixed(2) + '%';
  }

  // ============================================================
  // postMessage 监听（盯进展主页动态更新筛选）
  // ============================================================
  window.addEventListener('message', function (e) {
    if (e.data && e.data.type === 'riskMiniUpdate' && e.data.filters) {
      currentFilters = e.data.filters;
      loadMiniData();
    }
  });

  // ============================================================
  // 绑定查看详情链接
  // ============================================================
  function bindDetailLink() {
    var link = document.getElementById('detailLink');
    if (link && !link._riskMiniBound) {
      link._riskMiniBound = true;
      link.onclick = function (e) {
        e.stopPropagation();
        e.preventDefault();
        openDashboard();
        return false;
      };
    }
  }

  // ============================================================
  // 初始化
  // ============================================================
  function init() {
    // 解析 URL 筛选参数
    currentFilters = parseFiltersFromURL();

    // 检查布局
    checkLayout();

    // 加载数据
    loadMiniData();

    // ResizeObserver 自适应（与数字证书小页面一致：双重 resize 确保执行）
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(function () {
        checkLayout();
        if (trendChart) { try { trendChart.resize(); } catch (e) {} }
      });
      resizeObserver.observe(document.getElementById('miniView') || document.body);
    }

    // 窗口 resize
    window.addEventListener('resize', function () {
      if (trendChart) { try { trendChart.resize(); } catch (e) {} }
    });
  }

  // DOM Ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // 导出（供 postMessage 和外部调用）
  global.RiskMini = { init: init, loadMiniData: loadMiniData, openDashboard: openDashboard };

})(typeof window !== 'undefined' ? window : this);
